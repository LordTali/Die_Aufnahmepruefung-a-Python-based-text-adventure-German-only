"""
In dieser Datei sind die Funktionen der Räume gespeichert, die bei Spielstart ausgeführt werden.
Der Charakter wird durch die Einleitung und die ersten Räume geführt, ab dann hat er freie Hand.
"""

from fackel_und_tuer_proben import *
from raetsel import *
from fallen import *
from charakter import protagonist


def spielstart():
    print(f"{Fore.GREEN}Willkommen bei \"Die Aufnahmeprüfung\", einem Textabenteuer-Spiel "
          "im Zeit-Der-Zünfte-System von Vitali Hänisch!\n")
    WARTEN()
    print("Für die Zwecke dieses Spiels nehmen wir eine stark abgespeckte Version des Systems.\n")
    WARTEN()
    print("Das soll ja schließlich nur ein entspanntes kurzes Spiel sein, nicht wahr?\n")
    WARTEN()
    print("In diesem Abenteuer übernimmst du die Rolle eines jungen Anwärters, " 
          "der seine Aufnahmeprüfung als Lehrling bestehen und später zum Mitglied einer Gilde (Zunft) werden will.\n")
    WARTEN()
    print("Einen Ausbildungsplatz zu finden ist nicht einfach, aber du hast dich richtig ins Zeug gelegt, "
          "um deinen potentiellen Meister davon zu überzeugen, dich als seinen Lehrling zu nehmen.\n")
    WARTEN()
    print("Leider bleibt der Typ sehr skeptisch, aber er gibt dir immerhin eine Chance.\n")
    WARTEN()
    print("Dabei hat er sich eine ganz besondere Probe für dich ausgedacht.\n")
    WARTEN()
    print("Du musst dich in eine Höhle begeben, dich beweisen und mit drei Gegenständen zurückkommen.\n")
    while True:
        eingabe = input("Willst du wissen, wie dieses Spiel funktioniert?\n > ")
        if "ja" in eingabe:
            WARTEN()
            return True
        elif "nein" in eingabe:
            return False
        elif "raushier" in eingabe:
            programmende()
            continue
        else:
            hoppla()


def steuerung():
    print("Der Sinn und Zweck eines Textabenteuer-Spiels besteht darin, eine hoffentlich "
          "spannende und interessante Geschichte zu erzählen.\n")
    WARTEN()
    print("Im Verlauf dieses Spiels wirst du wiederholt aufgefordert, eine Eingabe zu machen.\n")
    WARTEN()
    print("Natürlich ist dabei auch etwas Glück im Spiel (haha), aber größtenteils entwickelt sich die Handlung "
          "ausgehend von deinen Handlungen, die so ganz nebenbei auch über deinen Erfolg bestimmen.\n")
    WARTEN()
    print("Überlege dir also gut, was du tust. ;)\n")
    WARTEN()
    print("Nimm dir ruhig jede semantische Freiheit bei deinen Antworten.\n")
    WARTEN()
    print("Bedenke aber, dass das Spiel auf bestimmte Schlüsselwörter und Schreibweisen achtet, "
          "um deine Eingabe zu erkennen und richtig einzuordnen.\n")
    WARTEN()
    print("An einigen Stellen kannst du versuchen, ein Hindernis mit dem Grips deines Charakters oder mit Gewalt "
          "zu überwinden.\n")
    WARTEN()
    print("Gib \"Grips\" als Antwort ein, wenn du deinen Charakter für schlau genug hältst, "
          "die Antwort selbst zu finden.\n")
    WARTEN()
    print("Möglicherweise hast du damit Erfolg, einen Gefallen tust du dir bei der Auswertung des Meisters "
          "aber nicht - immerhin nimmt Nachdenken viel Zeit in Anspruch..\n")
    WARTEN()
    print("Bist du begabt in der Magie, kannst du zum Teil auch sie einsetzen.\n")
    WARTEN()
    print("Wenn du denkst, dass dein Charakter bei etwas sein magisches Glück versuchen könnte, gib \"zaubern\" ein,"
          "wenn du dazu aufgefordert wirst.\n")
    WARTEN()
    print("Jeder Zauber hat einen Kontrollwert, den dein Charakter erreichen muss, damit die magische Energie "
          "fokussiert werden kann.\n")
    WARTEN()
    print("Bei einem Kontrollwurf wird geprüft, ob dein Charakter genug Erfolge hat.\n")
    WARTEN()
    print("Dazu würfeln wir für jeden Kontrollwürfel deines Charakters 1W6 (also einen sechsseitigen Würfel).\n")
    WARTEN()
    print("Jeder Würfel, der mindestens den sogenannten Erfolgswert erreicht (dieser variiert je nach Zauber "
          "- in der Regel 4), gilt der Würfel als Erfolg.\n")
    WARTEN()
    print("Hast du genug Erfolge für den jeweiligen Zauber, "
          "gilt der Kontrollwert als erreicht und der Kontrollwurf damit als bestanden.\n")
    WARTEN()
    print("Beim Zaubern besteht allerdings für die meisten Zauber die Chance einer sogenannten Zauberdetonation.\n")
    WARTEN()
    print("Dass das passiert, willst du nicht.\n")
    WARTEN()
    print("Wirklich nicht.\n")
    WARTEN()
    print("Beim Zaubern musst du also immer zwischen Nutzen und Risiko abwägen.\n")
    WARTEN()
    print("Außerdem verbrauchen Zauber deine Zauberkraft. Wenn du zu wenig davon hast, kannst du nicht mehr zaubern, "
          "bis du dich ausgeruht und Kraft getankt hast.\n")
    WARTEN()
    print("Du kannst das Spiel auch bei jeder Eingabe verlassen, indem du \"raushier\" (sic) eingibst.\n")
    WARTEN()
    print("Wobei der Entwickler dieses Spiels natürlich hofft, dass du später noch mal zurückkommst. :) \n")
    WARTEN()
    print("Oh! Und hinterlasse dem Entwickler nachher gerne eine Rückmeldung zum Spiel, "
          "falls du über diese Möglichkeit verfügst! (^_^) \n")
    WARTEN()
    print("Und nun... Mach das Programmfenster ein bisschen breiter, um den Text ordentlich lesen zu können.\n")
    WARTEN()
    print("Mach's dir bequem, hol dir was zu trinken, mach am besten irgendeine \"dungeon-taugliche\" Musik "
          "deiner Wahl an, und genieße das Amateur-Theater.\n")
    WARTEN()
    return


def vorraum_1():
    print("Die schwere Tür knallt hinter dir zu, und du findest in völliger Dunkelheit wieder.\n")
    WARTEN()
    print("Hier gibt es überhaupt keine Lichtquellen. Es hat sogar den Anschein, als könnte die Dunkelheit nicht "
          "absoluter sein.\n")
    if protagonist.rasse in ["Zwerg", "Dunkelelf", "Ork"]:
        print("Zum Glück bist du als Zwerg auf Lichtquellen nicht angewiesen.\n")
        WARTEN()
        print("Es dauert zwar einen Moment, bis sich deine Pupillen auf diese Dunkelheit einstellen, dann wird der "
              "Raum vor dir aber nach und nach wieder deutlich zu sehen\n")
        return
    elif protagonist.rasse in ["Elf", "Dunkelelf"] or protagonist.karriere == "Zauberer":
        print("Zum Glück kennst du einen Zauber, der Licht erschaffen kann.\n")
        WARTEN()
        print("Allerdings hast du beim Reingehen bemerkt, dass an der Wand eine Fackel hängt. Du könntest sie erspüren "
              "und versuchen, anzuzünden.\n")
        WARTEN()
        while True:
            aktion = input("Was willst du tun? (Optionen: Zaubern, Fackel anzünden) \n > ").lower()
            if "zauber" in aktion:
                WARTEN()
                print("Du gehst einmal in dich, und versucht, die magischen Ströme um dich zu fokussieren.\n")
                WARTEN()
                probe = protagonist.kontrollwurf(licht)
                WARTEN()
                if probe:
                    print("Du machst eine Handbewegung und formst die magischen Ströme um dich herum zu einer "
                          "Kugel aus reinem warmen Licht.\n")
                    WARTEN()
                    print("Deine Umgebung ist nun wieder gut sichtbar.\n")
                    WARTEN()
                    return
                else:
                    print("Du strengst dich an, doch deine Bewegungen sind vor lauter Aufregung zu unsicher.\n")
                    WARTEN()
                    print("Der Zauber will einfach nicht klappen.\n")
                    WARTEN()
                    print("Aber zumindest hast du noch die Streichhölzer, die du verwenden kannst.\n")
                    WARTEN()
                    wurf = probe_fackel()
                    if wurf:
                        return
            elif "fackel" or "zünd" in aktion:
                print("Du beschließt, deine Zauberkraft für wichtigere Dinge zu sparen.\n")
                WARTEN()
                wurf = probe_fackel()
                if wurf:
                    return
            elif "raushier" in aktion:
                programmende()
                continue
            else:
                print("Hoppla! Etwas ist bei deiner Eingabe schiefgegangen. Versuch es bitte noch einma.\n")
                WARTEN()

    else:
        print("Zum Glück hast du beim Hineingehen eine Fackel an der Wand bemerkt. Ohne weitere Hilfsmittel "
              "ist sie deine einzige Hoffnung hier.\n")
        wurf = probe_fackel()
        if wurf:
            return


def vorraum_2():
    print("Du befindest dich in einem großen Raum aus Stein.\n")
    WARTEN()
    print("Deine Umgebung wirkt wie ein von (Nicht-)Menschenhand bearbeitete Höhle.\n")
    WARTEN()
    print("Der Boden ist eben und aus Stein gehauen, eindeutig Handarbeit!\n")
    WARTEN()
    print("Die Wände hingegen sind natürliche Höhlenwände, nur stellenweise bearbeitet, "
          "um einen Türrahmen anbringen zu können.\n")
    WARTEN()
    print("Langsam dämmert es dir, was dein potentieller Meister mit dir vorhat.\n")
    WARTEN()
    print("Das hier ist ein Prüfungsgewölbe, in dem angehende junge Abenteurer ihren Wert unter Beweis stellen "
          "und idealerweise auch Ruhm und Beute sammeln können.\n")
    WARTEN()
    if protagonist.rasse == "Zwerg":
        print(f"\"{Fore.RED}Dönnschn{Fore.GREEN}\" in der Sprache der Zwerge, \"Svertsch\".\n")

    elif protagonist.rasse in ["Elf", "Dunkelelf"]:
        print(f"\"{Fore.CYAN}Dánesane{Fore.GREEN}\" in der Sprache der Elfen, \"Eleval\".\n")
    elif protagonist.rasse == "Mensch":
        print(f"Manche menschliche Sprachen - darunter auch deine, \"Norderlies\", die Sprache des Nordland-Imperiums "
              f"- haben dafür ein Wort unklaren Ursprungs: \"{Fore.BLUE}Dungeon{Fore.GREEN}\".\n")
    elif protagonist.rasse == "Ork":
        print(f"\"{Fore.LIGHTRED_EX}d'nsh'n{Fore.GREEN}\" in der Sprache der Orks, \"Orsák\".\n")
    elif protagonist.rasse == "Kurzling":
        print(f"\"{Fore.LIGHTWHITE_EX}Dainessén{Fore.GREEN}\" in \"Korotoa\", der Sprache der Kurzlinge.\n")
    else:
        print(f"\"{Fore.YELLOW}Du-huáa{Fore.GREEN}\" in der Sprache der Sim'iari, \"Gortka\".\n ")
    WARTEN()
    print("Direkt vor dir erstreckt sich eine dicke Felswand mit einer massiven eingelassenen Tür.\n")
    WARTEN()
    print("Sie gleicht vielmehr einem Festungstor und hat zwei Schlüssellöcher.\n")
    WARTEN()
    return True


def vorraum_3():
    print("Natürlich fehlen dir dafür die Schlüssel.\n")
    WARTEN()
    if protagonist.karriere == "Gauner":
        print("Du könntest aber trotzdem versuchen, sie aufzukriegen. Das Werkzeug dafür wurde dir ja gegeben.\n")
        WARTEN()
    if protagonist.karriere == "Zauberer" or protagonist.rasse == "Elf":
        print("Du könntest aber auch versuchen, die Tür mit Magie zu öffnen. Wir nicht einfach, "
              "aber wenn du stark genug bist, könnte es vielleicht klappen.\n")
        WARTEN()
    if protagonist.karriere == "Recke":
        print("Mit einem Schwert kriegst du jedenfalls nicht auf, dafür ist die Tür viel zu stark.\n")
        WARTEN()
        print("Da müsste man schon mit einer richtig guten Axt ankommen, und die hast du nicht.\n")
        WARTEN()
    return


def vorraum_4():
    print("Du stehst vor der massiven Tür, Gesicht gen Nord.\n")
    WARTEN()
    print("Zu deiner Rechten, gen Ost, befindet sich aber noch eine Tür.\n")
    WARTEN()
    print("Zu deiner Linken, gen West, ist zudem ein schmaler Durchgang ohne jegliche Türen.\n")
    WARTEN()
    return
