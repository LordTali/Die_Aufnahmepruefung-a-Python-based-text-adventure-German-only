"""
Diese Datei speichert verschiedene Proben (andere Spiele sprechen auch von Würfen, Checks oder Skillchecks),
die der Spieler im Verlauf des Spiels ablegen muss, um voranzukommen.
"""

from charakter import *
from steuerelemente import *
from ende import programmende
from raetsel import *


def probe_fackel():
    print("Mit einiger Mühe erspürst du die Fackel und versuchst, sie anzuzünden.\n")
    while True:
        probe = protagonist.geschickWurf(12)
        protagonist.streichhoelzer -= 1
        print(f"{Fore.WHITE}[Verbleibende Streichhölzer: {protagonist.streichhoelzer}]{Fore.GREEN}\n")
        WARTEN()
        if probe:
            print("Mit einer schnellen Handbewegung entzündet sich das Streichholz in kleinem, aber hellen Licht.\n")
            WARTEN()
            print("Schnell berührst du die Fackel, bevor es ausgehen kann.\n")
            WARTEN()
            print("Nur wenige Sekunden später erstrahlt die Fackel in hellem Licht und erleuchtet die Umgebung.\n")
            WARTEN()
            return True
        else:
            print("Vielleicht liegt es an der Dunkelheit, vielleicht an der Aufregung, aber du kriegst die Fackel "
                  "nicht angezündet.\n")
            WARTEN()
            if protagonist.streichhoelzer == 0:
                protagonist.epilog = True
                return False
            else:
                continue


def massive_tuer():
    print("Die Tür ist massiv und mit zwei Schlössern gesichert.\n")
    WARTEN()
    print("Wenn du sie aufmachen willst, brauchst du entweder die richtigen Schlüssel, richtig gutes Werkzeug, "
          "oder sehr starke magische Kontrolle.\n")
    WARTEN()
    while True:
        handlung = input("Was willst du tun? (Optionen: Öffnen, Schlüssel, Knacken, Zaubern, "
                         "Draufhauen, Weggehen)\n > ").lower()
        if "schl" in handlung:
            if spiel.massive_tuer:
                print("Die Tür ist bereits entsperrt.\n")
                WARTEN()
                continue
            else:
                aktion = massive_tuer_schluessel()
                if aktion:
                    spiel.massive_tuer = True
                continue
        elif "zauber" in handlung:
            if spiel.massive_tuer:
                print("Die Tür ist bereits entsperrt.\n")
                WARTEN()
                continue
            else:
                aktion = massive_tuer_zaubern()
                if aktion:
                    spiel.massive_tuer = True
                continue
        elif "hau" in handlung:
            print("Du schlägst mit deiner Waffe mit voller Wucht gegen die Tür.\n")
            WARTEN()
            print("Das zeigt keine Wirkung.\n")
            WARTEN()
            continue
        elif "nack" in handlung:
            if spiel.massive_tuer_knacken:
                print("Du hast bereits festgestellt, dass das Schloss zu komplex für dich ist.\n")
                WARTEN()
                print("Ein weiterer Versuch lohnt sich einfach nicht.\n")
                WARTEN()
                continue
            if spiel.massive_tuer:
                print("Die Tür ist bereits entsperrt.\n")
                WARTEN()
                continue
            else:
                if "Haarklammer" in protagonist.inventar:
                    aktion = massive_tuer_knacken()
                    if aktion:
                        spiel.massive_tuer = True
                else:
                    print("Du hast nicht das richtige Werkzeug für diese Aktion.\n")
                    WARTEN()
                continue
        elif "weg" in handlung:
            print("Du entfernst dich wieder von der Tür.\n")
            WARTEN()
            return
        elif "ffne" in handlung:
            if spiel.massive_tuer:
                print("Du kannst die schwere Tür mit einiger Anstrengung aufmachen.\n")
                WARTEN()
                print("Der Weg vor dir ist nun frei.\n")
                WARTEN()
                return True
            else:
                print("Die Tür ist verschlossen und lässt sich nicht öffnen.\n")
                WARTEN()
                continue
        elif "raushier" in handlung:
            programmende()
        else:
            hoppla()


def massive_tuer_knacken():
    print("Du machst dich an die Schlösser ran, und merkst sofort, wie schwer das wird.\n")
    WARTEN()
    print("Aber gut, du verlierst nichts außer Zeit.\n")
    WARTEN()
    knacken = protagonist.mechanikWurf(18)
    if knacken:
        print("Nach langem Rumfummeln hast du das Schloss endlich aufbekommen.\n")
        WARTEN()
        print("Die Tür ist nicht mehr verschlossen.\n")
        return True
    else:
        spiel.massive_tuer_knacken = True
        print("So sehr du dich auch bemühst, ist das Schloss für dich zu komplex.\n")
        WARTEN()
        print("Vielleicht hast du das notwendige Können, wenn du die Ausbildung abschließt.\n")
        WARTEN()
        print("Fürs Erste musst aber einen anderen Weg suchen, die Tür zu öffnen.\n")
        WARTEN()
        return False


def massive_tuer_schluessel():
    gelbes_schloss = False
    rotes_schloss = False
    if "roter Schlüssel" in protagonist.inventar:
        rotes_schloss = True
        print(f"Du steckst den {Fore.RED} roten Schlüssel {Fore.GREEN} ins {Fore.RED} rote Schloss{Fore.GREEN}.\n")
        WARTEN()
        print("Du drehst ihn um und hörst ein vertrautes Schlossknacken. Ein Schloss ist jetzt auf.\n")
        WARTEN()
    if "gelber Schlüssel" in protagonist.inventar:
        gelbes_schloss = True
        print(f"Du steckst den {Fore.YELLOW} gelben Schlüssel {Fore.GREEN} ins {Fore.YELLOW} "
              f"gelbe Schloss{Fore.GREEN}.\n")
        WARTEN()
        print("Du drehst ihn um und hörst ein vertrautes Schlossknacken. Ein Schloss ist jetzt auf.\n")
        WARTEN()
    if rotes_schloss and gelbes_schloss:
        print("Beide Schlüssel stecken jetzt in der Tür. Sie ist nicht mehr verschlossen.\n")
        WARTEN()
        return True
    elif "roter Schlüssel" not in protagonist.inventar and "gelber Schlüssel" not in protagonist.inventar:
        print("Du hast keine Schlüssel, die du reinstecken kannst.\n")
        WARTEN()
        return False
    else:
        if gelbes_schloss:
            print("Leider fehlt dir noch ein Schlüssel für das rote Schloss.\n")
            WARTEN()
            return False
        else:
            print("Leider fehlt dir noch ein Schlüssel für das gelbe Schloss.\n")
            WARTEN()
            return False


def massive_tuer_zaubern():
    zaubern = zauber_pruefen(entsperren)
    if not zaubern:
        print("Das ist zwar nicht verwunderlich, aber schon irgendwie bitter.\n")
        WARTEN()
        print("Wie dem auch sei, du musst dir einen anderen Weg suchen, sie zu knacken.\n")
        WARTEN()
        return False
    else:
        probe = protagonist.kontrollwurf(entsperren)
        if probe and protagonist.zauberkraft >= entsperren.aufwand_zauberkraft:
            print("Mit einer gewaltigen Anstrengung kannst du die magischen Ströme dazu bringen, "
                  "die Schlösser aufzumachen.\n")
            WARTEN()
            print("Die Tür ist nicht mehr verschlossen.\n")
            WARTEN()
            return True
        else:
            print("Du bist nicht stark genug, um diese Tür mit Magie aufzumachen.\n")
            WARTEN()
            print("Das ist zwar nicht verwunderlich, aber schon irgendwie bitter.\n")
            WARTEN()
            print("Wie dem auch sei, du musst dir einen anderen Weg suchen, sie zu knacken.\n")
            WARTEN()
            return False


def gelbe_tuer():
    print(f"Die Tür ist vergleichsweise robust und mit einem {Fore.YELLOW}gelben Schloss{Fore.GREEN} gesichert.\n")
    WARTEN()
    print("Wenn du sie aufmachen willst, brauchst du entweder die richtigen Schlüssel, richtig gutes Werkzeug, "
          "oder sehr starke magische Kontrolle.\n")
    WARTEN()
    while True:
        handlung = input("Was willst du tun? (Optionen: Öffnen, Schlüssel, Knacken, Zaubern, "
                         "Draufhauen, Weggehen)\n > ").lower()
        if "schl" in handlung:
            if spiel.gelbe_tuer:
                print("Die Tür ist bereits entsperrt.\n")
                WARTEN()
                continue
            else:
                aktion = gelbe_tuer_schluessel()
                if aktion:
                    spiel.gelbe_tuer = True
                continue
        elif "zauber" in handlung:
            if spiel.massive_tuer:
                print("Die Tür ist bereits entsperrt.\n")
                WARTEN()
                continue
            else:
                aktion = gelbe_tuer_zaubern()
                if aktion:
                    spiel.gelbe_tuer = True
                continue
        elif "hau" in handlung:
            print("Du schlägst mit deiner Waffe mit voller Wucht gegen die Tür.\n")
            WARTEN()
            if protagonist.karriere != "Recke":
                print("Das zeigt keine Wirkung.\n")
                WARTEN()
                continue
            else:
                spiel.strafpunkte += 1
                aktion = protagonist.kampf(15)
                if aktion:
                    spiel.gelbe_tuer = True
                    print("Du machst einige kraftvolle Hiebe.\n")
                    WARTEN()
                    print("Schon bald ist die Tür so schwer beschädigt, dass man sie nur noch wegwerfen kann.\n")
                    WARTEN()
                    print("Strenggenommen hängt sie noch, aber sie kann dich nicht mehr am Durchgehen hindern.\n")
                    WARTEN()
                    continue
                else:
                    print("Das zeigt keine Wirkung.\n")
                    WARTEN()
                    continue
        elif "nack" in handlung:
            if spiel.gelbe_tuer_knacken:
                print("Du hast bereits festgestellt, dass das Schloss zu komplex für dich ist.\n")
                WARTEN()
                print("Ein weiterer Versuch lohnt sich einfach nicht.\n")
                WARTEN()
                continue
            if spiel.gelbe_tuer:
                print("Die Tür ist bereits entsperrt.\n")
                WARTEN()
                continue
            else:
                if "Haarklammer" in protagonist.inventar:
                    aktion = gelbe_tuer_knacken()
                    if aktion:
                        spiel.gelbe_tuer = True
                else:
                    print("Du hast nicht das richtige Werkzeug für diese Aktion.\n")
                    WARTEN()
                continue
        elif "weg" in handlung:
            print("Du entfernst dich wieder von der Tür.\n")
            WARTEN()
            return
        elif "ffne" in handlung:
            if spiel.gelbe_tuer:
                print("Du kannst die schwere Tür mit einiger Anstrengung aufmachen.\n")
                WARTEN()
                print("Der Weg vor dir ist nun frei.\n")
                WARTEN()
                return True
            else:
                print("Die Tür ist verschlossen und lässt sich nicht öffnen.\n")
                WARTEN()
                continue
        elif "raushier" in handlung:
            programmende()
        else:
            hoppla()


def gelbe_tuer_knacken():
    print("Du machst dich ans Schloss ran, und merkst sofort, wie schwer das wird.\n")
    WARTEN()
    print("Aber gut, du verlierst nichts außer Zeit.\n")
    WARTEN()
    knacken = protagonist.mechanikWurf(14)
    if knacken:
        print("Nach langem Rumfummeln hast du das Schloss endlich aufbekommen.\n")
        WARTEN()
        print("Die Tür ist nicht mehr verschlossen.\n")
        return True
    else:
        spiel.gelbe_tuer_knacken = True
        print("So sehr du dich auch bemühst, ist das Schloss für dich zu komplex.\n")
        WARTEN()
        print("Vielleicht hast du das notwendige Können, wenn du die Ausbildung abschließt.\n")
        WARTEN()
        print("Fürs Erste musst aber einen anderen Weg suchen, die Tür zu öffnen.\n")
        WARTEN()
        return False


def gelbe_tuer_schluessel():
    if "gelber Schlüssel" in protagonist.inventar:
        print(f"Du steckst den {Fore.YELLOW} gelben Schlüssel {Fore.GREEN} ins {Fore.YELLOW} "
              f"gelbe Schloss{Fore.GREEN}.\n")
        WARTEN()
        print("Du drehst ihn um und hörst ein vertrautes Schlossknacken. Das Schloss ist jetzt auf.\n")
        WARTEN()
        return True
    else:
        print("Du hast keinen Schlüssel, den du reinstecken kannst.\n")
        WARTEN()
        return False


def gelbe_tuer_zaubern():
    zaubern = zauber_pruefen(entsperren_einfach)
    if not zaubern or protagonist.zauberkraft < entsperren_einfach.aufwand_zauberkraft:
        print("Das ist zwar nicht verwunderlich, aber schon irgendwie bitter.\n")
        WARTEN()
        print("Wie dem auch sei, du musst dir einen anderen Weg suchen, sie zu knacken.\n")
        WARTEN()
        return False
    else:
        probe = protagonist.kontrollwurf(entsperren_einfach)
        if probe:
            print("Mit einer gewaltigen Anstrengung kannst du die magischen Ströme dazu bringen, "
                  "die Schlösser aufzumachen.\n")
            WARTEN()
            print("Die Tür ist nicht mehr verschlossen.\n")
            WARTEN()
            return True
        else:
            print("Du bist nicht stark genug, um diese Tür mit Magie aufzumachen.\n")
            WARTEN()
            print("Das ist zwar nicht verwunderlich, aber schon irgendwie bitter.\n")
            WARTEN()
            print("Wie dem auch sei, du musst dir einen anderen Weg suchen, sie zu knacken.\n")
            WARTEN()
            return False
