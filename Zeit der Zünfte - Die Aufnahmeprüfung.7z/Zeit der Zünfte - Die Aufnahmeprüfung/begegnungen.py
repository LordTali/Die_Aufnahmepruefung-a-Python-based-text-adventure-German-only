import random
from ende import programmende
from colorama import Fore
from steuerelemente import *
from charakter import *
from kampfschleife import *


def zufallsbegegnung():
    # Die Begegnung mit dem Feind ist zufällig, elfen haben durch Magieverbundenheit aber höhere Kampfchance.
    if protagonist.zauberkraft < protagonist.max_zauberkraft or protagonist.rasse in ["Elf", "Dunkelelf"]:
        if protagonist.zauberkraft < protagonist.max_zauberkraft // 2:  # Feinde werden von Magie angezogen.
            begegnungsrechnung = random.randint(1, 6)             # Weniger Zauberkraft heißt: Der Charakter hat
        elif protagonist.zauberkraft <= 0:                              # sie ausgegeben.
            begegnungsrechnung = random.randint(1, 4)
        else:                                                          # Entsprechend erhöht sich die Chance mit jedem
            begegnungsrechnung = random.randint(1, 8)            # Magie-Einsatz.
    else:
        begegnungsrechnung = random.randint(1, 8)
    if begegnungsrechnung == 1:
        ereignis = gefahr()
        if ereignis:                                                    # Der Charakter gewinnt.
            print(f"{Fore.WHITE}[Du hast deinen Gegner besiegt und kannst den {protagonist.wort_fuer_dungeon()} "
                  f"weiter erkunden.]{Fore.GREEN}\n")
            WARTEN()
            return
        elif ereignis is None:                                          # Es findet keine Begegnung statt.
            return
        else:                                                           # Der Charakter verliert.
            spiel.epilog = True
            return False


def gefahr():
    if len(begegnung.moegliche_gegner) == 0:          # Wenn alle Gegner besiegt sind, gibt es keine neuen Begegnungen.
        return None
    else:
        print("Als du in den großen Hauptraumraum kommst, siehst du etwas Ungewöhnliches.\n")
        WARTEN()
        gegner = random.choice(begegnung.moegliche_gegner)             # Der Gegner wird zufällig bestimmt.
        begegnung_kampf(gegner)                                        # der Gegner wird vorgestellt.
        WARTEN()
        spiel.kampf = True
        begegnung.runde = 0
        while True:
            if spiel.kampf_zaehler < 1:                 # Vor dem ersten Kampf kommt die Tutorial-Frage.
                while True:
                    if spiel.neues_spiel:
                        break
                    else:
                        frage = input(f"{Fore.WHITE}[Nun befindest du dich im Kampf. "
                                      f"Willst du die Regeln dazu erfahren?]{Fore.GREEN}\n > ")
                        if "ja" in frage:
                            WARTEN()
                            kampfregeln()
                            WARTEN()
                            break
                        elif "nein" in frage:
                            print(f"{Fore.WHITE}[Gut, dann gehen wir davon aus, dass du diese bereits kennst. "
                                  f"Nervige Tutorials können wir also überspringen.]{Fore.GREEN}\n")
                            WARTEN()
                            break
                        elif "raushier" in frage:
                            programmende()
                        else:
                            hoppla()
            spiel.kampf_zaehler += 1
            begegnung.teilnehmer_hinzufuegen(protagonist)   # Ab hier beginnt der Kampf.
            begegnung.teilnehmer_hinzufuegen(gegner)
            begegnung.gegner_hinzufuegen(gegner)
            begegnung.initiative_wuerfeln()
            begegnung.reihenfolge_bestimmen()
            begegnung.reihenfolge_anzeigen()
            begegnung.kampf_beginnen()                      # Der Rundenzähler händelt den Ablauf.
            while len(begegnung.teilnehmer) > 1:            # Danach kommt Sieg oder Niederlage.
                begegnung.runden_zaehler()
                for kaempfer in begegnung.teilnehmer:
                    if kaempfer == protagonist:
                        ziel = gegner
                    else:
                        ziel = protagonist
                    if kaempfer.lebenskraft <= 0:
                        begegnung.teilnehmer.remove(kaempfer)

                        continue
                    kaempfer.handeln(ziel)
            else:                                           # Auswertung, wer gewonnen hat.
                begegnung.teilnehmer.clear()                # Die Kampfliste wird wieder geleert.
                begegnung.gegner.clear()
                if protagonist.lebenskraft > 0:
                    protagonist.ausdauer = protagonist.max_ausdauer     # Die Ausdauer wird wieder aufgefüllt.
                    begegnung.moegliche_gegner.remove(gegner)           # Der Gegner wird aus der Liste entfernt.
                    spiel.strafpunkte -= 1                              # Ein Sieg im Kampf hilft bei der Auswertung.
                    spiel.kampf = False
                    return True
                else:
                    return False


def begegnung_kampf(kreatur):
    if kreatur == kettenhase:
        print("Eine hasen- oder kaninchenähnliche Kreatur starrt dich hasserfüllt an.\n")
        WARTEN()
        print("Sie sieht aus... Nun ja, wie ein stark vermöbelter zerzauster Hase mit leuchtenden roten Augen und "
              "scharfen spitzen Zähnen eines Raubtiers.\n")
        WARTEN()
        print("Sein FellKörper ist von Metallketten bedeckt, die irgendwo in seinen Körper verschwinden.\n")
        WARTEN()
        print("So abstoßend der Anblick auch ist: Du hast irgendwann mal davon gehört.\n")
        WARTEN()
        print(f"Das Geschöpf, das du vor dir siehst, ist ein sogenannter {Fore.YELLOW}\"Kettenhase\"{Fore.GREEN}.\n")
        WARTEN()
        print("Starker Magie ausgesetzte Seelen von zu Tode gefolterten Tieren kehren manchmal "
              "in dieser Gestalt zurück, um sich an ihren Peinigern zu rächen.\n")
        WARTEN()
        print("Du fragst dich allerdings, war er hier macht.\n")
        WARTEN()
        print("Hast du dir dahingehend jemals etwas zu Schulden kommen lassen? Du kannst dich auf jeden Fall nicht "
              "daran erinnern.\n ")
        WARTEN()
        print("Dann wiederum, magische Monster fühlen sich zu magisches Quellen hingezogen.\n")
        WARTEN()
        print("Und Magie hast du auf jeden Fall eingesetzt.\n")
        WARTEN()
        print("Wie dem auch sei: Der Kettenhase schwingt seine Ketten und ist eindeutig auf Kampf aus.\n")
        WARTEN()
        print("Zum Glück ist ein einzelner Gegner dieser Art keine allzu große Gefahr.\n")
        WARTEN()
        print("Kettenhasen tendieren dazu, sich in größeren Mengen zu versammeln.\n")
        WARTEN()
        print("So traurig die Geschichte des Tieres aber sein mag, das es einmal war: Du musst an ihm vorbei.\n")
        WARTEN()
        print("Du greifst zu deiner Waffe und machst dich bereit zum Kampf.\n")
    if kreatur == blaehspinne:
        print(f"Eine riesige {Fore.YELLOW}Blähspinne{Fore.GREEN} krabbelt die "
              f"{protagonist.wort_fuer_dungeon()}-Wand runter.\n")
        WARTEN()
        print("Du hättest (leider fälschlicherweise) nie gedacht, dass du tatsächlich mal eine triffst.\n")
        WARTEN()
        print("Gehört hast du von Bläspinnen aber allemal.\n")
        WARTEN()
        print("Im Grunde ist an ihnen nichts wirklich ungewöhnlich. Es ist sind ganz normale Spinnen, die starker "
              "Magie ausgesetzt wurden.\n")
        WARTEN()
        print("Hin und wieder kommt das vor, wenn ein Zauberwirker unvorsichtig ist.\n")
        WARTEN()
        print("In der Natur sind sie selten. Trotz der gefährlichen Zähne haben sie selbst in dieser Gestalt genug "
              "natürliche Feinde.\n")
        WARTEN()
        print("Plus, sie verlieren ihre Spinnfähigkeit durch diese Mutation.\n")
        WARTEN()
        print("Was immer sie vorher waren: Jetzt sind sie im Grunde nur übergroße aufgedunsene Weberknechte.\n")
        WARTEN()
        print("Dennoch will man nicht mit ihnen alleine sein.\n")
        WARTEN()
        print("Leider bist es jetzt doch. Und du musst nun mal an ihr vorbei.\n")
        WARTEN()
        print("Trotz starker innerer Anspannung greifst du zu deiner Waffe und machst dich bereit zum Kampf.\n")
    if kreatur == schwerwolf:
        print("Ein ziemlich großer Wolf steht mitten im Gang und bleckt seine Zähne.\n")
        WARTEN()
        print("Oder... Moment! Ist dann ein Wolf?\n")
        WARTEN()
        print("Er sieht aus wie einer. Aber größer. Kräftiger. Und zwischen seinen schwarzen Fellhügeln schießen "
              "gelegentlich kaum bemerkbare schwache violette Blitze.\n")
        WARTEN()
        print(f"Ja, der Fall ist klar: Du hast es hier mit einem sogenannten {Fore.YELLOW}\"Schwerwolf\"{Fore.GREEN} "
              f"zu tun.\n")
        WARTEN()
        print("Schwerwölfe sind hier nicht heimisch - sie kamen zusammen mit dem Weltensturz nach Yarus.\n")
        WARTEN()
        if protagonist.rasse != "Mensch":
            print("Im grunde also wie deine eigene Rasse.\n")
            WARTEN()
        print("Du weißt nicht, wie er hierher kommt, aber das verheißt nichts Gutes.\n")
        WARTEN()
        print("Schwerwölfe sind in der freien Wildbahn ziemlich gefährlich\n")
        WARTEN()
        print("Der hier sieht allerdings ziemlich ausgehungert aus. Vielleicht hättest du also eine Chance.\n")
        WARTEN()
        print("So oder so: Du musst leider an ihm vorbei, wenn du die Prüfung bestehen willst.\n")
        WARTEN()
        print("Du hast einen ziemlichen Bammel vor dem Tier, aber du greifst trotzdem zu deiner Waffe und machst dich "
              "bereit zum Kampf.\n")
        WARTEN()
    return


def kampfregeln():
    print(f"{Fore.WHITE}[Wie in den meisten Rollenspielen auch, ist der Kampf hier in Runden gegliedert.]\n")
    WARTEN()
    print("[Wer zuerst angreifen darf, wird gleich über die sogenannte \"Initiative\" entschieden.]\n")
    WARTEN()
    print("[Dazu würfelt jeder einmal 1W12 und addiert seine Reflexe.]\n")
    WARTEN()
    print("[Um den Gegner zu besiegen, musst du seine Lebenskraft auf 0 reduzieren.]\n")
    WARTEN()
    print("[Dafür musst du mit deinem Wurf seinen Verteidigungswert überwinden.]\n")
    WARTEN()
    print("[Ziemlich viel Zufallsprinzip? Ja, willkommen in der Welt der Rollenspiele!]\n")
    WARTEN()
    print("[Aber du kannst das Ergebnis mit deinen Entscheidungen beeinflussen.]\n")
    WARTEN()
    print("[Der Kampf für dieses Abenteuer ist allerdings vereinfacht.]\n")
    WARTEN()
    print("[Eigentlich sieht das ZdZ-System fünf verschiedene Kampfstile vor.]\n")
    WARTEN()
    print("[Nicht zu vergessen: Viele verschiedene Aktionen, die man im Kampf machen kann:]\n")
    WARTEN()
    print("[Kampfbewegung, Boni, Waffenverhalten, Vorteile und Vieles mehr.]\n")
    WARTEN()
    print("[Vielleicht wird das alles im nächsten Abenteuer eingebaut, "
          "aber vorerst bleiben wir bei den Grundlagen.]\n")
    WARTEN()
    print("[Aber als kleiner Vorgeschmack:\n")
    WARTEN()
    print("[Ruhige Angriffe sind der Standard für jeden Kampfteilnehmer.]\n")
    WARTEN()
    print("[Gehst du aggressiv vor, achtest du mehr auf deine Treffsicherheit "
          "und Schaden als die eigene Verteidigung.]\n")
    WARTEN()
    print("[Bei vorsichtigen Angriffen ist es umgekehrt.]\n")
    WARTEN()
    print("[Natürlich kannst du auch versuchen, einfach mal nicht getroffen zu werden.]\n")
    WARTEN()
    print("[Hier sind die Regeln: Jeder Kampfteilnehmer hat 2 Aktionen zur Verfügung.]\n")
    WARTEN()
    print("[Normalerweise kann man sie für alles Mögliche benutzen, "
          "aber hier werden sie alle für den Kampf ausgegeben.]\n")
    WARTEN()
    print("[Außerdem hat jeder Kämpfer eine bestimmte Ausdauer, also eine Kraftreserve, "
          "die mit jeder Aktion beim Kämpfen verbraucht wird.]\n")
    WARTEN()
    print("[Fällt sie auf 0, wirst du erschöpft. Dass das mitten im Kampf passiert, willst du nicht.]\n")
    WARTEN()
    print("[Wirklich nicht.]\n")
    WARTEN()
    print("[Erschwerend kommt hinzu: Wenn dich ein angriff nur knapp verfehlt, heißt es, du bist aktiv "
          "ausgewichen.]\n")
    WARTEN()
    print("[Auch das verbraucht Ausdauer.]\n")
    WARTEN()
    print("[Sie erholt sich aber, wenn du nicht kämpfst bzw. gar nichts machst.]\n")
    WARTEN()
    print("[Und die gute Nachricht ist: Dein Gegner kämpft nach den gleichen Regeln.]\n")
    WARTEN()
    print("[Um den Gegner zu besiegen, muss du ihn gut erwischen.]\n")
    WARTEN()
    print("[Auch hier kommt die Ausdauer zum Einsatz: Du kannst nämlich mehr kraft in deinen Schwung reinstecken und "
          "damit den Schaden erhöhen.\n")
    WARTEN()
    print("[Falls du triffst, natürlich.]\n")
    WARTEN()
    print("[Und dass dieser zusätzliche Schwung von deiner Ausdauer abgezogen wird, erklärt sich wahrscheinlich von "
          "selbst.]")
    WARTEN()
    print("[Aber selbst wenn, jetzt hast du es eben einmal gehört.]\n")
    WARTEN()
    print("[Nur doof, dass du keine Rüstung anhast. Sie würde dir nämlich einen gewissen Schutz vor Schaden bieten.]\n")
    WARTEN()
    print("[Bedenke das, wenn du dir eine Strategie für den Kampf überlegst.]\n")
    WARTEN()
    if protagonist.karriere == "Zauberer":
        print("[Wenn du in der Magie bewandert bist, kannst im Kampf außerdem zaubern.]\n")
        WARTEN()
        print("[Dabei gelten die gleichen Regeln wie außerhalb von Kämpfen.]\n")
        WARTEN()
        print("[Kampfzauber sind in der Lage, eine Menge Schaden zu verursachen.]\n")
        WARTEN()
        print("[Davon kennt dein Charakter derzeit zwei: Feuerball und Blitz.\n")
        WARTEN()
        print(f"[Hier ein bisschen Info dazu:]{Fore.YELLOW}\n")
        WARTEN()
        for zauber in [blitz, feuerball]:
            print(f"{Fore.YELLOW}Name des Zaubers:    {zauber.name}\n")
            PAUSE()
            print(f"Kontrolle:            {zauber.kontrolle}")
            PAUSE()
            print(f"Aufwand(Aktion):      {zauber.aufwand_aktion}")
            PAUSE()
            print(f"Aufwand(Zauberkraft): {zauber.aufwand_zauberkraft}")
            PAUSE()
            print(f"Tödlichkeit:          {zauber.toedlichkeit}")
            PAUSE()
            print(f"Schadensart:          {zauber.schadensArt}")
            PAUSE()
            print(f"\n{Fore.WHITE}")
        WARTEN()
        print(f"{Fore.WHITE}[Außerdem kannst du Zauberangriffe mit zusätzlicher Zauberkraft verstärken - "
              f"das funktioniert genau wie Ausdauer bei gewöhnlichen Angriffen.]\n")
        WARTEN()
        print(f"{Fore.WHITE}[Natürlich musst dabei auch die Gefahr der Zauberdetonation im Hinterkopf behalten.]\n")
        WARTEN()
        print(f"[Sag hinterher nicht, man hätte dich nicht gewarnt. ;) ]\n")
        WARTEN()
    print(f"[Und damit legen wir dann los.]{Fore.GREEN}\n")
    while True:
        befehl = input("Gib bitte \"weiter\" ein, um fortzufahren.\n > ").lower()
        if befehl == "weiter":
            return
        elif "raushier" in befehl:
            programmende()
        else:
            hoppla()
