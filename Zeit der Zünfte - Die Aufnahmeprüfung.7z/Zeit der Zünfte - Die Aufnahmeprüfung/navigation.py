"""
Diese Datei steuert die Navigation der begehbaren Räume, solange die Spielschleife läuft
und das Abenteuer nicht vorbei ist.
"""

from steuerelemente import *
from start import *
from charaktererstellung import *
from ostraum import *
from westraum import *
from nordraum import *
from fackel_und_tuer_proben import *


# Diese Funktion steuert die eigentliche Navigation während des Abenteuers.

def richtungswechsel():
    while True:
        frage = input("Wo willst du hin? (Optionen: Norden, Osten, Süden, Westen)\n > ").lower()
        if "nord" in frage or "ost" in frage or "süd" in frage or "west" in frage:
            return frage
        elif "raushier" in frage:
            frage = programmende()
            if not frage:
                continue
        else:
            hoppla()


def navigation_spielstart():
    if not spiel.neues_spiel:
        start = spielstart()
        WARTEN()
        if start:
            steuerung()
            WARTEN()
    else:
        spiel.neues_spiel = False
        WARTEN()
    charakter_name()
    WARTEN()
    charakter_geschlecht()
    WARTEN()
    charakter_rasse()
    WARTEN()
    charakter_karriere()
    WARTEN()
    charakter_inventar()
    WARTEN()
    charakter_anzeigen()
    WARTEN()
    return


def navigation_vorraum():
    vorraum_1()
    WARTEN()
    vorraum_2()
    WARTEN()
    vorraum_3()
    WARTEN()
    vorraum_4()
    WARTEN()
    return


def navigation_nordraum():
    while not spiel.epilog:
        nordraum_1()
        while not spiel.epilog:
            frage = frage_nordraum()
            if "süd" in frage:
                print("Du verlässt dem nördlichen raum.\n")
                WARTEN()
                return
            else:
                nordraum_2()
                continue

        else:
            break
    else:
        return


def navigation_ostraum():
    while not spiel.epilog:
        if not spiel.gelbe_tuer:
            print("Du stehst vor einer Tür, Gesicht gen Ost.\n")
            WARTEN()
            print("Sie ist gelb, wenn auch etwas durch die Zeit verblichen, und wirkt oft benutzt.\n")
            WARTEN()
            probe = gelbe_tuer()
            if probe:
                spiel.gelbe_tuer = True
                continue
            else:
                break
        else:
            ostraum_1()
            aktion = richtungswechsel()
            if "nord" not in aktion and "west" not in aktion:
                print("Da kannst du von hier aus leider nicht hingehen.\n")
                WARTEN()
                continue
            elif "west" in aktion:
                print("Du verlässt den östlichen Raum.\n")
                WARTEN()
                return
            else:
                ostraum_2()

    else:
        return


def navigation_westraum():
    while not spiel.epilog:
        westraum_1()
        while not spiel.epilog:
            frage = westraum_2()
            if "ost" in frage:
                print("Du verlässt den westlichen Raum.\n")
                WARTEN()
                return
            elif "grau" in frage:
                westraum_grau()
                WARTEN()
                continue
            elif "blau" in frage:
                westraum_blau()
                WARTEN()
                continue
            elif "rot" in frage:
                westraum_rot()
                WARTEN()
                continue
            elif "grün" in frage:
                westraum_gruen()
                WARTEN()
                continue
            else:
                westraum_gelb()
                WARTEN()
                continue
        else:
            return
    else:
        return
