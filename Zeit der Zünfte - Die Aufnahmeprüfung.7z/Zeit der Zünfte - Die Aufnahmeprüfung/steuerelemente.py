"""
Diese Datei steuert die Variablen, die über den Spielverlauf bestimmen sowie einige wiederkehrende Funktionen.
"""

import copy
import time


# Diese Funktion lässt ein bisschen Zeit zwischen dem Einblenden von Text vergehen.

def WARTEN():
    time.sleep(0.8)


def PAUSE():
    time.sleep(0.35)

# Diese Funktion wird ausgelöst, wenn der Spieler etwas eintippt bzw. einen Befehl gibt,
# der vom Spiel nicht vorgesehen war.


def hoppla():
    print("Hoppla! Irgendwas ist bei deiner Eingabe schiefgegangen. Versuch es bitte noch einmal.\n")
    WARTEN()
    return


# gelbe_tuer/massive_tuer - True steht für "entsperrt", sonst ist die Tür versperrt.
# gelbe_tuer_knacken/massive_tuer_knacken - Hat der Charakter versucht, das Schloss zu knacken? True: Versagen.
# epilog - das Ende des Abenteuers. Wenn sie auf "True" schaltet, folgt die Auswertung.
# strafpunkte - selbsterklärend. Die Variable zählt die Strafpunkte, die das Ende beeinflussen.
# ostraum/westraum/nordraum - die Variable schaut, ob der Charakter den Gegenstand im jeweiligen Raum bekommen hat.
# falle_ost/falle_west - Die Variable schaut, ob die Falle im jeweiligen Raum ausgelöst wurde.
# loot - Gegenstände, die der Charakter bekommen kann. Die Questgegenstände werden aus diesem Pool genommen.


# Die Klasse Spielstand steuert die Variablen, die bestimmte Ereignisse im Spiel regeln.


class KeineZahlError(ValueError):
    pass


class Spielstand:
    def __init__(self, gelbe_tuer, gelbe_tuer_knacken, massive_tuer, massive_tuer_knacken, epilog, strafpunkte,
                 quest_gegenstaende, ostraum, westraum, nordraum, falle_ost, falle_west, falle_nord, loot, neues_spiel,
                 kampf, kampf_zaehler):
        self.gelbe_tuer = gelbe_tuer
        self.gelbe_tuer_knacken = gelbe_tuer_knacken
        self.massive_tuer_knacken = massive_tuer_knacken
        self.massive_tuer = massive_tuer
        self.epilog = epilog
        self.strafpunkte = strafpunkte
        self.quest_gegenstaende = quest_gegenstaende
        self.ostraum = ostraum
        self.westraum = westraum
        self.nordraum = nordraum
        self.falle_ost = falle_ost
        self.falle_west = falle_west
        self.falle_nord = falle_nord
        self.loot = loot
        self.neues_spiel = neues_spiel
        self.kampf = kampf
        self.kampf_zaehler = kampf_zaehler
        self.start = copy.deepcopy(self.__dict__)

    def zuruecksetzen(self):
        self.__dict__ = copy.deepcopy(self.start)


spiel = Spielstand(False, False, False, False, False,
                   0, [], False, False, False, False,
                   False, False,
                   ["dekorierter Handspiegel", "leuchtendes Goldstück", "kleines Zauberbuch",
                    "dekorative Silberbrosche", "feuerrote Blume", "Sanduhr aus Malachit", "Kompass aus Zwergeneisen",
                    "ein leuchtendes Stück Quartz", "Kerzenhalter aus Marmor", "bunte Greif-Feder",
                    "kleine verzierte Laterne", "mit Perlen verzierte Spieluhr", "Ring aus Silber",
                    "Blitz in Kristallflasche", "schön bemalter Hölzlöffel", "Glasglocke", "bemalte Holzflöte",
                    "Rubin in Form einer Eichel", "versiegelte Schriftrolle", "meisterhaft genähtes Kuscheltier",
                    "mit Edelsteinen verzierter Krug"], False, False, 0)
