"""Diese Datei speichert die Informationen über den Spielercharakter,
etwa Charakteristiken (Eigenschaften), Fortschritt und das eigentliche Würfeln."""

import random
import copy
from colorama import Fore
from steuerelemente import *
from zauber import *
from waffen import *


class Charakter:
    basis_verteidigung = 10

    def __init__(self, name, geschlecht, rasse, kraft, geschick, koerperbau, grips, empathie, magie, kontrollwuerfel,
                 inventar, willen, reflexe, zauber, mechanik, karriere, streichhoelzer, gegenstaende, ausdauer,
                 max_zauberkraft, stufe, verteidigung, max_lebenskraft, zauberkraft, lebenskraft, max_ausdauer,
                 bewaffnung, schadensbonus, aktionen, angriffsbonus, malus_erschoepfung, kampfstilbonus,
                 kampfstilmalus):
        self.name = name
        self.geschlecht = geschlecht
        self.rasse = rasse
        self.kraft = kraft
        self.geschick = geschick
        self.koerperbau = koerperbau
        self.grips = grips
        self.empathie = empathie
        self.magie = magie
        self.kontrollwuerfel = kontrollwuerfel
        self.inventar = inventar
        self.willen = willen
        self.reflexe = self.geschick
        self.zauber = zauber
        self.mechanik = mechanik
        self.karriere = karriere
        self.streichhoelzer = streichhoelzer
        self.gegenstaende = gegenstaende
        self.stufe = stufe
        self.max_ausdauer = self.kraft + self.koerperbau + self.stufe
        self.ausdauer = max_ausdauer
        self.max_zauberkraft = self.empathie + self.stufe
        self.kampfstilbonus = kampfstilbonus
        self.kampfstilmalus = kampfstilmalus
        self.verteidigung = Charakter.basis_verteidigung + self.reflexe - self.kampfstilmalus
        self.max_lebenskraft = self.koerperbau + self.stufe
        self.zauberkraft = self.max_zauberkraft
        self.lebenskraft = self.max_lebenskraft
        self.bewaffnung = bewaffnung
        self.schadensbonus = schadensbonus
        self.aktionen = aktionen
        self.angriffsbonus = angriffsbonus
        self.malus_erschoepfung = malus_erschoepfung
        self.start = copy.deepcopy(self.__dict__)
        pass

    def wuerfeln_w12(self):
        wurf_w12 = random.randint(1, 12)
        print(f"{Fore.WHITE}[Wurf: {wurf_w12}]{Fore.GREEN}\n")
        return wurf_w12

    def wuerfeln_w6(self):
        wurf_w6 = random.randint(1, 6)
        print(f"{Fore.WHITE}[Wurf: {wurf_w6}]{Fore.GREEN}\n")
        return wurf_w6

    def angriff_vorsichtig(self):
        self.kampfstilbonus -= 2
        self.kampfstilmalus += 2
        WARTEN()
        return

    def angriff_aggressiv(self):
        self.kampfstilbonus += 2
        self.schadensbonus += 2
        self.kampfstilmalus -= 4
        WARTEN()
        return
        
    def angreifen_schnell(self):
        WARTEN()
        self.kampfstilbonus -= 4
        self.kampfstilmalus -= 4
        WARTEN()
        return
    
    def schaden(self, ziel):
        print(f"{Fore.BLUE}[ERFOLG]{Fore.GREEN} \n")
        WARTEN()
        print(f"{Fore.WHITE}[Tödlichkeit der Waffe ({self.bewaffnung.name}): "
              f"{self.bewaffnung.toedlichkeit}]{Fore.GREEN}\n")
        WARTEN()
        print(f"{Fore.WHITE}[Schaden: {self.bewaffnung.schaden}]{Fore.GREEN}\n")
        WARTEN()
        print(f"{Fore.WHITE}[Schadensbonus (Kraft): {self.kraft // 2}]{Fore.GREEN}\n")
        WARTEN()
        gesamtschaden = self.bewaffnung.schaden + self.schadensbonus + self.kraft//2
        print(f"{Fore.WHITE}[Schaden (gesamt): {gesamtschaden}]{Fore.GREEN}\n")
        WARTEN()
        ziel.lebenskraft -= gesamtschaden
        if ziel == protagonist:
            print(f"{Fore.WHITE}[Lebenskraft ({ziel.name})]: {ziel.lebenskraft}/{ziel.max_lebenskraft}]"
                  f"{Fore.GREEN} \n")
        else:
            print(f"{Fore.WHITE}[Lebenskraft ({ziel.rasse})]: {ziel.lebenskraft}/{ziel.max_lebenskraft}]"
                  f"{Fore.GREEN} \n")
        WARTEN()
        if ziel.lebenskraft <= 0:
            print(f"{Fore.WHITE}[{ziel.name} wurde besiegt.]{Fore.GREEN}\n")
            WARTEN()
        return

    def zuruecksetzen(self):
        self.__dict__ = copy.deepcopy(self.start)

    def aktualisieren(self):
        pass
    
    
class Spieler (Charakter):
    def __init__(self, name, geschlecht, rasse, kraft, geschick, koerperbau, grips, empathie, magie, kontrollwuerfel,
                 inventar, willen, reflexe, zauber, mechanik, karriere, streichhoelzer, gegenstaende, ausdauer,
                 max_zauberkraft, stufe, verteidigung, max_lebenskraft, zauberkraft, lebenskraft, max_ausdauer,
                 bewaffnung, schadensbonus, aktionen, angriffsbonus, malus_erschoepfung, kampfstilbonus,
                 kampfstilmalus):
        super().__init__(name, geschlecht, rasse, kraft, geschick, koerperbau, grips, empathie, magie, kontrollwuerfel,
                         inventar, willen, reflexe, zauber, mechanik, karriere, streichhoelzer, gegenstaende, ausdauer,
                         max_zauberkraft, stufe, verteidigung, max_lebenskraft, zauberkraft, lebenskraft, max_ausdauer,
                         bewaffnung, schadensbonus, aktionen, angriffsbonus, malus_erschoepfung, kampfstilbonus,
                         kampfstilmalus)

    def kontrollwurf(self, Zauber):
        ziel = Zauber.kontrolle
        self.zauberkraft -= Zauber.aufwand_zauberkraft
        if Zauber.aufwand_zauberkraft > 0:
            print(f"{Fore.WHITE}[Deine Zauberkraft: {self.zauberkraft}/{self.max_zauberkraft}]\n")
            WARTEN()
        erfolge = []
        erfolgswert = Zauber.erfolgswert
        nat_1 = 0
        for element in range(self.kontrollwuerfel):
            wurf_w6 = self.wuerfeln_w6()
            WARTEN()
            if wurf_w6 >= erfolgswert:
                erfolge.append(wurf_w6)
            if wurf_w6 == 1:
                nat_1 += 1
            if wurf_w6 == 6:
                nat_1 -= 1
        WARTEN()
        if nat_1 > len(erfolge) and ziel > 1:
            print("Du versuchst, zu zaubern, kannst die magischen Ströme aber nicht so gut beherrschen, "
                  "wie du gedacht hast.\n")
            WARTEN()
            print("Du verlierst die Kontrolle, es kommt zu einer Zauberdetonation.\n")
            WARTEN()
            print("Wirbel aus ungebändigter blau-weißer Energie kreisen um dich herum und explodieren schließlich mit "
                  "einem lauten Knall.\n")
            spiel.strafpunkte += 1
            schaden = 0
            for element in range(2):
                wurf = self.wuerfeln_w6()
                schaden += wurf
            self.lebenskraft -= schaden
            print(f"{Fore.WHITE}[Schaden durch Zauberdetonation: {schaden}]{Fore.GREEN}\n")
            WARTEN()
            print(f"{Fore.WHITE}[Deine Lebenskraft: {self.lebenskraft}/{self.max_lebenskraft}]{Fore.GREEN}\n")
            WARTEN()
            if self.lebenskraft <= 0:
                spiel.epilog = True
            return False
        else:
            print(f"{Fore.WHITE}[Benötigte Erfolge: {len(erfolge)}/{ziel}]\n")
            WARTEN()
            if len(erfolge) >= ziel:
                print(f"[Du konntest genug Zauberkraft fokussieren, um den Zauber zu wirken.]{Fore.GREEN}\n")
                return True
            else:
                print(f"[Du konntest nicht genug Zauberkraft aufbringen, um den Zauber zu wirken.]{Fore.GREEN}\n")
                return False

    def geschickWurf(self, ziel):
        wurf = self.wuerfeln_w12()
        ergebnis = self.geschick + wurf
        print(f"{Fore.WHITE}[Dein Gesamtwurf: {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return False

    def reflexWurf(self, ziel):
        wurf = self.wuerfeln_w12()
        ergebnis = self.geschick + wurf + self.reflexe
        print(f"{Fore.WHITE}[Dein Gesamtwurf: {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return False

    def gripsWurf(self, ziel):
        spiel.strafpunkte += 1
        print("Du steht eine Weile da und denkst nach...\n")
        wurf = self.wuerfeln_w12()
        ergebnis = self.grips + wurf
        print(f"{Fore.WHITE}[Dein Gesamtwurf: {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            print("Dann fällt es dir ein:\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            print("Doch du kommst einfach nicht drauf. Jetzt kannst du nur noch raten.\n")
            WARTEN()
            return False

    def willensWurf(self, ziel):
        wurf = self.wuerfeln_w12()
        ergebnis = self.empathie + wurf + self.willen
        print(f"{Fore.WHITE}[Dein Gesamtwurf: {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return False

    def kampf(self, ziel):
        wurf = self.wuerfeln_w12()
        ergebnis = self.kraft + wurf
        print(f"{Fore.WHITE}[Dein Gesamtwurf: {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return False

    def mechanikWurf(self, ziel):
        wurf = self.wuerfeln_w12()
        ergebnis = self.geschick + wurf + self.mechanik
        print(f"{Fore.WHITE}[Dein Gesamtwurf: {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return False

    def wort_fuer_dungeon(self):
        if protagonist.rasse in ["Elf", "Dunkelelf"]:
            return "Dánesane"
        elif protagonist.rasse == "Kurzling":
            return "Dainessen"
        elif protagonist.rasse == "Mensch":
            return "Dungeon"
        elif protagonist.rasse == "Ork":
            return "d'nsh'n"
        elif protagonist.rasse == "Zwerg":
            return "Dönnschn"
        else:
            return "Du-huáa"

    def handeln(self, ziel):
        print(f"{Fore.WHITE}[Du bist dran.] {Fore.GREEN}\n")
        WARTEN()
        while self.aktionen > 0:
            while True:
                print(f"{Fore.WHITE}[Verbleibende Aktionen: {self.aktionen}]\n")
                WARTEN()
                if ziel.lebenskraft <= 0:
                    befehl = "zug"
                else:
                    befehl = input(f"{Fore.GREEN}Was willst du tun? (Optionen: angreifen, zaubern, ausweichen, "
                                   f"Zug beenden) \n > ").lower()
                if "greif" in befehl:
                    WARTEN()
                    self.angreifen(ziel)
                    break
                elif "zauber" in befehl:
                    self.kampf_zaubern(ziel)
                    break
                elif "weich" in befehl:
                    if self.aktionen >= 2:
                        self.aktionen = 0
                        self.verteidigung += 2
                        self.ausdauer -= 1
                        WARTEN()
                        print(f"{Fore.WHITE}[Du versuchst, dem Angriff des Gegners auszuweichen.]{Fore.GREEN}\n")
                        WARTEN()
                        print(f"{Fore.WHITE}[Bonus (Verteidigung): 2]{Fore.GREEN}\n")
                        WARTEN()
                        print(f"{Fore.WHITE}[Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
                        WARTEN()
                        return
                    else:
                        WARTEN()
                        print(f"{Fore.WHITE}[Du hast in dieser Runde bereits gehandelt, "
                              f"daher kannst du nicht mehr ausweichen. Bitte wähle eine andere Aktion.]{Fore.GREEN}\n")
                        WARTEN()
                        continue
                elif "zug" in befehl:
                    WARTEN()
                    print(f"{Fore.WHITE}[Du beendest deinen Zug.]{Fore.GREEN}\n")
                    WARTEN()
                    if self.aktionen == 2:
                        if self.ausdauer < self.max_ausdauer:
                            self.ausdauer += 1
                    print(f"{Fore.WHITE}[Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
                    WARTEN()
                    self.aktionen = 0
                    return
                else:
                    WARTEN()
                    print(f"{Fore.WHITE}[hoppla! An diesem Befehl stimmt etwas nicht. Versuch's bitte noch mal!]"
                          f"{Fore.GREEN}\n")
                    WARTEN()
                    continue
        else:
            print(f"{Fore.WHITE}[Du kannst in diesem Zug keine Aktionen mehr ausführen.]{Fore.GREEN}\n")
            WARTEN()
            return

    def angreifen(self, ziel):
        while True:
            if self.aktionen >= 2:
                befehl = input("Wie willst du angreifen? (Optionen: ruhig, aggressiv, vorsichtig) \n > ").lower()
    
                if "ruh" in befehl:
                    self.angriff(ziel)
                    break
                elif "aggr" in befehl:
                    self.angriff_aggressiv()
                    self.angriff(ziel)
                    break
                elif "vor" in befehl:
                    self.angriff_vorsichtig()
                    self.angriff(ziel)
                    break
                else:
                    hoppla()
            else:
                print(f"{Fore.WHITE}[Du hast bereits einen Kampfstil für diese Runde verwendet. "
                      f"Dieser bleibt bis zur nächsten Runde erhalten.]{Fore.GREEN}\n")
                WARTEN()
                self.angriff(ziel)
                break
        return
    
    def angriff(self, ziel):
        if self.aktionen < 2:
            self.angriffsmalus = 5
        else:
            self.angriffsmalus = 0
        if self.ausdauer <= 0:
            WARTEN()
            print(f"{Fore.WHITE}[Du bist erschöpft, kannst aber aus letzter Kraft noch weiterkämpfen.]{Fore.GREEN}\n")
            WARTEN()
        self.angriff_verstaerken()  # Frage nach Angriffsverstärkung
        self.aktionen -= 1
        wuerfelwurf = self.wuerfeln_w12()
        angriffswurf = ((wuerfelwurf + self.geschick + self.angriffsbonus + self.stufe + self.kampfstilbonus)
                        - self.angriffsmalus - self.bewaffnung.angriffsmalus - self.malus_erschoepfung)
        if angriffswurf <= 0:   # Damit keine Minuswerte bei Würfen entstehen.
            angriffswurf = 1
        angriffsmalus_gesamt = self.angriffsmalus + self.bewaffnung.angriffsmalus + self.malus_erschoepfung
        verteidigung_ziel = (ziel.verteidigung - ziel.malus_erschoepfung - ziel.bewaffnung.verteidigungsmalus
                             - ziel.kampfstilmalus)
        self.ausdauer -= 1 + self.bewaffnung.belastung
        print(f"{Fore.WHITE}[Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
        WARTEN()
        print(f"{Fore.WHITE}[Angriffsbonus: {self.geschick + self.angriffsbonus + self.stufe + self.kampfstilbonus}"
              f"]{Fore.GREEN} \n")
        WARTEN()
        if self.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (Folgeaktion): -{self.angriffsmalus}]{Fore.GREEN}\n")
            WARTEN()
        if self.bewaffnung.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (Waffe): {self.bewaffnung.angriffsmalus}]\n")
        if self.ausdauer <= 0:
            self.malus_erschoepfung = 4
            print(f"{Fore.WHITE}[Angriffsmalus (Erschöpfung): -{self.malus_erschoepfung}]{Fore.GREEN}\n")
            WARTEN()
        if self.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (gesamt): -{angriffsmalus_gesamt}]{Fore.GREEN}\n")
            WARTEN()
        else:
            self.malus_erschoepfung = 0
        print(f"{Fore.WHITE}[Angriffswurf: {angriffswurf}]{Fore.GREEN} \n")
        WARTEN()
        if ziel.ausdauer <= 0:
            ziel.malus_erschoepfung = 4
        print(f"{Fore.WHITE}[Verteidigung ({ziel.name}): {verteidigung_ziel}] {Fore.GREEN}\n")
        WARTEN()
        if angriffswurf >= verteidigung_ziel or wuerfelwurf == 12:  # Ab hier die Erfolgsberechnung
            self.schaden(ziel)
            return
        elif wuerfelwurf == 1:
            print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG]{Fore.GREEN}\n")
            WARTEN()
            print(f"{Fore.WHITE}[Dein Angriff geht kolossal daneben.]{Fore.GREEN}\n")
            WARTEN()
            self.ausdauer -= 1
            print(f"{Fore.WHITE}[Deine Ausdauer: {self.ausdauer}/{self.max_ausdauer}]{Fore.GREEN}\n")
            WARTEN()
            return
        elif angriffswurf < verteidigung_ziel - 1:
            print(f"{Fore.RED}[MISSERFOLG] {Fore.GREEN} \n")
            WARTEN()
            print(f"{Fore.WHITE}[Dein Angriff verfehlt den Gegner.]{Fore.GREEN}\n")
            WARTEN()
            return
        else:
            ziel.ausdauer -= 1
            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN} \n")
            WARTEN()
            print(f"{Fore.WHITE}[Dein Angriff verfehlt den Gegner nur knapp.]{Fore.GREEN}\n")
            WARTEN()
            return
    
    def angriff_verstaerken(self):
        while True:
            befehl1 = input(f"{Fore.GREEN}Willst du deinen Angriff mit mehr Krafteinsatz verstärken? "
                            "(Optionen: Ja, Nein)\n > ").lower()
            if "ja" in befehl1:
                WARTEN()
                while True:
                    befehl2 = input(f"Wie viel Ausdauer willst du einsetzen ({self.ausdauer} verfügbar)? "
                                    f"Bitte nur ganze Zahlen eingeben.\n > ").lower()
                    try:
                        befehl2 = int(befehl2)
                        if befehl2 < 0:
                            WARTEN()
                            raise KeineZahlError
                        if int(befehl2) > self.ausdauer:
                            WARTEN()
                            print(f"{Fore.WHITE}[So viel Ausdauer hast du derzeit leider nicht zur Verfügung. "
                                  f"Versuch's bitte noch einmal.]{Fore.GREEN}\n")
                            WARTEN()
                            continue
                    except KeineZahlError:
                        print(f"{Fore.WHITE}[Netter Versuch! Aber so kriegst du deine Ausdauer nicht zurück! "
                              f"Versuch's bitte noch einmal.]{Fore.GREEN}\n")
                        WARTEN()
                        continue
                    except ValueError:
                        print(f"{Fore.WHITE}[Das ist keine Zahl. Versuch's bitte noch einmal.]{Fore.GREEN}\n")
                        WARTEN()
                        continue
                    else:
                        WARTEN()
                        self.schadensbonus += int(befehl2)
                        self.ausdauer -= int(befehl2)
                        print(f"{Fore.WHITE}[Schadensbonus (Ausdauer): {befehl2}]{Fore.GREEN}\n")
                        WARTEN()
                        print(f"{Fore.WHITE}[Schadensbonus (gesamt): {self.schadensbonus}]{Fore.GREEN}\n")
                        WARTEN()
                        return
            elif "nein" in befehl1:
                WARTEN()
                return
            else:
                hoppla()
                WARTEN()
       
    def kampf_zaubern(self, ziel):
        zauber = self.zauber_waehlen()                              # Welchen Zauber einsetzen?
        if self.zauberkraft < zauber.aufwand_zauberkraft:
            print(f"{Fore.WHITE}[Leider hast du nicht genug Zauberkraft zur Verfügung, um diesen Zauber zu wirken.]\n")
            WARTEN()
            print("Bitte wähle eine andere Aktion.\n")
            WARTEN()
            return
        self.aktionen -= 1
        zauber_verstaerkung = self.zauber_verstaerken()             # Mit Zauberkraft verstärken?
        print(f"{Fore.WHITE}[Zauberkraft-Aufwand ({zauber.name}): {zauber.aufwand_zauberkraft}]\n")
        WARTEN()
        if zauber_verstaerkung > 0:
            self.zauberkraft -= zauber_verstaerkung
            print(f"[Aufwand (Zauberverstärkung): {zauber_verstaerkung}]\n")
            WARTEN()
            print(f"[Deine Zauberkraft: {self.zauberkraft}/{self.max_zauberkraft}]{Fore.GREEN}\n")
            WARTEN()                                                                             # Ende der Verstärkung
        print(f"[Aktionsaufwand ({zauber.name}): {zauber.aufwand_aktion}]\n")
        WARTEN()
        probe = self.kontrollwurf(zauber)                    # Kontrollwurf
        if probe:
            print(f"{Fore.WHITE}[Tödlichkeit des Zaubers: {zauber.toedlichkeit}]\n")  # Formel für den Schaden
            WARTEN()
            schaden = zauber.schaden
            gesamtschaden = schaden + zauber_verstaerkung
            print(f"[Gesamtschaden ({zauber.name}): {gesamtschaden}]\n")
            WARTEN()
            rettungswurf = ziel.reflexWurf(14)
            print(f"{Fore.WHITE}[Reflexe ({ziel.rasse}): {ziel.reflexe}]{Fore.GREEN}\n")
            WARTEN()
            if rettungswurf:
                ziel.ausdauer -= 1
                halber_schaden = int(gesamtschaden / 2)
                ziel.lebenskraft -= halber_schaden
                print(f"{Fore.WHITE}[Mit einem unglaublichen Zusammenspiel von Glück und Reflexen "
                      f"schafft es {ziel.name}, deinem Zauber im allerletzten Moment teilweise auszuweichen.]\n")
                WARTEN()
                print(f"[{ziel.name} kann nimmt nur den halben Schaden ({halber_schaden} Punkte "
                      f"durch {zauber.schadensArt}).]\n")

                print(f"[Lebenskraft ({ziel.rasse}): {ziel.lebenskraft}/{ziel.max_lebenskraft}]\n")
                WARTEN()
                return
            else:
                ziel.lebenskraft -= gesamtschaden
                print(f"[{ziel.name} versucht, deinem Zauber ({zauber.name}) auszuweichen, "
                      f"ist aber zu langsam und nimmt vollen Schaden.]\n")
                WARTEN()
                print(f"[Dein Zauber ({zauber.name}) trifft {ziel.name} und richtet {gesamtschaden} "
                      f"Punkte Schaden durch {zauber.schadensArt} an.]\n")
                WARTEN()
                print(f"[Lebenskraft ({ziel.name}): {ziel.lebenskraft}/{ziel.max_lebenskraft}]\n")
                WARTEN()
                return
        else:
            print("Dein Zauberangriff schlägt fehl.\n")
            WARTEN()
            return

    def zauber_schaden(self, zauber):
        zauberschaden = 0
        for element in zauber.schaden:
            zauberschaden += element
        return zauberschaden

    def zauber_waehlen(self):
        zauber_gefunden = False
        while not zauber_gefunden:
            befehl = input("Wähle den Zauber, den wirken willst.\n > ")
            WARTEN()
            for zauber in self.zauber:
                if befehl.lower() == zauber.name.lower():
                    WARTEN()
                    print(f"Du versuchst, {zauber.name} zu wirken.\n")
                    WARTEN()
                    zauber_gefunden = True
                    return zauber
            if not zauber_gefunden:
                print("Hoppla! Wie es scheint, ist dir ein solcher Zauber nicht bekannt.\n")
                    
    def zauber_verstaerken(self):
        while True:
            befehl1 = input("Willst du den Zauber mit zusätzlicher Zauberkraft verstärken?\n > ").lower()
            if "ja" in befehl1:
                while True:
                    try:
                        befehl2 = int(input(f"Wie viel Zauberkraft willst du einsetzen "
                                            f"({self.zauberkraft} verfügbar)?\n > "))
                    except TypeError:
                        print("Das ist keine (ganze) Zahl. Versuch's bitte noch einmal.\n")
                        WARTEN()
                        continue
                    else:
                        if befehl2 < 0:
                            WARTEN()
                            print("Netter Versuch! Aber so kriegst du deine Zauberkraft nicht zurück! "
                                  "Versuch's bitte noch einmal.\n")
                            WARTEN()
                        elif befehl2 > self.zauberkraft:
                            WARTEN()
                            print("So viel Zauberkraft hast du derzeit leider nicht zur Verfügung. "
                                  "Versuch's bitte noch einmal.\n")
                            WARTEN()
                        else:
                            WARTEN()
                            return befehl2
            elif "nein" in befehl1:
                return 0
            else:
                hoppla()
    

class Gegner(Charakter):
    def __init__(self, name, geschlecht, rasse, kraft, geschick, koerperbau, grips, empathie, magie, kontrollwuerfel,
                 inventar, willen, reflexe, zauber, mechanik, karriere, streichhoelzer, gegenstaende, ausdauer,
                 max_zauberkraft, stufe, verteidigung, max_lebenskraft, zauberkraft, lebenskraft, max_ausdauer,
                 bewaffnung, schadensbonus, aktionen, angriffsbonus, malus_erschoepfung, kampfstilbonus,
                 kampfstilmalus):
        super().__init__(name, geschlecht, rasse, kraft, geschick, koerperbau, grips, empathie, magie, kontrollwuerfel,
                         inventar, willen, reflexe, zauber, mechanik, karriere, streichhoelzer, gegenstaende, ausdauer,
                         max_zauberkraft, stufe, verteidigung, max_lebenskraft, zauberkraft, lebenskraft, max_ausdauer,
                         bewaffnung, schadensbonus, aktionen, angriffsbonus, malus_erschoepfung,
                         kampfstilbonus, kampfstilmalus)

    def reflexWurf(self, ziel):
        wurf = self.wuerfeln_w12()
        ergebnis = self.geschick + wurf + self.reflexe
        print(f"{Fore.WHITE}[Gesamtwurf ({self.rasse}): {ergebnis}]{Fore.GREEN}\n")
        WARTEN()
        if ergebnis >= ziel or wurf == 12:
            if wurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            print(f"{Fore.BLUE}[ERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return True
        else:
            print(f"{Fore.RED}[MISSERFOLG!]{Fore.GREEN}\n")
            WARTEN()
            return False

    def handeln(self, ziel):
        print(f"{Fore.WHITE}[{self.name} ist dran.] {Fore.GREEN}\n")
        WARTEN()
        while self.aktionen > 0:
            while True:
                print(f"{Fore.WHITE}[Verbleibende Aktionen: {self.aktionen}]{Fore.GREEN}\n")
                WARTEN()
                if ziel.lebenskraft <= 0:
                    befehl = 5                       # Willkürliche Zahl, die den Zug beendet.
                else:
                    befehl = random.randint(1, 20)
                if self.ausdauer < 0:
                    befehl = random.randint(1, 6)
                    if befehl in range(1, 5):
                        befehl = 17                  # willkürliche Zahl, aber sie fällt in den Erholungsbereich.
                if befehl in range(1, 11):
                    WARTEN()
                    print(f"{Fore.WHITE}[{self.name} greift an.]{Fore.GREEN}\n")
                    WARTEN()
                    self.angreifen(ziel)
                    while self.aktionen > 0:
                        break
                    else:
                        print(f"{Fore.WHITE}[{self.name} beendet den Zug.]{Fore.GREEN}\n")
                        WARTEN()
                        return
                elif befehl in range(11, 15):
                    if self.aktionen >= 2:
                        self.aktionen = 0
                        self.verteidigung += 2
                        self.ausdauer -= 1
                        WARTEN()
                        print(f"{Fore.WHITE}[Der Gegner versucht, dir auszuweichen.]{Fore.GREEN}\n")
                        WARTEN()
                        return
                    else:
                        continue
                elif befehl in range(15, 20):
                    if self.ausdauer >= 0:
                        continue
                    else:
                        WARTEN()
                        print(f"{Fore.WHITE}[{self.name} setzt den Zug aus, um sich zu erholen.]{Fore.GREEN}\n")
                        WARTEN()
                        if self.aktionen == 2:
                            if self.ausdauer < self.max_ausdauer:
                                self.ausdauer += 1
                        self.aktionen = 0
                        return
                else:
                    continue
        else:
            print(f"{Fore.WHITE}[{self.name} beendet den Zug.]{Fore.GREEN}\n")
            WARTEN()
            return

    def angreifen(self, ziel):
        ziel = protagonist
        while self.aktionen > 0:
            befehl = random.randint(1, 3)
            if self.aktionen >= 2:
                if befehl == 1:
                    self.angriff(ziel)
                    continue
                elif befehl == 2:
                    print(f"{Fore.WHITE}[{self.name} geht aggressiv vor.]{Fore.GREEN}\n")
                    self.angriff_aggressiv()
                    self.angriff(ziel)
                    continue
                else:
                    print(f"{Fore.WHITE}[{self.name} achtet auf die eigene Verteidigung.]{Fore.GREEN}\n")
                    self.angriff_vorsichtig()
                    self.angriff(ziel)
                    continue
            else:
                self.angriff(ziel)
                WARTEN()
        else:
            return

    def angriff(self, ziel):
        ziel = protagonist
        if self.aktionen < 2:
            self.angriffsmalus = 5
        else:
            self.angriffsmalus = 0
        if self.ausdauer <= 0:
            WARTEN()
            print(f"{Fore.WHITE}[{self.name} ist erschöpft, kann aber aber noch weiterkämpfen.]{Fore.GREEN}\n")
            WARTEN()
        self.aktionen -= 1
        wuerfelwurf = self.wuerfeln_w12()
        angriffswurf = ((wuerfelwurf + self.geschick + self.angriffsbonus + self.stufe + self.kampfstilbonus)
                        - self.angriffsmalus - self.bewaffnung.angriffsmalus - self.malus_erschoepfung)
        if angriffswurf <= 0:       # Damit keine Minuswerte bei Würfen entstehen.
            angriffswurf = 1
        angriffsmalus_gesamt = self.angriffsmalus + self.bewaffnung.angriffsmalus + self.malus_erschoepfung
        verteidigung_ziel = (ziel.verteidigung - ziel.malus_erschoepfung - ziel.bewaffnung.verteidigungsmalus
                             - ziel.kampfstilmalus)
        self.ausdauer -= 1 + self.bewaffnung.belastung
        if self.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (Folgeaktion): -{self.angriffsmalus}]{Fore.GREEN}\n")
            WARTEN()
        if self.bewaffnung.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (Waffe): {self.bewaffnung.angriffsmalus}]\n")
        if self.ausdauer <= 0:
            self.malus_erschoepfung = 4
            print(f"{Fore.WHITE}[Angriffsmalus (Erschöpfung): -{self.malus_erschoepfung}]{Fore.GREEN}\n")
            WARTEN()
        if self.angriffsmalus > 0:
            print(f"{Fore.WHITE}[Angriffsmalus (gesamt): -{angriffsmalus_gesamt}]{Fore.GREEN}\n")
            WARTEN()
        else:
            self.malus_erschoepfung = 0
        print(f"{Fore.WHITE}[Angriffswurf: {angriffswurf}]{Fore.GREEN} \n")
        WARTEN()
        if ziel.ausdauer <= 0:
            ziel.malus_erschoepfung = 5
        print(f"{Fore.WHITE}[Verteidigung ({ziel.name}): {verteidigung_ziel}] {Fore.GREEN}\n")
        WARTEN()
        if angriffswurf >= verteidigung_ziel or wuerfelwurf == 12:  # Ab hier die Erfolgsberechnung
            if wuerfelwurf == 12:
                print(f"{Fore.BLUE}[Erfolg durch Natürliche 12]{Fore.GREEN}\n")
                WARTEN()
            self.schaden(ziel)
            return
        elif wuerfelwurf == 1:
            print(f"{Fore.LIGHTRED_EX}[KRITISCHER MISSERFOLG.]{Fore.GREEN}\n")
            WARTEN()
            print(f"{Fore.WHITE}[{self.name} schwingt kolossal daneben.]{Fore.GREEN}\n")
            WARTEN()
            self.ausdauer -= 1
            print(f"{Fore.WHITE}[Deine Ausdauer: {ziel.ausdauer}/{ziel.max_ausdauer}]{Fore.GREEN}\n")
            WARTEN()
            return
        elif angriffswurf < verteidigung_ziel - 1:
            print(f"{Fore.RED}[MISSERFOLG] {Fore.GREEN} \n")
            WARTEN()
            print(f"{Fore.WHITE}[Der Angriff verfehlt.]\n")
            WARTEN()
            return
        else:
            ziel.ausdauer -= 1
            print(f"{Fore.RED}[MISSERFOLG]{Fore.GREEN} \n")
            WARTEN()
            print(f"{Fore.WHITE}[Der Angriff verfehlt nur knapp.]{Fore.GREEN}\n")
            WARTEN()
            print(f"{Fore.WHITE}[Deine Ausdauer: {ziel.ausdauer}/{ziel.max_ausdauer}]{Fore.GREEN}\n")
            WARTEN()
            return


protagonist = Spieler("unbekannt", "unbekannt", "unbekannt", 4, 4, 2,
                      4, 2, 0, 0, [], 0,
                      2, [feuerball, blitz], 0, "unbekannt", 5,
                      [], 4, 5, 0, 12, 0,
                      5, 0, 0, unbewaffnet, 0, 2,
                      0, 0, 0, 0)

blaehspinne = Gegner("Die Blähspinne", "unbekannt", "Blähspinne", 4, 3, 2,
                     1, 0, 0, 0, None, 0, 0, None,
                     None, "Monster", None, None, 8, 0,
                     1, 8, 11, 0, 11,  8,
                     unbewaffnet, 2, 0, 5, 0, 0,
                     0)

kettenhase = Gegner("Der Kettenhase", "unbekannt", "Kettenhase", 2, 2, 4,
                    1, 1, 5, 0, [], 2, 0,
                    None, 0, "Monster", 0, None, 6,
                    0, 1, 4, 8, 0, 8, 6,
                    hasenkette, 2, 2, 4, 0, 0,
                    0)

schwerwolf = Gegner("Der Schwerwolf", "unbekannt", "Schwerwolf", 6, 2, 5,
                    4, 2, 2, 0, None, 2, 2, None,
                    None, "Monster", None, None, 12, 0,
                    1, 10, 15, 0, 15, 12,
                    unbewaffnet, 0, 2, 6, 0, 0,
                    0)
