"""
In dieser Datei sind die im Spiel verfügbaren Zauber gespeichert.
"""


import random


class Zauber:
    def __init__(self, name, kontrolle, erfolgswert, aufwand_aktion, aufwand_zauberkraft, zauberart, toedlichkeit,
                 schaden, schadensart, schadensbonus):
        self.name = name
        self.kontrolle = kontrolle
        self.erfolgswert = erfolgswert
        self.aufwand_aktion = aufwand_aktion
        self.aufwand_zauberkraft = aufwand_zauberkraft
        self.zauberart = zauberart
        self.toedlichkeit = toedlichkeit
        self.schaden = schaden
        self.schadensArt = schadensart
        self.schadensbonus = schadensbonus


blitz = Zauber("Blitz", 3, 4, 1, 4, "Schaden",
               "3W6",
               int(random.randint(1, 6) + random.randint(1, 6) + random.randint(1, 6)),
               "Elektrizität", 0)

entsperren_einfach = Zauber("Entsperren", 3, 4, 1,
                            3, "Kontrolle", None, 0,
                            None, None)

entsperren = Zauber("Entsperren", 5, 4, 1, 4,
                    "Kontrolle", None, 0, None, None)

feuerball = Zauber("Feuerball", 3, 4, 1, 6, "Schaden",
                   "3W8",
                   int(random.randint(1, 8) + random.randint(1, 8) + random.randint(1, 8)),
                   "Feuer", 0)

licht = Zauber("Licht", 1, 4, 1, 0, "Beschwörung",
               None, 0, None, None)

manipulation_einfach = Zauber("Manipulation", 3, 4, 1, 3,
                              "Beschwörung", None, 0, None, None)

manipulation = Zauber("Manipulation", 4, 4, 1, 3,
                      "Beschwörung", None, 0, None, None)

# print(blitz.schaden)
