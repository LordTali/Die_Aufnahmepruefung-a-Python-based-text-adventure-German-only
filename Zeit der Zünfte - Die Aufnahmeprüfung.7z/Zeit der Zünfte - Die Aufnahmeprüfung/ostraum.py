"""
In dieser Datei sind die Aktionen im Ostraum gespeichert.
"""

from steuerelemente import *
from fallen import *
from raetsel import *


def ostraum_1():
    print("Du betrittst einen langen steinernen Korridor bar jeder Dekoration.\n")
    WARTEN()
    print("Im Westen jenseits des Raums befindet sich der Eingang mit dem Gang gen West und der massiven Tür.\n")
    WARTEN()
    print("Am nördlichen Rand des Raums stehen hier und da einige Steinsäulen.\n")
    WARTEN()
    print("Sonst entdeckst du hier auf den ersten Blick nichts von Interesse, aber irgendeinen Grund muss dieser Raum "
          "doch haben!\n")
    WARTEN()
    print("Vielleicht solltest du dich hier etwas genauer umschauen.\n")
    return


def ostraum_2():
    while not spiel.epilog:
        print("Du näherst dich den Säulen und der Tür.\n")
        WARTEN()
        print("Eine der Säulen ist blau angestrichen, die andere grün.\n")
        WARTEN()
        print("Die Tür war bestimmt einmal rot, aber die Farbe ist mittlerweile ausgeblichen "
              "und sieht eher braun aus.\n")
        while True:
            aktion = input("Willst du dir etwas genauer anschauen? (Optionen: Blau Säule, grüne Säule, "
                           "zurückgehen)\n > ").lower()
            if "blau" in aktion:
                if "roter Schlüssel" in protagonist.inventar:
                    print("Hier gibt es nicht mehr von Interesse, daher gehst du einige Schritte zurück.\n")
                    WARTEN()
                    continue
                else:
                    protagonist.inventar.append("roter Schlüssel")
                    print("Du näherst dich der blauen Säule.\n")
                    WARTEN()
                    print(f"Zunächst entdeckst du nichts Ungewöhnliches, dann fällt dir aber etwas zwischen den Rissen "
                          f"im Gestein auf: ein kleiner {Fore.RED}roter Schlüssel{Fore.GREEN}.\n")
                    WARTEN()
                    print("Du steckst ihn ein und kannst deinen Weg fortsetzen.\n")
                    continue
            elif "grün" in aktion:
                while True:
                    print("Du kannst dich der Säule von Links oder von Rechts nähern. Oder du gehst weg.\n")
                    WARTEN()
                    antwort = input("Was tust du? (Optionen: Links, rechts, weggehen) \n > ").lower()
                    if "links" in antwort:
                        if spiel.falle_ost:
                            print("Du näherst dich gefahrlos der Säule.\n")
                            WARTEN()
                        else:
                            print("Du näherst dich der Säule, aber klar, warum würde es hier nach all dem Stress nicht "
                                  "auch noch Fallen geben?\n")
                            WARTEN()
                            reaktion = falle()   # Hier wird eine Falle ausgelöst. Bei Misserfolg ist das Spiel vorbei.
                            if reaktion:
                                spiel.falle_ost = True
                                print("Jetzt kommst du gefahrlos zur Säule.\n")
                                WARTEN()
                            else:
                                spiel.epilog = True
                                return
                        if spiel.ostraum:
                            print("Nachdem du hier einen Gegenstand gefunden hast, "
                                  "gibt es hier nichts mehr von Interesse.\n")
                            WARTEN()
                            print("Daher gehst du einige Schritte zurück.\n")
                            break
                        else:
                            print("Dort fällt dir etwas auf.\n")
                            WARTEN()
                            loesung = raetsel_aufgeben()
                            if loesung:
                                spiel.ostraum = True
                                if spiel.epilog:
                                    continue
                                break
                    elif "rechts" in antwort:
                        print("Du näherst dich der Säule.\n")
                        WARTEN()
                        if spiel.ostraum:
                            print("Nachdem du hier einen Gegenstand gefunden hast, "
                                  "gibt es hier nichts mehr von Interesse.\n")
                            WARTEN()
                            print("Daher gehst du einige Schritte zurück.\n")
                            break
                        else:
                            print("Dort fällt dir etwas auf.\n")
                            WARTEN()
                            loesung = raetsel_aufgeben()
                            if loesung:
                                spiel.ostraum = True
                                break
                    elif "weg" in antwort:
                        print("Du machst einige Schritte zurück.\n")
                        break
                    elif "raushier" in antwort:
                        programmende()
                        continue
                    else:
                        hoppla()
            elif "raushier" in aktion:
                programmende()
                continue
            elif "zurück" in aktion or "weg" in aktion:
                print("Du machst einige Schritte zurück in die Richtung, aus der du gekommen bist.\n")
                WARTEN()
                return
            else:
                hoppla()
    else:
        return
