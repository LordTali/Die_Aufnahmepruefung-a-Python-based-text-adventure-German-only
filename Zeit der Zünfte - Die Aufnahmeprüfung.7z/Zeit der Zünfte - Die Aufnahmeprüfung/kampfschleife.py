import random
from colorama import *
from steuerelemente import *
from charakter import *


class Kampf:
    def __init__(self, teilnehmer, gegner, letzter_zug, runde, moegliche_gegner):
        self.teilnehmer = teilnehmer
        self.gegner = gegner
        self.letzter_zug = letzter_zug
        self.runde = runde
        self.moegliche_gegner = moegliche_gegner

    def wurf_w12(self):
        wurf = random.randint(1, 12)
        print(f"{Fore.WHITE}[Würfel: {wurf}]{Fore.GREEN}\n")
        WARTEN()
        return wurf

    def teilnehmer_hinzufuegen(self, teilnehmer):
        self.teilnehmer.append(teilnehmer)
        return

    def gegner_hinzufuegen(self, gegner):
        self.gegner.append(gegner)
        return

    def initiative_wuerfeln(self):
        print(f"{Fore.WHITE}[Initiativwurf]{Fore.GREEN} \n")
        WARTEN()
        for kaempfer in self.teilnehmer:
            print(f"{Fore.WHITE}[Wurf ({kaempfer.name})]{Fore.GREEN}\n")
            WARTEN()
            wurf = self.wurf_w12()
            WARTEN()
            print(f"{Fore.WHITE}[Reflexe ({kaempfer.name}): {kaempfer.reflexe}]{Fore.GREEN}{Fore.GREEN}\n")
            WARTEN()
            initiative_gesamt = kaempfer.reflexe + wurf
            kaempfer.initiative = initiative_gesamt
            print(f"{Fore.WHITE}[Gesamtinitiative ({kaempfer.name}): {initiative_gesamt}]{Fore.GREEN}\n")
            WARTEN()
            print("---------------------------------------\n")
            WARTEN()
        return

    def reihenfolge_bestimmen(self):
        self.teilnehmer.sort(key=lambda teilnehmer: teilnehmer.initiative, reverse=True)
        self.gegner.sort(key=lambda teilnehmer: teilnehmer.initiative, reverse=True)
        WARTEN()
        return

    def reihenfolge_anzeigen(self):
        print(f"{Fore.WHITE}[Kampfreihenfolge]{Fore.GREEN}\n")
        WARTEN()
        for platz, teilnehmer in enumerate(self.teilnehmer, start=1):
            print(f"{Fore.WHITE}[{platz}. {teilnehmer.name} (Initiative: {teilnehmer.initiative})]{Fore.GREEN}\n")
        WARTEN()
        return

    def kampf_beginnen(self):
        deine_gegner = []
        for kaempfer in self.gegner:
            deine_gegner.append(kaempfer.name)
        umwandeln = [str(gegner) for gegner in deine_gegner]
        trennzeichen = ", "
        gegner_liste = trennzeichen.join(umwandeln)
        print(f"{Fore.WHITE}[Du bist nun im Kampf gegen {Fore.YELLOW}{gegner_liste}{Fore.WHITE}.]{Fore.GREEN}\n")
        WARTEN()
        return

    def runden_zaehler(self):
        self.runde += 1
        for kaempfer in self.teilnehmer:
            kaempfer.verteidigung = (Charakter.basis_verteidigung + kaempfer.stufe + kaempfer.reflexe
                                     - kaempfer.bewaffnung.verteidigungsmalus)
            kaempfer.kampfstilbonus = 0
            kaempfer.kampfstilmalus = 0
            kaempfer.schadensbonus = 0
            kaempfer.aktionen = 2
        print(f"{Fore.WHITE}[Runde {self.runde}]{Fore.GREEN}\n")
        WARTEN()
        return

    def kampfschleife(self):
        for kaempfer in self.teilnehmer:
            self.letzter_zug = kaempfer
            kaempfer.handeln()
        return


begegnung = Kampf([], [], [], 0, [kettenhase, blaehspinne, schwerwolf])
