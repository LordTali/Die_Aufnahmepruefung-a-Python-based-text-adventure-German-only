"Zeit der Zünfte: Die Aufnahmeprüfung" ist ein Textabenteuer-Spiel im vereinfachten Zeit-Der-Zünfte-Rollenspielsystem von Vitali Hänisch, in dem Spieler bestimmte Handlungen ihre Charakters mittels Texteingabe steuern.

Ziel des Spiels ist es, den Spielern eine interaktive Geschichte zu bieten, die je nach Spielverlauf unterschiedlich ausgehen kann.


WICHTIG:

Die Software verwendet das Modul Colorama. Je nach System wird dieses notwendig sein, um das Programm zu starten.

ACHTUNG:

Das Programm ist in seiner derzeitigen Form spielbar, durchläuft aber noch die Qualitätssicherung.
Abstürze und Bugs können momentan nicht ausgeschlossen werden.
Eine Rechtschreibprüfung bei Texten der Software wurde ebenfalls nicht vollständig abgeschlossen.
Der Entwickler würde sich über Rückmeldungen zum Spielerlebnis und eventuellen Problemen freuen, damit das Spiel verbessert werden kann.

Zu einem späteren Zeitpunkt könnten noch Updates folgen, die das Spiel erweitern.