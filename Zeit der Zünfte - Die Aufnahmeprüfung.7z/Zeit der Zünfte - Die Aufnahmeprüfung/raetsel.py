"""
In dieser Datei werden wie verschiedenen Rätsel gespeichert, die ein Spieler im Verlauf des Spiels lösen muss.
Die Rätsel werden aus einer erweiterbaren Liste von Rätseln zufällig ausgewählt.

Wenn ein Rätsel gelöst ist, erhält der Spieler einen ebenfalls zufällig gewählten Gegenstand als Belohnung.
Hier wird auch der Fortschritt des Spielers überwacht. Sobald er oder sie drei Gegenstände gesammelt hat,
wird ein Epilog ausgelöst.
"""

import random
from charakter import protagonist
from steuerelemente import *
from colorama import Fore
from zauber import *
from ende import programmende
random.seed()


# Rätselmechaniken


def zufallswort(wort):          # Anagramm innerhalb des Wortes.
    buchstaben = list(wort)
    random.shuffle(buchstaben)
    return ''.join(buchstaben)


def zufallswoerter(woerter):    # Zufallswort auf die Liste anwenden.
    wortpaar = {}
    for wort in woerter:
        zufallsgenerator = zufallswort(wort)
        wortpaar[zufallsgenerator] = wort
    return wortpaar


def wort_ausgeben(mischmasch):      # Anagramm ausgeben.
    return random.choice(list(mischmasch.keys()))


def anagramm_pruefung(ausgabe, ursprungswortpaar, antwort):     # Prüfen, ob das Wort richtig entschlüsselt wurde.
    ursprungswort = ursprungswortpaar.get(ausgabe)
    return antwort == ursprungswort.lower()


woerter = ["Gandalf", "Zauberlehrling", "Zauberstab", "Bruchtal", "Siegfried", "Krabat", "Pfadfinder", "Krieger",
           "Barbar", "Druide", "Kleriker", "Paladin", "Waldläufer", "Kämpfer", "Mönch", "Schütze", "Pistolero", "Krug",
           "Magier", "Hexenmeister", "Alchemist", "Ritter", "Drache", "Turmschild", "Festung", "Erfinder", "Pferd",
           "Schimmelreiter", "Fantasy", "Urlaub", "Schloss", "Herausforderung", "Schönheit", "Kaffee", "Schenke",
           "Freund", "Priester", "Goblin", "Schlange", "Ehrgeiz", "Schauspiel", "Eigenschaft", "Überlegung",
           "Gedanke", "Wunder", "Prüfung"]

mischmasch = zufallswoerter(woerter)

ursprungswortpaar = zufallswoerter(woerter)

# Buchstabelsalat ausgeben

BUCHSTABENSALAT = wort_ausgeben(mischmasch)


def zauber_pruefen(Zauber):           # Prüft, ob der Charakter genug Kontrollwürfel hat, um einen Wurf zu versuchen.
    if protagonist.kontrollwuerfel < Zauber.kontrolle or protagonist.zauberkraft < Zauber.aufwand_zauberkraft:
        # Wenn er rein rechnerisch gar nicht bestehen kann, wird das gesagt.
        print("Du bist nicht stark genug, um dieses Hindernis mit Magie zu überwinden.\n")
        WARTEN()
        return False
    else:
        return True


def raetsel_aufgeben():                 # Ein Rätsel aus dem Rätselpool wird zufällig bestimmt und ausgegeben.
    funktion_frage = random.choice(RAETSEL)
    frage = funktion_frage()
    if frage:
        RAETSEL.remove(funktion_frage)
        return True
    else:
        return False


def zuffaelliger_gegenstand():  # Der Charakter erhält einen zufälligen Gegenstand, den er für die Prüfung braucht.
    loot = random.choice(spiel.loot)
    return loot


def fortschritt_pruefen():              # Prüfen, ob der Charakter genug Gegenstände gesammelt hat.
    if len(spiel.quest_gegenstaende) >= 3:     # Wenn ja, endet das Rumlaufen, es kommt zum Finale.
        WARTEN()
        print(f"{Fore.MAGENTA}{", ".join(spiel.quest_gegenstaende)}{Fore.GREEN}\n")
        WARTEN()
        print("Damit hast du alle drei Gegenstände gefunden, die du beschaffen solltest.\n")
        WARTEN()
        print("Es wird Zeit, zum Eingang zurückzukehren und deine Beurteilung zu erhalten.\n")
        WARTEN()
        spiel.epilog = True
        return
    else:
        return


# Hier die eigentlichen Rätsel

def raetsel_witz():
    print("Du stehst vor einer Steintafel. Darauf liest du die folgende Innschrift:")
    WARTEN()
    print(f"{Fore.LIGHTYELLOW_EX}\"Man kann mich reißen oder machen. Den Einen kann ich verletzen, "
          f"den Anderen bringe ich zum lachen\"{Fore.GREEN}.\n")
    WARTEN()
    while True:
        antwort = input(f"{Fore.LIGHTYELLOW_EX}Was bin ich?{Fore.GREEN} \n > ").lower()
        if "witz" in antwort or "scherz" in antwort:
            raetsel_witz_richtig()
            return True
        elif "zauber" in antwort:
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if not probe:
                    reflexprobe = raetsel_witz_falsch()
                    if reflexprobe:
                        return True
                else:
                    raetsel_witz_richtig()
                    return True
        elif "grips" in antwort:
            probe = protagonist.gripsWurf(12)
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}Witz{Fore.GREEN}\n")
                raetsel_feuer_richtig()
                return True
            else:
                continue
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            reaktion = raetsel_witz_falsch()
            if reaktion:
                return True
            else:
                return False


def raetsel_witz_falsch():
    spiel.strafpunkte += 1
    print("Die Steintafel bekommt Risse und explodiert von Innen. Splitter fliegen dir direkt "
          "ins Gesicht.\n")
    WARTEN()
    print("Du versuchst, auszuweichen.\n")
    reflexprobe = protagonist.reflexWurf(12)
    if reflexprobe:
        return True
    else:
        print("Ein Splitter trifft dich mit voller Wucht, und du verlierst das Bewusstsein.\n")
        WARTEN()
        print("Als du wieder zu dir kommst, siehst du, wie dein potentieller Meister neben dir steht.\n")
        WARTEN()
        print("Er ist sichtlich enttäuscht, und schüttelt nur langsam mit dem Kopf, um seinem Gemüt Ausdruck "
              "zu verleihen.\n")
        spiel.epilog = True
        return False


def raetsel_witz_richtig():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print("Die Tafel bekommt plötzlich risse und zerbricht mit einem lauten Knacken.\n")
    WARTEN()
    print(f"Zwischen den Trümmern findest du einen kleinen Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}) "
          f"und steckst ihn ein.\n")
    WARTEN()
    fortschritt_pruefen()
    return True


def raetsel_feuer():
    print("Du stehst vor einer Statue, bei der du dir nicht ganz sicher bist, was eigentlich darstellen soll.\n")
    WARTEN()
    print("Sie hält ein Stück Pergament in den Händen. Darauf steht:\n ")
    WARTEN()
    print(f"{Fore.LIGHTYELLOW_EX}\"Ich lebe nicht, doch ich kann wachsen. Ich atme nicht, "
          f"doch ich brauche Luft. Ich muss gefüttert werden, "
          f"doch Wasser darf ich nicht trinken\"{Fore.GREEN}.\n")
    WARTEN()
    while True:
        antwort = input(f"{Fore.LIGHTYELLOW_EX}Was bin ich?{Fore.GREEN} \n > ").lower()
        if "feuer" in antwort or "flamme" in antwort:
            raetsel_feuer_richtig()
            return True
        elif "zauber" in antwort:
            WARTEN()
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    raetsel_feuer_richtig()
                    return True
                else:
                    WARTEN()
                    reaktion = raetsel_feuer_falsch()
                    if reaktion:
                        return True
                    else:
                        return False
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        elif "grips" in antwort:
            WARTEN()
            probe = protagonist.gripsWurf(12)
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}Feuer{Fore.GREEN}.\n")
                WARTEN()
                raetsel_feuer_richtig()
                return True
            else:
                continue
        else:
            reaktion = raetsel_feuer_falsch()
            if reaktion:
                return True
            else:
                return False


def raetsel_feuer_richtig():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print("Die Tafel in den Händen der Statue entzündet sich und verbrennt in nur wenigen Sekunden.\n")
    WARTEN()
    print(f"Die Statue öffnet ihren Mund und lässt einen kleinen Gegenstand "
          f"({Fore.MAGENTA}{belohnung}{Fore.GREEN}) auf den Boden Fallen.\n")
    WARTEN()
    print("Du hebst den Gegenstand auf und steckst ihn ein.\n")
    WARTEN()
    fortschritt_pruefen()
    return True


def raetsel_feuer_falsch():
    spiel.strafpunkte += 1
    print("Die Statue öffnet ihre leuchtenden grünen Augen und starrt dich an.\n")
    WARTEN()
    print("Ihr Blick hat etwas richtig Hypnotisches.\n")
    WARTEN()
    print("Etwas Verführerisches.\n")
    WARTEN()
    print("Es fällt dir nur schwer, deinen Blick von ihr abzuwenden.\n")
    WARTEN()
    probe = protagonist.willensWurf(12)
    if probe:
        print("Du kannst deinen ganzen Willen jedoch zusammennehmen und unter großer Anstrengung in eine andere "
              "Richtung schauen.\n")
        WARTEN()
        print("Kurz darauf erlöschen die Augen der Statue wieder.\n")
        raetsel_feuer_richtig()
        return True
    else:
        print("Als die Augen der Statue erlöschen, bemerkst du deinen potentiellen Meister, der kopfschüttelnd neben"
              "dir steht.\n")
        WARTEN()
        print("Wie viel Zeit war denn bitte vergangen? Dir wurde doch sooooo viel Zeit für die Prüfung eingeräumt!\n")
        WARTEN()
        print("Ooooooh! Oh, nein.\n")
        WARTEN()
        print("Der Tag ist vorbei, und du standest die ganze Zeit da, und hast in die Augen der "
              "Statue gestarrt, oder?\n")
        WARTEN()
        print("Du willst jetzt fluchen, doch es wäre zwecklos.\n")
        WARTEN()
        spiel.epilog = True
        return False
        

def raetsel_wolke():
    print("Vor dir wächst ein Baum, eine uralte riesige Eiche.\n")
    WARTEN()
    print("Ihre Wurzeln scheinen viel tiefer zu liegen als der Höhlenboden, ihre Krone verschwindet irgendwo "
          "weit außerhalb deiner Sichtweite.\n")
    WARTEN()
    print("In den Baumstamm ist etwas eingeritzt.\n")
    WARTEN()
    print("Es fällt dir schwer, die Schrift auszumachen, dann kannst du die Worte aber doch lesen.\n")
    WARTEN()
    print(f"{Fore.LIGHTYELLOW_EX}\"Ich brauche keine Flügel, um zu fliegen. Ich brauche keine Augen, um zu weinen. "
          f"Wo immer ich hinkomme, bringe ich Dunkelheit\"{Fore.GREEN}.\n")
    while True:
        antwort = input(f"{Fore.LIGHTYELLOW_EX}Was bin ich?{Fore.GREEN} \n > ").lower()
        if "wolke" in antwort:
            WARTEN()
            raetsel_wolke_richtig()
            return True
        elif "zauber" in antwort:
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    raetsel_wolke_richtig()
                    return True
                else:
                    WARTEN()
                    reaktion = raetsel_wolke_falsch()
                    if reaktion:
                        return True
                    else:
                        spiel.epilog = True
                        return False
        elif "grips" in antwort:
            WARTEN()
            probe = protagonist.gripsWurf(12)
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}(Regen-)Wolke{Fore.GREEN}.\n")
                WARTEN()
                raetsel_wolke_richtig()
                return True
            else:
                continue
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            WARTEN()
            reaktion = raetsel_wolke_falsch()
            if reaktion:
                return True
            else:
                return False


def raetsel_wolke_richtig():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print("Der Baum bewegt einige seiner Wurzeln zur Seite und offenbart eine kleine moosbewachsene Fläche.\n")
    WARTEN()
    print(f"Darauf bemerkst du einen kleinen Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}) und steckst ihn ein.\n")
    fortschritt_pruefen()
    return True


def raetsel_wolke_falsch():
    spiel.strafpunkte += 1
    print("Du bemerkst, wie einige Wurzeln des Baums plötzlich nach dir schnellen.\n")
    WARTEN()
    while True:
        antwort = input("Du kannst wählen, ob du gegen den Baum kämpfen "
                        "oder den Wurzeln ausweichen willst.\n > ").lower()
        if "kämp" or "kamp" in antwort:
            if protagonist.karriere == "Recke" or protagonist.karriere == "Gauner":
                kampf = protagonist.kampf(12)
                if kampf:
                    protagonist.minuspunkte += 1
                    print("Du musst dich ordentlich winden und bewegen, zerschneidest aber erfolgreich alle Wurzeln, "
                          "die nach dir greifen.\n")
                    WARTEN()
                    raetsel_wolke_richtig()
                    return True
                else:
                    print("Du greifst die Wurzeln an, doch es sind zu viele.\n")
                    WARTEN()
                    print("Eine der Wurzeln wickelt sich um deinen Waffenarm und hält ihn fest, "
                          "während weitere Wurzeln dich umklammern.\n")
                    WARTEN()
                    print("In dieser bewegungsunfähigen Position verharrst du, "
                          "bis dein potentieller Meister irgendwann vorbeikommt und dich befreit.\n")
                    WARTEN()
                    print("Er ist sichtlich enttäuscht von diesem unrühmlichen Ergebnis, und du kannst diesem "
                          "Gesichtsausdruck nicht viel entgegensetzen.\n")
                    WARTEN()
                    spiel.epilog = True
                    return False
            else:
                if protagonist.kontrollwuerfel >= 3 and protagonist.zauberkraft >= 5:
                    zaubern = protagonist.kontrollwurf(feuerball)
                    if zaubern:
                        print("Du fokussiert deine gesamte Zauberkraft und lässt einen großen Feuerball "
                              "auf den blöden Baum los.\n")
                        WARTEN()
                        print("Die Flammenzungen verbrennen den Großteil seiner Wurzeln und ein gutes Stück Rinde.\n")
                        WARTEN()
                        print("Du begreifst langsam, was du da gerade getan hast.\n")
                        WARTEN()
                        print("Zufrieden kann dein potentieller Meister mit dieser Entscheidung ganz eindeutig "
                              "nicht sein, aber hoffentlich wird dich das allein nicht disqualifizieren.\n")
                        WARTEN()
                        print("Zumindest hast du jetzt, was du wolltest.\n")
                        raetsel_wolke_richtig()
                        return True
                    else:
                        print("Du versuchst, du zaubern, kannst aber nicht rechtzeitig genug Zauberkraft aufbringen.\n")
                        WARTEN()
                        print("Eine der Wurzeln wickelt sich um deinen Waffenarm und hält ihn fest, während "
                              "weitere Wurzeln dich umklammern.\n")
                        WARTEN()
                        print("In dieser bewegungsunfähigen Position verharrst du, bis dein potentieller "
                              "Meister irgendwann vorbeikommt und dich befreit.\n")
                        WARTEN()
                        print("Er ist sichtlich enttäuscht von diesem unrühmlichen Ergebnis, und du kannst diesem "
                              "Gesichtsausdruck nicht viel entgegensetzen.\n")
                        WARTEN()
                        protagonist.epilog = True
                        return False
                else:
                    print("Du versuchst, du zaubern, kannst aber nicht rechtzeitig genug Zauberkraft aufbringen.\n")
                    WARTEN()
                    print("Eine der Wurzeln wickelt sich um deinen Waffenarm und hält ihn fest, während "
                          "weitere Wurzeln dich umklammern.\n")
                    WARTEN()
                    print("In dieser bewegungsunfähigen Position verharrst du, bis dein potentieller "
                          "Meister irgendwann vorbeikommt und dich befreit.\n")
                    WARTEN()
                    print("Er ist sichtlich enttäuscht von diesem unrühmlichen Ergebnis, und du kannst diesem "
                          "Gesichtsausdruck nicht viel entgegensetzen.\n")
                    WARTEN()
                    spiel.epilog = True
                    return False
        elif "weich" in antwort:
            print("Du versuchst, auszuweichen.\n")
            probe = protagonist.reflexWurf(14)
            if probe:
                print("Du kannst gerade noch zurückspringen.\n")
                WARTEN()
                print("Du machst dich für einen Kampf mit dem Baum bereit, doch er kommt nicht.\n")
                WARTEN()
                raetsel_wolke_richtig()
                return True
            else:
                print("Du willst zurückspringen, bist aber nicht schnell genug.\n")
                WARTEN()
                print("Die Wurzeln greifen und umklammern dich wie eine Würgeschlange.\n")
                WARTEN()
                print("Wenigstens kannst du so noch atmen, dich umzubringen war hier offenbar nicht das Ziel.\n")
                WARTEN()
                print("In dieser bewegungsunfähigen Position verharrst du, bis dein potentieller Meister irgendwann "
                      "vorbeikommt und dich befreit.\n")
                WARTEN()
                print("Er ist sichtlich enttäuscht von diesem unrühmlichen Ergebnis, und du kannst diesem "
                      "Gesichtsausdruck nicht viel entgegensetzen.\n")
                WARTEN()
                spiel.epilog = True
                return False
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            hoppla()


def raetsel_karte():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print(f"Du sieht einen kleinen Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}) auf einem kleinen "
          f"steinernen Podest.\n")
    WARTEN()
    print("Als du dich näherst, schießen scharfe Speere aus dem Boden um dich herum.\n")
    WARTEN()
    print("Sie formen eine Falle, aus der du so ohne Weiteres nicht rauskommst.\n")
    WARTEN()
    print("Auf dem Boden erscheint neben deinen Füßen aber eine leuchte Nachricht.\n")
    WARTEN()
    print(f"{Fore.LIGHTYELLOW_EX}\"Ich habe Städte, aber keine Häuser. Ich habe Wälder, doch keine Bäume. "
          f"Ich habe Flüsse, doch kein Wasser\".{Fore.GREEN}\n")
    WARTEN()
    while True:
        antwort = input(f"{Fore.LIGHTYELLOW_EX}Was bin ich?{Fore.GREEN}\n > ").lower()
        if "karte" in antwort:
            WARTEN()
            raetsel_karte_richtig()
            return True
        elif "zauber" in antwort:
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    print("Du bist nicht sicher, welchen Zauber du gerade verwendest, aber du merkst, "
                          "dass du die Speere manipulieren kannst.\n")
                    WARTEN()
                    raetsel_karte_richtig()
                    return True
                else:
                    WARTEN()
                    reaktion = raetsel_karte_falsch()
                    if reaktion:
                        return True
                    else:
                        return False
        elif "grips" in antwort:
            WARTEN()
            probe = protagonist.gripsWurf(12)
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}(Land-)Karte{Fore.GREEN}.\n")
                WARTEN()
                raetsel_wolke_richtig()
                return True
            else:
                continue
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            WARTEN()
            reaktion = raetsel_karte_falsch()
            if reaktion:
                return True
            else:
                spiel.epilog = True
                return False


def raetsel_karte_richtig():
    print("Die Schrift verschwindet, die Speere fahren wieder nach unten, zurück in den steinernen Boden.\n")
    WARTEN()
    print("Der Weg zum Gegenstand ist wieder frei. Du nimmst ihn an dich und steckst ihn ein.\n")
    fortschritt_pruefen()
    return True


def raetsel_karte_falsch():
    print("Was immer du tust, du kommst hier nicht mehr raus. Nicht selbst, jedenfalls.\n")
    WARTEN()
    print("Du hättest es eigentlich echt besser wissen sollen.\n")
    WARTEN()
    print("Als ob du den Gegenstand einfach so nehmen könntest! Das wäre doch viel zu einfach.\n")
    WARTEN()
    print("Es musste irgendwo einen Haken geben!\n")
    WARTEN()
    print("Bei solchen Überlegungen verbringst du eine vergleichsweise lange Zeit, bis dein potentieller Meister "
          "vorbeikommt und dich befreit.\n")
    WARTEN()
    print("Seinem Gesichtsausdruck nach ist er alles Andere als beeindruckt.\n")
    WARTEN()
    print("Er hatte nie gesagt, wie viel Vertrauen er in deine Fertigkeiten hat, sicherlich hätte er dir solch einen "
          "Anfängerfehler aber dann doch nicht zugetraut.\n")
    WARTEN()
    spiel.epilog = True
    return False


def raetsel_stille():
    print("Ein starker Wind kommt aus dem nichts und wirbelt um dich.\n")
    WARTEN()
    print("Der Druck ist so stark, dass du dich nicht einmal bewegen kannst.\n")
    WARTEN()
    print("Während du überlegst, wie du aus dieser Situation rauskommen kannst, hörst du in deinem Kopf eine Stimme.\n")
    WARTEN()
    while True:
        antwort = input(f"{Fore.LIGHTYELLOW_EX}\"Was ist so zerbrechlich, "
                        f"dass selbst sein Name es brechen kann?\"{Fore.GREEN}\n > ").lower()
        if "stille" in antwort:
            raetsel_stille_richtig()
            return True
        elif "zauber" in antwort:
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    print("Also wirklich! An dieser Stelle hättest du etwas mehr von deinem Meister erwartet!\n")
                    WARTEN()
                    print("Luftmanipulationszauber können zwar recht stark sein, aber wenn man sich damit auskennt, "
                          "ist ein Gegenzauber nicht allzu schwer. Für dich, jedenfalls.\n")
                    WARTEN()
                    raetsel_stille_richtig()
                    return True
                else:
                    WARTEN()
                    reaktion = raetsel_karte_falsch()
                    if reaktion:
                        return True
                    else:
                        spiel.epilog = True
                        return False
        elif "grips" in antwort:
            WARTEN()
            probe = protagonist.gripsWurf(12)
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}Stille{Fore.GREEN}.\n")
                WARTEN()
                raetsel_stille_richtig()
                return True
            else:
                continue
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            WARTEN()
            reaktion = raetsel_stille_falsch()
            if reaktion:
                return True
            else:
                spiel.epilog = True
                return False


def raetsel_stille_richtig():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print("Der Wind lässt genauso schnell nach, wie er aufgekommen ist.\n")
    WARTEN()
    print(f"Als du gerade schulterzuckend weitergehen willst, bemerkst du, "
          f"wie ein kleiner Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}) von oben fällt - "
          f"direkt in deine Hand.\n")
    WARTEN()
    print("Du steckst den Gegenstand ein und machst weiter.\n")
    WARTEN()
    fortschritt_pruefen()
    return True


def raetsel_stille_falsch():
    spiel.strafpunkte += 1
    print("Der Wind will einfach nicht aufhören.\n")
    WARTEN()
    print("Das Einzige, was dir jetzt noch einfällt, ist ein Kraftakt.\n")
    WARTEN()
    print("Wenn du deinen ganzen Willen zusammen nimmst und deine Muskeln bis zum Äußersten anspannst, "
          "könntest du unter Umständen ausbrechen.\n")
    WARTEN()
    probe = protagonist.willensWurf(12)
    print(f"{Fore.WHITE}[Bonus: {protagonist.kraft}]{Fore.GREEN}\n")
    kraftakt = probe + protagonist.kraft
    if kraftakt > 15:
        print("Mit einer gigantischen Kraftanstregung kannst du dich doch noch bewegen und aus dem "
              "Windwirbel ausbrechen.\n")
        WARTEN()
        print("Dieser Erfolg bleibt nicht unbemerkt.\n")
        WARTEN()
        raetsel_stille_richtig()
        return True
    else:
        print("So sehr du dich auch bemühst: Du bist einfach nicht stark genug. Du verharrst in dieser Position, "
              "bis dein potentieller Meister kommt und dich befreit.\n")
        WARTEN()
        print("Er sagt dir gegenüber nicht viel, aber jedes Wort schneidet wie eine zwergische Klinge.\n")
        WARTEN()
        return False


def raetsel_buchstaben():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print(f"Der Gegenstand vor dir ({Fore.MAGENTA}{belohnung}{Fore.GREEN}) befindet sich in einer "
          f"durchsichtigen Kiste.\n")
    WARTEN()
    print("An der Kiste sind mehrere Rädchen angebracht. Sie bewegen jeweils einen Buchstaben.\n")
    WARTEN()
    print("Dir wird schnell klar, dass du sie in die richtige Folge bringen musst, um den Gegenstand zu bekommen.\n")
    WARTEN()
    if protagonist.karriere == "Recke" or protagonist.karriere == "Gauner":
        print("Dann wiederum, du könntest auch einfach draufhauen und den Gegenstand an dich nehmen.\n")
        WARTEN()
    raetsel_buchstaben_2()
    fortschritt_pruefen()
    return True


def raetsel_buchstaben_2():
    while True:
        antwort = input(f"Derzeit zeigen die Regler {Fore.LIGHTYELLOW_EX}{BUCHSTABENSALAT}{Fore.GREEN}.\n > ").lower()
        pruefung = anagramm_pruefung(BUCHSTABENSALAT, mischmasch, antwort)
        WARTEN()
        if pruefung:
            spiel.strafpunkte -= 1
            print("Du hörst ein vertrautes Schlossknacken, und die Kiste geht auf.\n")
            WARTEN()
            print("Der Gegenstand gehört nun dir.\n")
            WARTEN()
            print("Du steckst ihn ein und gehst weiter.\n")
            return True
        elif "hau" in antwort:
            if protagonist.karriere in ["Recke", "Gauner"]:
                spiel.strafpunkte += 1
                if protagonist.karriere == "Recke":
                    print("Mit einem mächtigen Hieb zersplitterst du die durchsichtige Kiste.\n")
                    WARTEN()
                else:
                    print("Du brauchst einige Schläge mit dem Dolch, aber schließlich gibt die Kiste nach.\n")
                    WARTEN()
                    print("Du erschaffst ein Loch, das groß genug ist, um die Hand durchzustecken "
                          "und den Gegenstand zu nehmen.\n")
                    WARTEN()
                print("Dem Meister dürfte dein Ansatz unter Umständen nicht gefallen, aber er müsste zumindest deine "
                      "Kreatitivät würdigen, nicht wahr?\n")
                WARTEN()
                print("Wie dem auch immer sei, der Gegenstand gehört nun dir.\n")
                WARTEN()
                print("Du steckst ihn ein und gehst weiter.\n")
                WARTEN()
                return True
            else:
                print("Was immer das für ein Material ist, gegen deine Waffe scheint es nicht immun zu sein.\n")
                WARTEN()
                continue
        elif "zauber" in antwort:
            spiel.strafpunkte += 1
            zaubern = zauber_pruefen(entsperren)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(entsperren)
                if probe:
                    print("Du gehst einmal in dich und wirkst einen Zauber, der die Kombination knacken kann.\n")
                    WARTEN()
                    print("Die Regler schieben sich wie von Zauberhand (haha) in die richtige Position, und die "
                          "Kiste geht auf.\n")
                    WARTEN()
                    print("Der Gegenstand gehört nun dir.\n")
                    WARTEN()
                    print("Du steckst ihn ein und gehst weiter.\n")
                    return True
                else:
                    WARTEN()
                    print("Deine Magie kann dir hier leider nicht helfen.\n")
                    WARTEN()
                    print("Du wirst einen anderen Weg suchen müssen, die Kiste zu öffnen.\n")
                    WARTEN()
                    continue
        elif "grips" in antwort:
            WARTEN()
            spiel.strafpunkte += 1
            probe = protagonist.gripsWurf(15)
            if probe:
                print("Du kannst die Buchstaben in die richtige Folge bringen.\n")
                WARTEN()
                print("Du bist nicht ganz sicher, was du da gemacht hast, aber das Rumprobieren hat sich "
                      "zumindest gelohnt.\n")
                WARTEN()
                print("Der Gegenstand gehört nun dir.\n")
                WARTEN()
                print("Du steckst ihn ein und gehst weiter.\n")
                return True
            else:
                continue
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            spiel.strafpunkte += 1
            print("Du drehst an den Reglern, aber es passiert nichts.\n")
            WARTEN()
            print("Vermutlich war die Kombination nicht richtig.\n")
            WARTEN()
            print("Leider führt an dieser blöden Kiste kein Weg vorbei, du brauchst den Gegenstand.\n")
            continue
    pass


def raetsel_zukunft():
    print("Du siehst einen eine Schachtel auf einem Podest. Als du dich näherst, scheint sich die Schwerkraft in der "
          "Gegend aber umzukehren.\n")
    WARTEN()
    print("Alle Gegenstände, die vorher auf dem waren - das schließt dich mit ein -, fliegen plötzlich in die Luft.\n")
    WARTEN()
    print("Du kannst dich in der Luft bewegen, kommst aber nicht von der Stelle.\n")
    WARTEN()
    print("Während du überlegst, wie du aus dieser Lage wieder herauskommen kannst, hörst du eine Stimme in deinem "
          "Kopf - einen Gedanken, der nicht dir gehört.\n")
    print(f"{Fore.YELLOW}\"Ich war nie da, und doch komme ich immer.\n")
    WARTEN()
    print("Niemand hat mich je gesehen oder wird es jemals tun.\n")
    WARTEN()
    print("Ich verheiße Angst und Hoffnung, den ich bin der Grund für alles, "
          "was passiert ist und was passiert wird\".\n")
    while True:
        antwort = input(f"Was bin ich?{Fore.GREEN}\n > ").lower()
        if "morgen" in antwort or "zukunft" in antwort:
            raetsel_zukunft_richtig()
            return True
        elif "grips" in antwort:
            WARTEN()
            spiel.strafpunkte += 1
            probe = protagonist.gripsWurf(15)
            print("Du denkst einmal scharf über die Lösung nach.\n")
            WARTEN()
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}die Zukunft{Fore.GREEN}. "
                      f"Wobei {Fore.YELLOW}das Morgen{Fore.GREEN} vermutlich auch gelten würde.\n")
                WARTEN()
                raetsel_zukunft_richtig()
                return True
            else:
                print("Leider fällt dir beim besten Willen nichts Gescheites ein.\n")
                WARTEN()
                continue
        elif "zauber" in antwort:
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    print("Du bist nicht sicher, welchen Zauber du gerade verwendest, aber du merkst, "
                          "dass du die Schwerkraft manipulieren kannst.\n")
                    WARTEN()
                    raetsel_zukunft_richtig()
                    return True
                else:
                    WARTEN()
                    raetsel_zukunft_falsch()
                    return False
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            raetsel_zukunft_falsch()
            return False


def raetsel_zukunft_richtig():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print("Die Schwerkraft scheint sich wieder zu normalisieren.\n")
    WARTEN()
    print("Langsam, aber sicher, senkt sich alles wieder ab, auf seinen Platz.\n")
    WARTEN()
    print("Nichts hält dich mehr davon ab, die Schachtel aufzumachen.\n")
    WARTEN()
    print(f"Darin findest du einen kuriosen Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}).\n")
    WARTEN()
    print("Du steckst den Gegenstand ein und machst weiter.\n")
    WARTEN()
    fortschritt_pruefen()
    return True


def raetsel_zukunft_falsch():
    print("Was immer du tust, es ist vergeblich.\n")
    WARTEN()
    print("Du bleibst in der Luft, bis dein potentieller Meister irgendwann vorbeikommt und dich befreit.\n")
    WARTEN()
    print("Sein Gesichtsausdruck sagt eigentlich alles.\n")
    WARTEN()
    spiel.epilog = True
    return False


def raetsel_k():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print(f"Vor dir liegt ein Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}).\n")
    WARTEN()
    print("Du nimmst ihn an dich und steckst ihn ein, doch während du noch dabei bist, schießen aus dem Boden scheinbar"
          "unendlich viele Spiegel.\n")
    WARTEN()
    print("Sie formen ein nahezu undurchdringliches Labyrinth.\n")
    WARTEN()
    print("Während du überlegst, wie du aus dieser Lage wieder rauskommst (du kannst es speziell hier versuchen, "
          "in dem du \"weghier\" (sic) eingibst), erscheint in einem der Spiegel ein "
          "Schriftzug:")
    WARTEN()
    print(f"{Fore.YELLOW}Ich bin das Ende deines Glück, und der Beginn eines jeden Krieges.\n")
    WARTEN()
    print(f"Ein Orakel findet mit mir seine Mitte, doch selbst der fähigste Meister wird mich niemals haben.\n")
    WARTEN()
    while True:
        antwort = input(f"Was bin ich?{Fore.GREEN}\n > ").lower()
        if "buchstabe" in antwort and "k" in antwort:
            raetsel_k_richtig()
            return True
        elif "grips" in antwort:
            WARTEN()
            spiel.strafpunkte += 1
            probe = protagonist.gripsWurf(15)
            print("Du denkst einmal scharf über das Rätsel nach.\n")
            WARTEN()
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}der Buchstabe \"K\"{Fore.GREEN}.\n")
                WARTEN()
                raetsel_k_richtig()
                return True
            else:
                print("Leider fällt dir auf Gedeih und Verderb nichts Gescheites ein.\n")
                WARTEN()
                continue
        elif "zauber" in antwort:
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    print("Du bist nicht sicher, welchen Zauber du gerade verwendest, aber du merkst, "
                          "dass du die Spiegel manipulieren kannst.\n")
                    WARTEN()
                    raetsel_k_richtig()
                    return True
                else:
                    spiel.strafpunkte += 1
                    print("Leider reicht deine Magie nicht aus, um die Spiegel wieder abzusenken.\n")
                    WARTEN()
                    print("Du musst nach einer anderen Lösung suchen.\n")
                    WARTEN()
                    continue
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        elif "weghier" in antwort:
            print("Du versuchst, die Falle auszutricksen, und den aus dem Labyrinth zu finden.\n")
            probe = protagonist.gripsWurf(16)
            if probe:
                print("Du irrst, eine Weile herum, findest letztlich aber doch einen Ausgang.\n")
                WARTEN()
                print("Sobald du aus dem Labyrinth raus bist, verschwinden die Spiegel wieder im Boden.\n")
                WARTEN()
                print("Als du dich umschaust, stellst du fest, dass du am Ende gerade mal einen Schritt von deinem "
                      "Labyrinth-Start entfernt bist.\n")
                WARTEN()
                print("Eine merkwürdige Falle. Aber gut, jetzt ist sie hinter dir, und du hast den Gegenstand.\n")
                WARTEN()
                fortschritt_pruefen()
                return True
            else:
                raetsel_k_falsch()
                return False
        else:
            raetsel_k_falsch()
            return False


def raetsel_k_richtig():
    print("Die Spiegel verschwinden wieder im Boden.\n")
    WARTEN()
    print("Der Weg ist wieder frei.\n")
    WARTEN()
    fortschritt_pruefen()
    return True


def raetsel_k_falsch():
    print("Leider schaffst du es nicht, eine Lösung für deine Lage zu finden.\n")
    WARTEN()
    print("Du kommst weder auf die richtige Lösung, "
          "noch kannst du selbst einen Weg aus dem Spiegel-Labyrinth finden.\n")
    WARTEN()
    print("Du bleibst in diesem Labyrinth, bis dein potentieller Meister vorbeikommt und dich befreit.\n")
    WARTEN()
    print("Er setzt an, um etwas zu sagen, aber du kannst dir schon denken, was gleich passiert.\n")
    WARTEN()
    spiel.epilog = True
    return False


def raetsel_sand():
    belohnung = zuffaelliger_gegenstand()
    protagonist.inventar.append(belohnung)
    spiel.quest_gegenstaende.append(belohnung)
    spiel.loot.remove(belohnung)
    print(f"Du siehst einen Gegenstand ({Fore.MAGENTA}{belohnung}{Fore.GREEN}) auf einem Podest.\n")
    WARTEN()
    print("Allem Anschein nach ist das einer der Gegenstände, die dein potentieller Meister haben wollte.\n")
    WARTEN()
    print("Als du nach ihm greifst, bildet sich um dich plötzlich eine Glaskuppel.\n")
    WARTEN()
    print("So kannst du natürlich nicht weitermachen.\n")
    WARTEN()
    print("Vermutlich könntest du die Kuppel aber zerbrechen (bzw. \"hauen\"), "
          "wenn du stark genug draufhauen kannst.\n")
    WARTEN()
    print("Während du überlegst, wie du da verfahren sollst, ertönt in deinem Kopf ein seltsames Flüstern.\n")
    WARTEN()
    print(f"{Fore.YELLOW}Ich errichte ganze Schlösser, und ich kann den mächtigsten Berg vernichten.\n")
    WARTEN()
    print(f"Viele kann ich blenden, doch Manchen helfe ich, etwas zu sehen.\n")
    while True:
        antwort = input(f"Was bin ich?{Fore.GREEN}\n > ").lower()
        if "sand" in antwort:
            raetsel_zukunft_richtig()
            return True
        elif "grips" in antwort:
            WARTEN()
            spiel.strafpunkte += 1
            probe = protagonist.gripsWurf(15)
            print("Du denkst einmal scharf über die Lösung nach.\n")
            WARTEN()
            if probe:
                print(f"Die Lösung ist {Fore.YELLOW}Sand{Fore.GREEN}.\n")
                WARTEN()
                raetsel_sand_richtig()
                return True
            else:
                print("Leider fällt dir beim besten Willen nichts Gescheites ein.\n")
                WARTEN()
                continue
        elif "zauber" in antwort:
            spiel.strafpunkte += 1
            zaubern = zauber_pruefen(manipulation_einfach)
            if not zaubern:
                continue
            else:
                probe = protagonist.kontrollwurf(manipulation_einfach)
                if probe:
                    WARTEN()
                    print("Du bist nicht sicher, welchen Zauber du gerade verwendest, aber du merkst, "
                          "dass du die Kuppel auch magisch auflösen kannst.\n")
                    WARTEN()
                    raetsel_sand_richtig()
                    return True
                else:
                    WARTEN()
                    raetsel_sand_falsch()
                    return False
        elif "raushier" in antwort:
            frage = programmende()
            if not frage:
                continue
        else:
            raetsel_sand_falsch()
            return False


def raetsel_sand_richtig():
    print("De Kuppel verschwindet wieder.\n")
    WARTEN()
    print("Der Weg zum Gegenstand (bzw. weiter) ist nun frei.\n")
    WARTEN()
    fortschritt_pruefen()
    return True


def raetsel_sand_falsch():
    spiel.strafpunkte += 1
    print("Die Kuppel füllt sich mit irgendeinem Duft, der eben noch nicht da war.\n")
    WARTEN()
    print("Du glaubst nicht, dass er lebensgefährlich ist.\n")
    WARTEN()
    print("Im Gegenteil: Der Duft ist ziemlich angenehm.\n")
    WARTEN()
    print("Berauschend angenehm!")
    WARTEN()
    probe = protagonist.willensWurf(15)
    if probe:
        print("Zum Glück bist du stark genug, diesem rausch zu wiederstehen.\n")
        WARTEN()
        if protagonist.geschlecht == "männlich":
            print("Du driftest zwar kurz ab, schüttelst dann aber den Kopf und bist wieder der Alte.\n")
        else:
            print("Du driftest zwar kurz ab, schüttelst dann aber den Kopf und bist wieder die Alte.\n")
        WARTEN()
        print("Dein Willensakt bleibt im Übrigen nicht unbemerkt.\n")
        WARTEN()
        raetsel_sand_richtig()
        return True
    else:
        print("Du weißt nicht, wie lange du den angenehmen Duft beschnüffelst, doch du wirst aus der schönen Träumerei "
              "herausgerissen, als dein Meister die Kuppel auflöst und dich befreit.\n")
        WARTEN()
        print("Oooooh, nein!\n")
        WARTEN()
        print("Wie viel Zeit ist bitte vergangen?\n")
        WARTEN()
        print("Du hast da einen ganz schlimmen verdacht, dass du die ganze restliche Prüfung über einfach nur da "
              "standest und die Luft geschnuppert hast.\n")
        WARTEN()
        print("Dein Verdacht bewahrheitet sich sehr schnell.\n")
        WARTEN()
        spiel.epilog = True
        return False


RAETSEL = [raetsel_witz, raetsel_feuer, raetsel_wolke, raetsel_karte, raetsel_stille, raetsel_buchstaben,
           raetsel_zukunft, raetsel_k, raetsel_sand]
