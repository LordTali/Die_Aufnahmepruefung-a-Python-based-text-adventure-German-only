from steuerelemente import WARTEN, hoppla
from raetsel import *
from fallen import *


def nordraum_1():
    print("Du betrittst den Raum hinter der massiven Tür, Gesicht gen Nord.\n")
    WARTEN()
    print("Was immer hier gewesen sein soll, nun ist es nur eine große Halle bar jeder Dekoration "
          "oder jeglichen erkennbaren Zwecks.\n")
    WARTEN()
    print("in anderen Worten: Der Raum ist praktisch leer.\n")
    WARTEN()
    print("Lediglich in der hinteren nördlichen Ecke siehst du eine rote Steinsäule.\n")
    WARTEN()
    print("Was dieser ganze Raum hier soll oder warum es so schwer war, hierher zu gelangen, "
          "entzieht sich deinem Verstand.\n")
    WARTEN()
    print("Jetzt hast du den ganzen Aufwand aber schon gemacht. Da kannst du dem auch genauso gut "
          "nachgehen, oder? \n")
    WARTEN()
    return


def frage_nordraum():
    while True:
        aktion = input("Wo willst du hin? (Optionen: Rote Säule, Süden) \n > ").lower()
        if "süd" in aktion:
            return aktion
        elif "säule" in aktion or "rot" in aktion:
            return aktion
        elif "raushier" in aktion:
            programmende()
            continue
        else:
            hoppla()


def nordraum_2():
    while True:
        antwort = input("Du kannst dich der Säule von Links oder von Rechts nähern. Oder du gehst weg. "
                        "Was tust du? \n > ").lower()
        if "rechts" in antwort:
            if spiel.falle_nord:
                print("Du kommst gefahrlos zur Säule.\n")
                WARTEN()
                print("Dort fällt dir etwas auf.\n")
                WARTEN()
            else:
                print("Du näherst dich der Säule, aber klar, warum würde es hier nach all dem Stress nicht auch noch "
                      "Fallen geben?\n")
                WARTEN()
                reaktion = falle()
                if reaktion:
                    print("Jetzt kommst du gefahrlos zur Säule.\n")
                    WARTEN()
                    print("Dort fällt dir etwas auf.\n")
                    WARTEN()
                    spiel.falle_nord = True
                else:
                    spiel.epilog = True
                    return
            if spiel.nordraum:
                print("Nachdem du den Gegenstand im Norden erhalten hast, gibt es hier für dich "
                      "nichts mehr von Interesse.\n")
                WARTEN()
                print("Daher machst du einige Schritte zurück.\n")
                WARTEN()
                return
            loesung = raetsel_aufgeben()
            if loesung:
                spiel.nordraum = True
                return
        elif "links" in antwort:
            print("Du näherst dich der Säule.\n")
            WARTEN()
            if spiel.nordraum:
                print("Nachdem du hier einen Gegenstand gefunden hast, "
                      "gibt es hier nichts mehr von Interesse.\n")
                WARTEN()
                print("Daher gehst du einige Schritte zurück.\n")
                continue
            else:
                print("Dort fällt dir etwas auf.\n")
                WARTEN()
                loesung = raetsel_aufgeben()
                if loesung:
                    protagonist.nordraum = True
                    return
                else:
                    spiel.epilog = True
                    return
        elif "weg" in antwort:
            print("Du machst einige Schritte zurück.\n")
            return
        elif "raushier" in antwort:
            programmende()
            continue
        else:
            hoppla()
