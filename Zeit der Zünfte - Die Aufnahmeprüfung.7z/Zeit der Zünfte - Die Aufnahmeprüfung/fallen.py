"""Diese Datei speichert die möglichen Fallen, die ein Spieler im Verlauf des Spiels auslösen kann.
Sie werden zufällig aus einer erweiterbaren Liste ausgewählt und ausgelöst."""

import random
from ende import programmende
from charakter import protagonist
from steuerelemente import *


def falle():
    funktion_falle = random.choice(FALLE)
    ausloeser = funktion_falle()
    if ausloeser:
        FALLE.remove(funktion_falle)
        return True
    else:
        return False


def falle_lasso():
    print("Dir fällt ein Stück Seil auf, das auf dem Boden liegt - leider erst im letzen Augenblick.\n")
    WARTEN()
    print("Das Seil schnell hoch, ein Lasso wickelt sich um dein Bein.\n")
    WARTEN()
    print("Du versuchst, auszuweichen\n")
    WARTEN()
    reaktion = rettung_lasso()
    if reaktion:
        return True
    else:
        print("Egal, was du tust, du kannst dich einfach nicht befreien.\n")
        WARTEN()
        print("Es bleibt dir nichts Anderes, als in dieser peinlichen Kopfüber-Position zu verharren, bis dein "
              "potentieller Meister eintrifft und dich befreit.\n")
        WARTEN()
        print("Seinem Gesichtsausdruck entnimmst du, dass du dir jegliche Fragen sparen kannst.\n")
        spiel.epilog = True
        return False


def rettung_lasso():
    reaktion = protagonist.geschickWurf(12)
    if reaktion:
        print("Du kannst der Falle gerade noch so entgehen.\n")
        WARTEN()
        return True
    else:
        print("Das Lasso schlingelt sich um dein Bein und reißt dich kopfüber in die Höhe.\n")
        WARTEN()
        if protagonist.bewaffnung.name not in ["Streithammer", "Zauberstab"]:
            print("Du kannst aber zumindest versuchen, dich wieder zu befreien.\n")
            WARTEN()
            print("Zum Glück hast du eine passende Waffe dabei.\n")
            if protagonist.bewaffnung.name in ["Sichel", "Sachs", "Dolch"]:
                ziel = 12
                print("Leider ist sie für diese Aufgabe nicht ideal, aber etwas Anderes hast du nun mal nicht.\n")
                WARTEN()
            else:
                print("Zum Glück hast du ein vergleichsweise langes Schwert dabei.\n")
                WARTEN()
                print("Stell dir vor, du hättest das mit einem kurzen Dolch oder so machen müssen!\n")
                WARTEN()
                ziel = 10
            probe = protagonist.kampf(ziel)
            if probe:
                print("Du kannst das Seil durchschneiden und fällt unsanft auf den Boden.\n")
                WARTEN()
                print("Das tut ordentlich weh, aber zumindest bist du wieder frei.\n")
                WARTEN()
                print("Peinlich, peinlich! Aber gut, weiter geht's.\n")
                return True
            else:
                return False
        if protagonist.bewaffnung.name in ["Streithammer", "Zauberstab"]:
            print("Leider hast du nichts dabei, um dich aus dieser Lage zu befreien.\n")
            WARTEN()
            return False
        else:
            print("Du kannst aber zumindest versuchen, das Lasso mit einem Zauber zu vergrößern.\n")
            probe = protagonist.kontrollwurf(3)
            if probe:
                print("Die Schlinge löst sich, und du fällst unsanft auf den Boden.\n")
                WARTEN()
                print("Das tut ordentlich weh, aber zumindest bist du wieder frei.\n")
                WARTEN()
                print("Peinlich, peinlich! Aber gut, weiter geht's.\n")
                return True
            else:
                return False


def falle_kaefig():
    print("Du bemerkst, wie ein großer Gitterkäfig auf dich fällt.\n")
    WARTEN()
    print("Du versuchst, auszuweichen.\n")
    WARTEN()
    probe = protagonist.geschickWurf(10)
    if probe:
        print("Du springst zur Seite und kannst dem Käfig gerade noch so ausweichen.\n")
        WARTEN()
        return True
    else:
        reaktion = rettung_kaefig()
        if reaktion:
            return True
        else:
            print("Was immer du tust, kommst du hier leider nicht weg.\n")
            WARTEN()
            print("Jetzt kannst du nur noch in diesem Käfig sitzen, und auf den Meister WARTEN.\n")
            WARTEN()
            print("Als dieser zurückkommt, sagt sein Gesicht mehr als Tausend Worte.\n")
            WARTEN()
            spiel.epilog = True
            return False


def rettung_kaefig():
    print("Du springst zur Seite, bist aber zu langsam.\n")
    WARTEN()
    print("Leider kannst du nicht viel gegen diese Lage machen.\n")
    WARTEN()
    if protagonist.karriere == "Zauberer":
        print("Höchstens den Käfig einmal kurz anheben und wegkriechen.\n")
        WARTEN()
        print("Ist nicht einfach, aber für einen Zauberer machbar.\n")
        probe = protagonist.kontrollwurf(4)
        if probe:
            print("Du kannst den Käfig kurz zum Schweben bringen und schnell in die Freiheit kriechen.\n")
            WARTEN()
            print("Das ist zwar peinlich, aber zumindest kannst du dein Prüfung fortsetzen.\n")
            WARTEN()
            return True
        else:
            return False
    else:
        return False


def falle_grube():
    print("Du bemerkst, dass unter dir eine Falltür ist - gerade noch rechtzeitig, bevor diese aufgeht.\n")
    WARTEN()
    print("Du versuchst, auszuweichen.\n")
    WARTEN()
    probe = protagonist.geschickWurf(12)
    if probe:
        print("Zum Glück kannst du noch rechtzeitig zurückspringen.\n")
        WARTEN()
        return True
    else:
        reaktion = rettung_grube()
        if reaktion:
            print("Du hast dir bei dieser Fallgrubenaktion wahrlich nicht mit Ruhm bekleckert.\n")
            WARTEN()
            print("Aber gut, zumindest bist du wieder draußen.\n")
            WARTEN()
            print("Weiter geht's!\n")
            WARTEN()
            return True
        else:
            print("Tja.\n")
            WARTEN()
            print("Viel Handlungsspielraum hattest du bei dieser Aktion wirklich nicht.\n")
            WARTEN()
            print("Leider hast du sie versemmelt.\n")
            WARTEN()
            print("Jetzt kannst du in dieser kalten Grube noch auf den Meister warten, der dich hoffentlich befreit.\n")
            WARTEN()
            print("Als er dich aufsucht, tut er das auch.\n")
            WARTEN()
            print("Sein Gesichtsausdruck lässt allerdings noch weniger Spielraum als deine Fallsituation übrig.\n")
            WARTEN()
            spiel.epilog = True
            return False


def rettung_grube():
    print("Du bist nicht schnell genug und fällst unsanft in eine Grube.\n")
    WARTEN()
    print("Das tut zwar weh, aber hätte schlimmer sie können\n")
    WARTEN()
    print("Zum Glück ist die Grube nicht besonders tief, du könntest also versuchen, hier wieder rauszukommen.\n")
    WARTEN()
    print("Klettern ist hier leider fast unmöglich, aber du versuchst es trotzdem.\n")
    WARTEN()
    if protagonist.karriere == "Zauberer" or protagonist.rasse == "Flug-Sim'iar":
        print("natürlich kannst du auch versuchen, dich selbst zum Schweben zu bringen, um hier davon zu fliegen.\n")
        WARTEN()
        while True:
            aktion = input("Was willst du tun? (Optionen: Klettern, Fliegen) \n > ")
            if "flie" in aktion:
                # Fliegende Sim'iari können dieser Falle ohne Probleme entgehen, sie haben ja Flügel.
                if protagonist.rasse == "Flug-Sim'iar":
                    print("Du warst nicht schnell genug, um den Fall zu verhindern. Aber zumindest hast du immer noch "
                          "Flügel, die dich mühelos aus der Fall befreien.\n")
                    WARTEN()
                    print("Du fliegst aus der Grube und landest sanft auf dem Steinboden.\n")
                    WARTEN()
                else:
                    # Zauberer können zwar rausfliegen, müssen dafür aber einen Kontrollwurf bestehen.
                    probe = protagonist.kontrollwurf(4)
                    if probe:
                        print("Du sammelst deine Kräfte, und hebst langsam ab.\n")
                        WARTEN()
                        print("Schon bald schwebst du aus der Grube und landest sanft auf dem Steinboden.\n")
                        WARTEN()
                        return True
                    else:
                        return False
            elif "klet" in aktion:
                # Mit genug Parcour-Glück kann man auch rausspringen/klettern.
                probe = protagonist.geschickWurf(15)
                if probe:
                    print("Du holst Schwung und stützt dich im Sprung ab, um wieder nach oben zu kommen.\n")
                    WARTEN()
                    return True
                else:
                    return False
            elif "raushier" in aktion:
                programmende()
            else:
                hoppla()
    WARTEN()
    probe = protagonist.geschickWurf(15)
    if probe:
        print("Du holst Schwung und stützt dich im Sprung ab, um wieder nach oben zu kommen.\n")
        WARTEN()
        return True
    else:
        return False
    pass


FALLE = [falle_lasso, falle_kaefig, falle_grube]
