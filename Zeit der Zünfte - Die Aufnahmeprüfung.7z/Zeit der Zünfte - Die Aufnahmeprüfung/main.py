"""
Diese Datei steuert den Programmablauf.
"""


""" 
\"Zeit der Zünfe: Die Aufnahmeprüfung\" (c) by Vitali Hänisch

\"Zeit der Zünfe: Die Aufnahmeprüfung\" is licensed under a
Creative Commons Attribution-NoDerivatives 4.0 International License
"""


import colorama
from ende import *
from navigation import *
from steuerelemente import *
from begegnungen import *
colorama.init()


def main():
    while True:
        while not spiel.epilog:
            navigation_spielstart()
            WARTEN()
            navigation_vorraum()
            while not spiel.epilog:
                zufallsbegegnung()      # Das Spiel prüft mögliche Kampfbegegnungen.
                if spiel.kampf:         # Das Spiel endet, falls der Spieler verliert.
                    break
                aktion = richtungswechsel()
                if "nord" in aktion and not spiel.massive_tuer:
                    probe = massive_tuer()
                    if probe:
                        spiel.massive_tuer = True
                        continue
                elif "nord" in aktion and spiel.massive_tuer:
                    navigation_nordraum()
                    continue
                elif "ost" in aktion:
                    navigation_ostraum()
                    continue
                elif "süd" in aktion:
                    print("Der Weg hinter dir ist verschlossen, bis deine Prüfung vorbei ist.\n")
                    WARTEN()
                    continue
                elif "west" in aktion:
                    print("Du gehst weiter in Richtung West.\n")
                    WARTEN()
                    navigation_westraum()
                    continue
                else:
                    hoppla()
            else:               # Die eigentliche Schleife wurde durch Epilog beendet. Jetzt durch break zur Auswertung.
                break
        else:
            if len(spiel.quest_gegenstaende) < 3:
                if spiel.kampf:                     # Der Charakter wurde im Kampf besiegt.
                    besiegt()
                elif protagonist.lebenskraft <= 0:  # Der Charakter ist auf 0 Lebenskraft gesunken, bevor 3 Gegenstände
                    kaputtgezaubert()               # gesammelt wurden. Das ist nur möglich, wenn eine Zauberdetonation
                else:                               # einritt.
                    durchgefallen()
            else:
                epilog()
                if protagonist.streichhoelzer == 0:  # Der Charakter hat keine Streichhölzer mehr und konnte das
                    totalversagen()                  # Abenteuer nicht einmal richtig beginnen.
                elif spiel.strafpunkte <= 0:         # Erfolg und Ende in Abhängigkeit von gesammelten Strafpunkten.
                    bestanden_ausgezeichnet()
                elif spiel.strafpunkte in range(1, 4):
                    bestanden_gut()
                elif spiel.strafpunkte in range(4, 6):
                    bestanden_passabel()
                else:
                    durchgefallen()
            frage = ende()               # Frage nach wiederholtem Spiel, wenn die Auswertung abgeschlossen ist.
            if not frage:
                print("Auf Wiedersehen!\n")
                WARTEN()
                print("Danke fürs Spielen!\n")
                WARTEN()
                quit()
            else:                               # Die Steuervariablen und der Charakter werden zurückgesetzt.
                spiel.zuruecksetzen()
                protagonist.zuruecksetzen()
                spiel.neues_spiel = True
                continue                        # Das Spiel wird neugestartet.



if __name__ == "__main__":
    main()

