"""
In dieser Datei befinden sich die Funktionen, mit denen Spieler ihren Charakter erstellen.
"""

import random
from steuerelemente import *
from charakter import protagonist
from colorama import Fore
from ende import programmende
from waffen import *


def charakter_name():
    while True:
        antwort = input("Gut, dann legen wir los. Aber... Wie heißt du eigentlich?\n > ")
        if antwort != "raushier":
            protagonist.name = antwort
            return
        else:
            programmende()


def charakter_geschlecht():
    print("Alles klar! Nächste Frage: Bist du männlich oder weiblich?\n")
    WARTEN()
    print("Was einen Charakter bei \"Zeit der Zünfte\" ausmacht, ist eher kompliziert, aber im Wesentlichen " 
          "werden die Charaktere von fünf Eigenschaften geprägt:\n")
    WARTEN()
    print("Kraft, Geschick, Grips, Körperbau, Empathie und Magie.\n")
    WARTEN()
    print("Männliche Charaktere verfügen - in der Regel - über mehr Kraft und Ausdauer, weibliche über mehr Geschick " 
          "und Empathie.\n")
    WARTEN()
    print("Keine Option ist besser oder schlechter als die andere, sie haben jedoch unterschiedliche Stärken.\n")
    WARTEN()
    while True:
        geschlecht = input("Was bist du (männlich/weiblich)?\n > ").lower()
        WARTEN()
        if "weib" in geschlecht:
            protagonist.geschlecht = "weiblich"
            protagonist.geschick += 2
            protagonist.empathie += 2
            return protagonist.geschlecht
        elif "män" in geschlecht or "man" in geschlecht:
            protagonist.geschlecht = "männlich"
            protagonist.kraft += 2
            protagonist.koerperbau += 2
            return protagonist.geschlecht
        elif "raushier" in geschlecht:
            programmende()
        else:
            hoppla()


def charakter_rasse():
    print(f"Alles klar, {protagonist.name}!\n")
    WARTEN()
    print("Nächste Frage: Welcher Rasse gehörst du an?\n")
    WARTEN()
    while True:
        frage = input("Bzw. willst du vorher mehr über die verfügbaren Rassen erfahren?\n > ").lower()
        if "ja" in frage:
            info_rassen()
            break
        elif "nein" in frage:
            print("Alles klar!\n")
            break
        else:
            hoppla()
    WARTEN()
    while True:
        rasse = input("Also, was bist du? \n > ").lower()
        if "mensch" in rasse:
            zufallswerte_mensch()           # Der Bonus/Malus von Menschen wird zufällig bestimmt.
            protagonist.rasse = "Mensch"
            protagonist.willen += 2
            protagonist.max_lebenskraft = 8 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "dunkel" in rasse:
            protagonist.rasse = "Dunkelelf"
            protagonist.geschick += 2
            protagonist.magie += 1
            protagonist.kontrollwuerfel += 1
            protagonist.max_zauberkraft += 2
            protagonist.zauberkraft = protagonist.max_zauberkraft
            protagonist.max_lebenskraft = 8 + protagonist.koerperbau // 2 + 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "elf" in rasse:
            protagonist.rasse = "Elf"
            protagonist.kraft -= 2
            protagonist.geschick += 2
            protagonist.magie += 1
            protagonist.empathie += 2
            protagonist.kontrollwuerfel += 1
            protagonist.max_zauberkraft += 2
            protagonist.zauberkraft = protagonist.max_zauberkraft
            protagonist.max_lebenskraft = 8 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "zwerg" in rasse:
            protagonist.rasse = "Zwerg"
            protagonist.kraft += 2
            protagonist.koerperbau += 2
            protagonist.geschick -= 2
            protagonist.willen += 2
            protagonist.max_lebenskraft = 12 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "ork" in rasse:
            protagonist.rasse = "Ork"
            protagonist.kraft += 4
            protagonist.verteidigung -= 4
            protagonist.max_lebenskraft = 10 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            protagonist.max_ausdauer += 2
            protagonist.ausdauer = protagonist.max_ausdauer
            return rasse
        elif "kurz" in rasse:
            protagonist.rasse = "Kurzling"
            protagonist.grips += 2
            protagonist.geschick += 4
            protagonist.empathie += 2
            protagonist.kraft -= 4
            if protagonist.kraft < 2:
                protagonist.kraft = 2
            protagonist.koerperbau -= 2
            if protagonist.koerperbau < 2:
                protagonist.koerperbau = 2
            protagonist.max_lebenskraft = 6 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "flug" in rasse:
            protagonist.rasse = "Flug-Sim'iar"
            protagonist.geschick += 2
            protagonist.grips -= 2
            if protagonist.grips < 2:
                protagonist.grips = 2
            protagonist.max_lebenskraft = 10 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "sim" in rasse:
            protagonist.rasse = "Sim'iar"
            protagonist.kraft += 2
            protagonist.geschick += 2
            if protagonist.grips < 2:
                protagonist.grips = 2
            protagonist.max_lebenskraft = 10 + protagonist.koerperbau // 2
            protagonist.lebenskraft = protagonist.max_lebenskraft
            return rasse
        elif "raushier" in rasse:
            programmende()
        else:
            hoppla()


def info_rassen():
    print(f"{Fore.BLUE}Menschen{Fore.GREEN} sind die einheimischen Bewohner der Spielwelt, Yarus.\n")
    WARTEN()
    print(f"Einst waren sie die einzige wirklich intelligente Rasse, die Land und Wasser nur unter "
          f"sich teilen musste.\n")
    WARTEN()
    print(f"Das änderte sich schlagartig mit einem Ereignis, das als der {Fore.YELLOW}\"Weltensturz\"{Fore.GREEN} in "
          f"die Geschichte einging.\n")
    WARTEN()
    print("Was danach folgte, war eine Zeit von extrem blutigen Konflikten und Verfolgung der Nichtmenschen "
          "(\"Neuankömmlinge\", wie sie manchmal abschätzig genannt werden).\n")
    WARTEN()
    print("Inzwischen sind die schlimmsten Konflikte jedoch vorbei.\n")
    WARTEN()
    print("Die meisten Nichtmenschen haben sich auf die eine der andere Weise in die menschliche Gesellschaft "
          "integriert, oder haben ein Stück Land nur für sich beansprucht.\n")
    WARTEN()
    print("Nicht, dass jetzt alles \"Friede, Freude, Eierkuchen\" wäre, wie man schön sagt, aber es ist... besser.\n")
    WARTEN()
    print("Vor allem für diejenigen, die es geschafft haben, in eine der lokalen Zünfte aufgenommen zu werden.\n")
    WARTEN()
    print("Im Vergleich mit den Nichtmenschen, haben Menschen zwar keine besonderen Stärken, "
          "dafür aber auch keine nennenswerten Schwächen.\n")
    WARTEN()
    print("Zumindest ist das die allgemeine Wahrnehmung.\n")
    WARTEN()
    print("Tatsächlich sind Menschen so zahlreich, dass es nur schwer vorher abzuschätzen ist, welche Vor- und "
          "Nachteile der Körper und Geist einer Person hat.\n")
    WARTEN()
    print("Nichtmenschen sind da anders.\n")
    WARTEN()
    print(f"{Fore.CYAN}Elfen{Fore.GREEN} sind ein naturverbundenes Volk, etwas größer und schlanker als Menschen. "
          f"Ganz wichtig: Die länglichen Ohren nicht vergessen! \n")
    WARTEN()
    print("Mit den Menschen können sie in Sachen Kraft zwar nicht sehr gut mithalten, sind aber wendiger und haben "
          "von Natur eine besondeere Verbindung zur Magie. \n")
    WARTEN()
    print(f"Etwas robuster, wenn auch weniger elegant, sind die mit den Elfen eng verwandten "
          f"{Fore.LIGHTCYAN_EX}Dunkelelfen{Fore.GREEN} - manchmal auch inkorrekterweise\n"
          f"als Nacht- oder Tiefenelfen, seltener als \"Elefiten\" bezeichnet.\n")
    WARTEN()
    print("Ihre Körper ist zwar eher menschlich als elfisch von der Größe her und etwas weniger delikat gebaut,\n"
          "die meisten Eigenschaften teilen sich die beiden Rassen aber weiterhin.\n")
    WARTEN()
    print("Das heißt, im biologischen Sinne tun sie das. Kulturell und vom Lebensraum her haben sie eigentlich mehr "
          "mit den Zwergen gemein,\naber das ist eine Geschichte für ein anderes Mal.\n")
    WARTEN()
    print("Ein angenehmer Nebeneffekt: Dunkelelfen können, genau wie die Zwerge, gut im Dunkeln sehen.\n")
    WARTEN()
    print(f"{Fore.RED}Zwerge{Fore.GREEN} sind im Vergleich etwas kurz geraten, aber wahrlich nicht zu unterschätzen.\n")
    WARTEN()
    print("Sie sind ein stämmiges, stark behaartes, brutal direktes und stoisches Volk, das auf seinesgleichen achtet, "
          "und ordentlich was einstecken kann.\n")
    WARTEN()
    print("Und was noch wichtiger ist: Sie können noch besser austeilen!\n")
    WARTEN()
    print(f"{Fore.LIGHTRED_EX}Orks{Fore.GREEN} sind in gemischtrassigen Gesellschaften ein seltener Anblick.\n")
    WARTEN()
    print(f"Entgegen der weit verbreiteten Meinung, sie seien von Natur aus böse, brutal und gefährlich, "
          f"ist zumindest der erste Teil nur bedingt wahr.\n")
    WARTEN()
    print("Tatsächlich haben Ork - sowohl biologisch als auch kulturell bedingt - ihr Leben lang mit Reizbarkeit und "
          "Wutanfällen zu kämpfen.\n")
    WARTEN()
    print("Das macht es ihnen schwierig, sich in eine andere Gesellschaft zu integrieren.\n")
    WARTEN()
    print("Die auf Gewalt und Dominanz aufgebaute soziale Struktur einer rein orkischen Gesellschaft macht es ihnen "
          "dabei nicht gerade einfacher.\n")
    WARTEN()
    print("Dennoch sind sie grundsätzlich dazu in der Lage.\n")
    WARTEN()
    print("Und wenn sie sich beherrschen können - und ihrem Umfeld beweisen können, dass sie nicht zwangsläufig "
          "eine Gefahr darstellen, \nkönnen sie sich durchaus in eine gemischtrassige Umgebung einfinden.\n")
    WARTEN()
    print("Angenehmer Nebeneffekt: Orks können genau wie Zwerge und Dunkelelfen gut im Dunkeln sehen.\n")
    WARTEN()
    print(f"{Fore.LIGHTWHITE_EX}Kurzlinge{Fore.GREEN} hingegen sind, wie der Name vermuten lässt, ein Volk und kleinen "
          f"und flinken Wesen mit einem kindlichen Charakter.\n")
    WARTEN()
    print("Rein physikalisch betrachtet sind sie den anderen Rassen deutlich unterlegen.\n")
    WARTEN()
    print("Daher verlassen sie sich eher auf ihr Einfallsreichtum, ihre List und ihre Wendigkeit "
          "denn auf (kaum vorhandene) physische Stärke.\n")
    WARTEN()
    print(f"Und dann wären da noch die {Fore.YELLOW}Sim'iari{Fore.GREEN} (ausgesprochen \"Ssimjari\"),\n"
          f"im Volksmund auch - meistens abwertend - als \"Affenvolk\" oder gar als \"Affenmenschen\" bezeichnet.\n")
    WARTEN()
    print("Tatsächlich sieht ein typischer Sim'iar sowohl einem Affen als auch einem Menschen recht ähnlich.\n")
    WARTEN()
    print("Mit einer selbst nach zwergischen Maßstäben extremen Körperbehaarung, einem starken Gebiss und dem "
          "gekrümmten Gang\n"
          "scheint ein solcher Vergleich offensichtlich.\n")
    WARTEN()
    print("Ganz zu schweigen von gelegentlichen Redeschwierigkeiten und dem Volksmund nach geringeren Intelligenz.\n")
    WARTEN()
    print("Dennoch sollte man weder ihre körperlichen Fähigkeiten noch ihren Verstand unterschätzen.\n")
    WARTEN()
    print("Zwar scheinen die Sim'iari im Vergleich mit anderen Rassen tatsächlich im Durchschnitt weniger intelligent "
          "zu sein, \naber auch sie können durchaus redegewandt, einfühlsam und erfinderisch sein.\n")
    WARTEN()
    print("Obendrein sind sie - in der Regel - auch noch ziemliche soziale Wesen.\n")
    WARTEN()
    print("Die Vorurteile über ihren Körper hingegen täuschen eindeutig über ihre angeborene Kraft und Beweglichkeit "
          "hinweg.\n")
    WARTEN()
    print("Das heißt: Für gewöhnlich. Auch die Sim'iari haben nämlich enge Blutsverwandte.\n")
    WARTEN()
    print("Im Gegensatz zu den Elfen wird bei den Sim'iari zwar keine Unterscheidung im Namen gemacht.\n")
    WARTEN()
    print("Sie haben jedoch eine Unterart, die zwar nicht ganz so körperlich stark und spürbar leichter ist, \n"
          "dafür aber über Flügeln verfügt, die sie über eine gewisse Distanz durch die Luft tragen können.\n")
    WARTEN()
    print(f"Nennen wir sie für die Zwecke dieses Spiels einfach \"{Fore.LIGHTYELLOW_EX}Flug-Sim'iari{Fore.GREEN}\".\n")
    WARTEN()
    print("Manche von diesen Rassen sind biologisch gesehen sogar kompatibel.\n")
    WARTEN()
    print("Das Thema der Mischlinge und Halbblüter ist wirklich spannen,\n"
          "aber lassen es wir hier am besten sein, bevor es zu kompliziert wird. ;) \n")
    return


def zufallswerte_mensch():                  # Hier wird der zufällige Bonus/Malus bestimmt.
    zufall = random.randint(1, 7)     # + 2 auf ein zufälliges Attribut
    if zufall == 1:
        protagonist.kraft += 2
    elif zufall == 2:
        protagonist.geschick += 2
    elif zufall == 3:
        protagonist.grips += 2
    elif zufall == 4:
        protagonist.koerperbau += 2
    elif zufall == 5:
        protagonist.empathie += 2
    elif zufall == 6:
        protagonist.magie += 2
    else:                                   # Bei einer 7 gibt es +4 auf eins und -4 auf ein anderes.
        bonus = random.randint(1, 6)
        if bonus == 1:
            protagonist.kraft += 4
        elif bonus == 2:
            protagonist.geschick += 4
        elif bonus == 3:
            protagonist.grips += 4
        elif bonus == 5:
            protagonist.empathie += 4
        else:
            protagonist.magie += 4
        malus = random.randint(1, 5)
        if bonus == malus:              # Bonus und Malus dürfen nicht gleich sein.
            malus += 1
            if malus > 5:
                if bonus != malus:
                    malus = 1
                else:
                    malus = 2
        if malus == 1:
            protagonist.kraft -= 4
            if protagonist.kraft < 2:
                protagonist.kraft = 2     # Kein Attribut außer Magie (die 0 sein kann) darf unter 2 sinken.
        elif malus == 2:
            if protagonist.geschick < 2:
                protagonist.geschick = 2
            protagonist.geschick -= 4
        elif malus == 3:
            protagonist.grips -= 4
            if protagonist.grips < 2:
                protagonist.grips = 2
        elif malus == 4:
            protagonist.empathie -= 4
            if protagonist.empathie < 2:
                protagonist.empathie = 2
        else:
            protagonist.magie -= 4
            if protagonist.magie < 0:
                protagonist.magie = 0
    return


def charakter_karriere():
    protagonist.ausdauer = protagonist.max_ausdauer
    zauberbonus = protagonist.magie // 2  # Jetzt kommt die Kontrollwürfelrechnung.
    for element in range(zauberbonus):    # Pro 2 Punkte in Magie gibt es einen neuen Kontrollwürfel.
        protagonist.kontrollwuerfel += 1
    print("Aha.\n")
    WARTEN()
    if protagonist.rasse == "Mensch":
        print("Es kann nicht einfach gewesen sein, bis zu diesem berühmten Meister vorzudringen.\n")
        WARTEN()
        print("Vermutlich hat dir die Tatsache, dass du ein Mensch bist, zumindest einen kleinen Wettbewerbsvorteil "
              "verschafft, wo der Meister doch selber ein Mensch ist und so... \n")
        WARTEN()
    else:
        print("Es war sicherlich nicht einfach, als Nichtmensch die Aufmerksamkeit eines menschlichen Meisters "
              "zu erlangen!\n")
        WARTEN()
        if protagonist.rasse == "Elf":
            print("Vielleicht hast du ihn letztlich aber doch mit deinem natürlichen Charme oder deiner Schönheit"
                  "beeindruckt.\n")
            WARTEN()
            print("Vielleicht war es aber auch deine Schnelligkeit, die Reflexe oder dein natürlicher "
                  "Hang zur Magie.\n")
            WARTEN()
        elif protagonist.rasse == "Dunkelelf":
            print("An deiner natürlichen Schönheit wird es jedenfalls wohl nicht gelegen haben, Dunkelelfen wird "
                  "diese nur selten nachgesagt.\n")
            WARTEN()
            print("Aber vielleicht waren es deine Direktheit, Zielstrebigkeit, die Schnelligkeit und die Reflexe...\n")
            WARTEN()
            print("Vielleicht aber auch dein natürlicher Hang zur Magie.\n")
            WARTEN()
        elif protagonist.rasse == "Zwerg":
            print("Vermutlich waren es letztlich deine Unnachgiebigkeit, Sturheit und Trotz, "
                  "die ihn letztlich überzeugte, deine Kandidatur in Betracht zu ziehen.")
            WARTEN()
            print("Vielleicht war es aber auch deine Stärke oder dein natürliche Begabung fürs Handwerk.\n")
            WARTEN()
        elif protagonist.rasse == "Ork":
            print("Du bezweifelst, dass es die Angst davor war, sämtliche Knochen gebrochen zu bekommen, die ihn "
                  "dabei getrieben hat. \n")
            WARTEN()
            print("Der Meister scheint nicht so leicht zu beeindrucken zu sein. Etwas an dir "
                  "hat ihn aber so halb überzeugt.\n")
            WARTEN()
            print("Vielleicht war es deine Stärke, Ausdauer oder vielleicht deine Unnachgiebigkeit.\n")
            WARTEN()
            print("Und vielleicht - hoffentlich wenigstens ein bisschen - die Angst.\n")
            WARTEN()
        elif protagonist.rasse == "Kurzling":
            print("Aber selbst so kleine und scheinbar nicht ernstzunehmende Wesen wie du kriegen und wieder eine "
                  "Chance, sich zu beweisen.\n")
            WARTEN()
            print("Vermutlich waren es deine Schnelligkeit, die Auffassungsgabe, und "
                  "vielleicht auch zumindest teilweise dein kindlich-offener Charakter, die den Aussschlag gaben.\n")
            WARTEN()
        else:
            print("Dann wiederum: Sim'iari sind nicht leicht zu übersehen.\n")
            WARTEN()
            print("Dein robuster Körperbau, dein Stärke, vielleicht auch die Stereotype brechende Auffassungsgabe "
                  "oder deine soziale Ader, haben sicherlich eine Rolle dabei gespielt.\n")
            WARTEN()
        WARTEN()
        print("Aber wie dem auch immer sei, hast du den Meister fast soweit, dich zu unterweisen.\n")
        WARTEN()
        print("Was ist eigentlich dein Ziel?\n")
        WARTEN()
        print("Vielleicht willst du zu einem starken Krieger werden, der mit Speer, Schwert und Schild das Land auf "
              "Abenteuersuche bereist?\n")
        WARTEN()
        print("Oder du hast eine stark ausgeprägte soziale Ader und willst etwas in dieser Richtung machen?\n")
        WARTEN()
        print("Möglicherweise willst du mit damit zu einer Spion werden, "
              "der jede noch so hartnäckige Tür aufbekommt?\n")
        WARTEN()
        print("Oder du hast vielleicht bereits ein gewisses magisches Talent und willst zu einem mächtigen Zauberer "
              "werden, der eines Tages mit Feuerbällen und Blitzen um sich werfen will?\n")
        WARTEN()
    while True:
        karriere = input("Was ist dein Schwerpunkt? (Optionen: Kampf, Soziales, Magie)\n > ").lower()
        if "kampf" in karriere:
            protagonist.kraft += 2
            protagonist.angriffsbonus += 3
            protagonist.max_ausdauer += 2
            protagonist.ausdauer += 2
            protagonist.reflexe += 2
            protagonist.karriere = "Recke"
            return
        elif "sozi" in karriere:
            protagonist.grips += 2
            protagonist.mechanik += 2
            protagonist.angriffsbonus += 1
            protagonist.karriere = "Gauner"
            return
        elif "magie" in karriere:
            protagonist.magie += 3
            protagonist.angriffsbonus += 1
            protagonist.kontrollwuerfel += 2 + (protagonist.magie // 2)
            protagonist.willen += 2
            protagonist.karriere = "Zauberer"
            protagonist.max_zauberkraft += 8
            protagonist.zauberkraft = protagonist.max_zauberkraft
            return
        elif "raushier" in karriere:
            programmende()
            continue
        else:
            print("Hoppla! Irgendwas hat an deiner Eingabe nicht funktioniert. Versuch es bitte noch einmal.\n")


def charakter_inventar():
    print("Zum Schluss gibt dir dein potentieller Meister noch etwas auf den Weg. Du sollst schließlich nicht komplett "
          "unvorbereitet hineingehen.\n")
    WARTEN()
    print("Du begibst dich zum Vereinbarten Zeitpunkt zum Prüfungsort, und stehst vor einer Art Höhle.\n")
    WARTEN()
    print("Eine massive Holztür versperrt den Eingang, daneben findest du einen Zettel.\n")
    WARTEN()
    print(f"\"{Fore.LIGHTWHITE_EX}Für {protagonist.name}!{Fore.GREEN}\", so die Schrift darauf. "
          f"Daneben liegen ein paar Gegenstände.\n")
    WARTEN()
    frage = waffenauswahl()
    if frage == "Zauberstab":
        protagonist.kontrollwuerfel += 1
    if protagonist.bewaffnung.name in ["Sichel", "Streitaxt", "Zweihändige Axt"]:
        print("Eine", end=" ")
    else:
        print("Ein", end=" ")
    if protagonist.karriere == "Gauner":
        print(f"{frage}, eine Haarklammer und Streichhölzer! Du bist dir nicht sicher, was der Meister mit dir "
              "vorhat, aber das wird schon seinen Grund haben. \n")
        protagonist.inventar.append("Haarklammer")
        WARTEN()
    else:
        print(f"{frage} und Streichhölzer! Du bist dir nicht sicher, was der Meister mit dir "
              "vorhat, aber das wird schon seinen Grund haben. \n")
        WARTEN()
        if protagonist.bewaffnung == "Zauberstab":
            print("Nicht, dass du einen Zauberstab wirklich brauchen würdest, aber er hilft "
                  "natürlich dabei, deine Zauberkraft zu fokussieren. Schaden kann er jedenfalls nicht.\n")
            WARTEN()
        print("Mit einer Waffe ín der Hand fühlst du dich jedenfalls gleich viel besser.\n")
        WARTEN()
    protagonist.inventar.append("Streichhölzer")
    WARTEN()
    print("Mit dieser Ausrüstung schließt du einmal kurz die Augen, atmest tief durch und sammelst deine Kräfte.\n")
    WARTEN()
    print("Dann machst du einen Schritt nach vorn und betrittst die Höhle.\n")
    return


def waffenauswahl():
    print(f"{Fore.WHITE}[Für dieses Abenteuer darfst du dir selbst aussuchen, was deine Waffe sein wird.]\n")
    WARTEN()
    print("[Hoffentlich wirst du sie nicht brauchen, aber man kann nie wissen.]\n")
    WARTEN()
    print("[Hier ist die Auswahl, die dein potentieller Meister für dich rausgesucht hat:]\n")
    if protagonist.karriere == "Recke":
        waffen = [dolch, kurzschwert, langschwert, sachs, sichel, streitaxt, streithammer, zweihaendige_axt]
    elif protagonist.karriere == "Gauner":
        waffen = [dolch, sachs, sichel]
    else:
        waffen = [dolch, sachs, zauberstab]
    for waffe in waffen:
        if waffe == waffen[-1]:
            print(f"{Fore.YELLOW}{waffe.name}{Fore.WHITE}", end="\n\n")
        else:
            print(f"{Fore.YELLOW}{waffe.name}{Fore.WHITE}", end=", ")
    WARTEN()
    while True:
        frage = input(f"{Fore.GREEN}Willst du mehr über deine Optionen erfahren?\n > ").lower()
        if "ja" in frage:
            for waffe in waffen:
                print(f"{Fore.YELLOW}{waffe.name}:\n")
                PAUSE()
                print(f"Gattung: {waffe.gattung}")
                PAUSE()
                print(f"Tödlichkeit: {waffe.toedlichkeit}")
                PAUSE()
                print(f"Belastung: {waffe.belastung}")
                PAUSE()
                print(f"Angriffsmalus: {waffe.angriffsmalus}")
                PAUSE()
                print(f"Verteidigungsmalus: {waffe.verteidigungsmalus}")
                PAUSE()
                print(f"\n{Fore.WHITE}")
                WARTEN()
            print("[Jede Waffe hat ihre Vor- und Nachteile, objektiv ist aber keine besser als die andere.]\n")
            WARTEN()
            print("[Über Waffen erfährst du mehr, falls du dich tatsächlich in einer Kampfsituation findest.]\n")
            WARTEN()
            print("[Für den Moment reicht es zu wissen, dass du mit unterschiedlichen Waffen deine Gegner "
                  "besser oder schlechter treffen bzw. verletzten kannst.]\n")
            WARTEN()
            print(f"[Und je höher die Belastung ist, desto schneller wirst du im Kampf müde.]{Fore.GREEN}\n")
            WARTEN()
            break
        elif "nein" in frage:
            break
        elif "raushier" in frage:
            programmende()
        else:
            hoppla()
    waffe_gefunden = False
    while not waffe_gefunden:
        frage = input("Welche Waffe willst du zu dieser Prüfung mitnehmen?\n > ").lower()
        for waffe in waffen:
            if frage == waffe.name.lower():
                protagonist.bewaffnung = waffe
                protagonist.inventar.append(waffe.name)
                waffe_gefunden = True
                return waffe.name
            elif "raushier" in frage:
                programmende()
            else:
                pass
        if not waffe_gefunden:
            hoppla()


def charakter_anzeigen():
    print(f"{Fore.WHITE}[Herzlichen Glückwunsch! Dein Charakter ist fertig und im Einsatz.]\n")
    WARTEN()
    print(f"[Das ist dein hoffnungsfroher Kandidat für die Ausbildung:]{Fore.YELLOW}\n")
    WARTEN()
    print(f"Name:                   {protagonist.name}")
    PAUSE()
    print(f"Gechlecht:              {protagonist.geschlecht}")
    PAUSE()
    print(f"Rasse:                  {protagonist.rasse}")
    PAUSE()
    print(f"(angestrebte) Klasse:   {protagonist.karriere}")
    PAUSE()
    print(f"Kraft:                  {protagonist.kraft}")
    PAUSE()
    print(f"Geschick:               {protagonist.geschick}")
    PAUSE()
    print(f"Grips:                  {protagonist.grips}")
    PAUSE()
    print(f"Körperbau:              {protagonist.koerperbau}")
    PAUSE()
    print(f"Empathie:               {protagonist.empathie}")
    PAUSE()
    print(f"Magie:                  {protagonist.magie}")
    PAUSE()
    print(f"Kontrollwürfel:         {protagonist.kontrollwuerfel}")
    PAUSE()
    print(f"Verteidigung:           {protagonist.verteidigung}")
    PAUSE()
    print(f"Willen:                 {protagonist.willen}")
    PAUSE()
    print(f"Reflexe:                {protagonist.reflexe}")
    PAUSE()
    print(f"Fertigkeit (Mechanik):  {protagonist.mechanik}")
    PAUSE()
    print(f"Lebenskraft:            {protagonist.lebenskraft}/{protagonist.max_lebenskraft}")
    PAUSE()
    print(f"Ausdauer:               {protagonist.ausdauer}/{protagonist.max_ausdauer}")
    PAUSE()
    print(f"Zauberkraft:            {protagonist.zauberkraft}/{protagonist.max_zauberkraft}")
    PAUSE()
    print(f"Inventar:               {", ".join(protagonist.inventar)}\n")
    WARTEN()
    print(f"{Fore.WHITE}[Mit diesen Werten wirst du in diesem Durchlauf spielen.]\n")
    WARTEN()
    print(f"[Mach dich ruhig damit Vertraut.]{Fore.GREEN}\n")
    WARTEN()
    while True:
        befehl = input("Gib \"weiter\" ein, um das Abenteuer zu beginnen, wenn du soweit bist.\n > ")
        if "weiter" in befehl:
            return
        elif "raushier" in befehl:
            programmende()
        else:
            hoppla()
