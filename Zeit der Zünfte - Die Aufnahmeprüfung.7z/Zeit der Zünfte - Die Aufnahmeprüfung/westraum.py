"""
In dieser Datei sind die Aktionen im Westraum gespeichert.
"""

from raetsel import *
from fallen import *

# Grün = gelber Schlüssel, Rot = Loot, Gelb = Falle


def westraum_1():
    print("Du betrittst einen riesigen Raum zu deiner Linken, Gesicht gen West.\n")
    WARTEN()
    print("der von der Machart und der (fehlenden) Dekoration her allerdings auch sehr schlicht.\n")
    WARTEN()
    print("Andere Ein- oder Ausgänge siehst du hier nicht, dafür aber mehrere Steinsäulen, "
          "die über den Raum verstreut sind.\n")
    WARTEN()
    print("Am westlichen Ende des Raums entdeckst du zwei grau angestrichene Säulen - "
          "warum auch immer jemand Stein noch extra grau anmalen würde.\n")
    WARTEN()
    print("Etwas weiter rechts davon, mehr Richtung Norden, entdeckst du eine ziemlich lange und große Säule, "
          "die mehr wie eine Trennwand denn nur eine Säule wirkt.\n")
    WARTEN()
    print("Sie weist hier und da gelben Anstrich auf.\n")
    WARTEN()
    print("Östlicher davon, fast direkt zu deiner Rechten, sind zwei rot angestrichene Säulen, "
          "die nebeneinander stehen.\n")
    WARTEN()
    print("Eine blau angestrichene Säule befindet sich im hinteren Bereich, gen Norden.\n")
    WARTEN()
    print("Nur etwas westlicher davon siehst du eine grüne Säule.\n")
    WARTEN()
    print("Direkt hinter dir, gen Ost, befindet sich der einzige Ausgang aus dem Raum, "
          "durch den du reingekommen bist.\n")
    return


def westraum_2():
    while not spiel.epilog:
        antwort = input("Wo willst du hin? (Optionen: Graue Säulen, gelbe Säule, grüne Säule, blaue Säule, "
                        "rote Säulen, Osten)\n > ").lower()
        if "ost" in antwort:
            return antwort
        elif "grau" in antwort:
            return antwort
        elif "gelb" in antwort:
            return antwort
        elif "rot" in antwort:
            return antwort
        elif "blau" in antwort:
            return antwort
        elif "grün" in antwort:
            return antwort
        elif "raushier" in antwort:
            programmende()
            continue
        else:
            hoppla()
    else:
        return


def westraum_grau():
    print("Du untersuchst die grauen Säulen.\n")
    WARTEN()
    print("Du findest irgendwelchen Ramsch zwischen den Säulen, aber du glaubst nicht, dass es für deine "
          "Prüfung von Bedeutung ist.\n")
    return


def westraum_rot():
    print("Du untersuchst den Raum zwischen zwei roten Säulen.\n")
    WARTEN()
    if spiel.westraum:
        print("Nachdem du hier einen Gegenstand gefunden hast, "
              "gibt es hier nichts mehr von Interesse.\n")
        WARTEN()
        print("Daher gehst du einige Schritte zurück.\n")
        return
    else:
        print("Dabei fällt dir etwas auf.\n")
        WARTEN()
        loesung = raetsel_aufgeben()
        if loesung:
            spiel.westraum = True
            WARTEN()
            return
        else:
            spiel.epilog = True
            return


def westraum_blau():
    print("Du untersuchst die blaue Säule.\n")
    WARTEN()
    print("Leider findest du hier nichts von Interesse.\n")
    WARTEN()
    print("So eine Zeitverschwendung!\n")
    WARTEN()
    return


def westraum_gelb():
    print("Du willst die gelbe Säule untersuchen.\n")
    WARTEN()
    while True:
        aktion = input("Willst du dich von Links oder Rechts nähern?\n > ").lower()
        if "rechts" in aktion:
            print("Du näherst dich der Säule von Rechts an.\n")
            WARTEN()
            if spiel.falle_west:
                print("Nachdem du die Falle bereits überstanden und das Geld gefunden hast, gibt es hier für dich "
                      "nichts mehr von Interesse. Daher machst wieder einige Schritte zurück.\n")
                WARTEN()
                return
            else:
                print("Dabei wird dir klar: Irgendeinen Haken MUSSTE dieser Raum einfach haben.\n")
                WARTEN()
                if spiel.falle_west:
                    print("Nachdem du die Falle überstanden und die Münze gefunden hast, "
                          "gibt es hier für dich nichts mehr von Interesse.\n)")
                    WARTEN()
                    print("Daher machst du einige Schritte zurück.\n")
                    WARTEN()
                    return
                else:
                    reaktion = falle()
                    if reaktion:
                        spiel.falle_west = True
                        protagonist.inventar.append("Goldmünze")
                        print("Nachdem du die Falle überstanden hast, kannst du dich gefahrlos der Säule nähern.\n")
                        WARTEN()
                        print("Zwischen den Säulen in der Säule findest du eine Goldmünze.\n")
                        WARTEN()
                        print("Du bezweifelst sehr stark, dass sie irgendwas mit deiner Prüfung zu tun hat.\n")
                        WARTEN()
                        print("Aber auf der positiven Seite kannst du sie jetzt wahrscheinlich behalten.\n")
                        WARTEN()
                        print("Für eine gute Feier in deiner Stammschenke sollte sie allemal reichen.\n")
                        WARTEN()
                        return
                    else:
                        spiel.epilog = True
                        return
        elif "link" in aktion:
            print("Du näherst dich der blauen und der grünen Säule von Links.\n")
            WARTEN()
            print("Leider entdeckst du hier nichts außer Staub.\n")
            WARTEN()
            print("Vielleicht noch eine Spinne, aber so genau willst du da nicht hinsehen. Igitt!\n")
            WARTEN()
            return
        elif "raushier" in aktion:
            programmende()
            continue
        else:
            hoppla()


def westraum_gruen():
    if "gelber Schlüssel" in protagonist.inventar:
        print("Nachdem du den Schlüssel gefunden hast, gibt es hier nichts mehr von Interesse.\n")
        WARTEN()
        return
    else:
        protagonist.inventar.append("gelber Schlüssel")
        print("Du untersuchst die grüne Säule.\n")
        WARTEN()
        print(f"Zwischen den Rissen im Gestein findest du einen merkwürdigen Gegenstand: "
              f"einen {Fore.YELLOW}gelben Schlüssel{Fore.GREEN}.\n")
        WARTEN()
        print("Du steckst den Gegenstand ein und machst weiter. \n")
        WARTEN()
        return
