from colorama import *
from steuerelemente import *
from charakter import protagonist


def programmende():
    while True:
        eingabe = input("Willst du das Programm wirklich verlassen?\n > ").lower()
        if "ja" in eingabe:
            print("Auf Wiederesehen! Danke fürs Spielen!")
            WARTEN()
            quit()
        elif "nein" in eingabe:
            return False
        else:
            hoppla()


def ende():
    while True:
        aufforderung = input("Willst du noch einmal spielen? \n > ").lower()
        if "ja" in aufforderung:
            WARTEN()
            return True
        elif "nein" in aufforderung:
            WARTEN()
            quit()
        else:
            print("Hoppla! Irgendwas hat an deiner Eingabe nicht funktioniert. Versuch es bitte noch einmal.\n")


def epilog():
    print("Du kommst wieder in den Vorraum, wo dein potentieller Meister dich bereits "
          "vor der offenen Eingangstür erwartet.\n")
    WARTEN()
    print(f"Derzeit trägst du die folgenden Gegenstände bei dir: "
          f"{Fore.BLUE}{", ".join(protagonist.inventar)}{Fore.GREEN}.\n")
    WARTEN()
    print(f"Du kramst in deinen Taschen bzw. dem kleinen Rucksack und präsentierst "
          f"ihm deine Funde: {Fore.MAGENTA}{", ".join(spiel.quest_gegenstaende)}{Fore.GREEN}.\n")
    WARTEN()
    print("Der Meister lächelt und nickt zufrieden.\n")
    WARTEN()
    print(f"\"{Fore.MAGENTA}Sehr gut, {protagonist.name}! Du hast dich den Herausforderungen gestellt "
          f"und sie überwunden.\n")
    WARTEN()
    print(f"Das ehrt deine Fähigkeit, Dinge zum Abschluss zu bringen.{Fore.GREEN}\", sagt er.\n")
    WARTEN()
    print(f"\"{Fore.MAGENTA}Der Weg zum Ziel ist aber genauso wichtig wie das Ziel selbst!\n")
    WARTEN()
    print("Die Fertigkeiten, die jemand hat, sollten nicht leichtfertig eingesetzt werden.\n")
    WARTEN()
    print(f"Setzt du sie ein, um alles wahllos kurz und klein zu schlagen, verschwendest du deine Magiekenntnisse, "
          f"handelst unüberlegt oder bist tollpatschig, dann kreide ich dir das an.{Fore.GREEN}\"\n")
    WARTEN()
    if spiel.kampf_zaehler > 0:
        print(f"{Fore.MAGENTA}Andererseits hast du in meinem Prüfungsgewölbe Gefahren getrotzt, "
              f"die nicht vorgesehen waren.\n")
        WARTEN()
        print("Das tut mir Leid, ich hätte das Gewölbe vorher lieber noch einma überprüfen sollen.\n")
        WARTEN()
        print("Aber du hast dich tapfer geschlagen! Und das sei dir angerechnet.\n")
        WARTEN()
    print(f"Damit geht er deinen Weg durch seinen {protagonist.wort_fuer_dungeon()} einmal durch.\n")
    WARTEN()
    if spiel.strafpunkte == 1:
        print(f"Für dein Vorgehen bei deinem Abenteuer bekommst du {Fore.LIGHTRED_EX}{spiel.strafpunkte} "
              f"Strafpunkt.\n{Fore.GREEN}")
    else:
        print(f"Für dein Vorgehen bei deinem Abenteuer bekommst du {Fore.LIGHTRED_EX}{spiel.strafpunkte} "
              f"Strafpunkte.\n{Fore.GREEN}")
        if spiel.strafpunkte < 0:
            print("Selbst, wenn du dir Fehltritte geleistet hast, kann das Ergebnis nur bedeuten, dass du eindeutig "
                  "mehr richtig als falsch gemacht hast.\n")
            WARTEN()
    WARTEN()
    print("Der Meister nickt nachdenklich und streichelt seinen Bart. Nach einer Weile fällt er sein Urteil.\n")
    WARTEN()
    return


def totalversagen():
    print("Und jetzt ist auch dein letztes Streichholz weg. Ohne eine Möglichkeit, dich in dieser "
          "Dunkelheit zurecht zu finden, bleibt dir nichts Anderes übrig, als auf deinen potentiellen "
          "Meister zu warten. \n")
    WARTEN()
    print("Allein.\n")
    WARTEN()
    print("Im Dunkeln.\n")
    WARTEN()
    print("Als der Meister zurückkommt, versucht er nicht einmal, seine Enttäuschung zu verbergen.\n")
    WARTEN()
    print("Du bist nicht einmal fünf Schritte in die Höhle vorgedrungen.\n")
    WARTEN()
    print("Worte können nicht einmal beginnen, zu beschreiben, wie peinlich das ist.\n")
    WARTEN()
    print("Von diesem Karrierewunsch kannst du dich jedenfalls getrost verabschieden.\n")
    WARTEN()
    print("Sofern du nicht doch irgendwie noch einen anderen Meister finden kannst.\n")
    WARTEN()
    print("Fürs Erste solltest du dich aber direkt nach Hause begeben und die Schande verarbeiten.\n")
    WARTEN()
    print("Und während du die Höhle mit gesenktem Kopf verlässt, vernimmst du nur ein kaum hörbares "
          "Seufzen hinter deinem Rücken.\n")
    WARTEN()
    print("Wie es scheint, hast du sogar die niedrigsten Erwartungen noch unterboten.\n")
    WARTEN()
    print("Viel Glück beim nächsten Mal!\n")
    WARTEN()
    print("[Ende]\n")
    WARTEN()
    return


def durchgefallen():
    print("Das Ergebnis deiner Prüfung ist klar.\n")
    WARTEN()
    print("Du hast dich angestrengt, die Prüfung des Meisters hast du aber eindeutig nicht bestanden.\n")
    WARTEN()
    print("Dir bleibt also nichts Anderes übrig, als mit gesenktem Kopf kehrt zu machen, und die Höhle zu verlassen.\n")
    WARTEN()
    print("Du begibst dich direkt nach Hause, um dein Versagen zu verarbeiten.\n")
    WARTEN()
    print("Sofern du nicht irgendwo irgendwie einen anderen Meister finden kannst, hat sich dein Traum von der "
          "Karriere in einer Abenteurer-Gilde damit endgültig erledigt.\n")
    WARTEN()
    print("Aber zumindest hast du es versucht! Das kann dir keiner nehmen.\n")
    WARTEN()
    print("Sicherlich wird das immerhin für einige (natürlich etwas beschönigte!) Geschichten in deiner Stammschenke "
          "sorgen.\n")
    WARTEN()
    print("Womöglich könntest du damit sogar ein Interesse von einem Objekt deiner Begierde für dich gewinnen!\n")
    WARTEN()
    print("Die Zeit wird es zeigen. Fürs Erste hat sich dein Abenteuer jedenfalls erledigt.\n")
    WARTEN()
    print("Du gehst heim. Erst mal ausschlafen.\n")
    WARTEN()
    print("Bei den Göttern, du kannst das wirklich gebrauchen!\n")
    WARTEN()
    print("[Ende]\n")
    WARTEN()
    return


def bestanden_ausgezeichnet():
    print("Dein Meister ist nicht nur zufrieden - er ist absolut baff!\n")
    WARTEN()
    print("Es kommt selten vor, dass jemand seine Prüfung so makellos meistert.\n")
    WARTEN()
    print("Dass er dich unterweisen und deine Fertigkeiten ausfeilen will, ist nicht nur keine Frage - "
          "er würde es als eine Ehre ansehen.\n")
    WARTEN()
    print("Dafür will er von dir nicht einmal Lehrgeld oder Ersatzleistungen.\n")
    WARTEN()
    print(f"So geh also in die Schenke und lass dich feiern, {protagonist.name}, du hast dir wahrlich verdient!\n")
    WARTEN()
    print("Lass dich nur nicht zu sehr gehen. Du musst heute früh ins Bett, die Ausbildung geht direkt morgen los.\n")
    WARTEN()
    print("Noch einmal herzlichen Glückwunsch! Du bist auf dem besten Weg, ein Abenteurer in einer "
          "richtigen Zunft zu werden!\n")
    WARTEN()
    print("Hurra! Ein Hoch auf dich! \n")
    WARTEN()
    print("Ende\n")
    WARTEN()
    return


def bestanden_gut():
    print("Du hast dir ein paar Fehltritte geleistet, so viel steht fest.\n")
    WARTEN()
    print("Dann wiederum: Kaum jemand ist zum wahren Abenteurer geboren.\n")
    WARTEN()
    print("Im Großen und Ganzen hast du die Aufgabe trotzdem gut gemeistert.\n")
    WARTEN()
    print(f"Der Meister - {Fore.LIGHTGREEN_EX} dein Meister {Fore.GREEN}- schaut dich an und lächelt.\n")
    WARTEN()
    print("Du bist kein perfekter Kandidat, aber du hast auf jeden Fall Talent. "
          "Deine vielversprechende Leistung hat ihn letztlich überzeugt.\n")
    WARTEN()
    print(f"So geh also in die Schenke, {protagonist.name}, du hast heute einen Grund zum Feiern!\n")
    WARTEN()
    print("Lass dich nur nicht zu sehr gehen. Du musst heute früh ins Bett, die Ausbildung geht direkt morgen los.\n")
    WARTEN()
    print("Du bist jetzt auf dem besten Weg, ein Abenteurer in einer richtigen Zunft zu werden!\n")
    WARTEN()
    print("Hurra! Herzlichen Glückwunsch! \n")
    WARTEN()
    print("Ende\n")
    WARTEN()
    return


def bestanden_passabel():
    print("Du hast dich bei deiner Leistung wahrlich nicht mit Ruhm bekleckert, wie man's dreht und wendet.\n")
    WARTEN()
    print("Vielleicht war es die Aufregung, vielleicht deine unüberlegte Art, vielleicht auch nur Pech.\n")
    WARTEN()
    print("Dennoch: Insgesamt warst du nicht so schlecht, dass der Meister dich abweisen würde.\n")
    WARTEN()
    print("Du bist dir nicht ganz sicher, was genau an deinem Ergebnis ihn doch noch positiv gestimmt hat, "
          "aber im Grunde sind solche Überlegungen zweitrangig.\n")
    WARTEN()
    print("Immerhin hast du es geschafft! Du hast einen berühmten Meister überzeugen können, dich zu unterweisen.\n")
    WARTEN()
    print("Du bist auf dem Weg, ein richtiger Abenteurer in einer Zunft zu werden. "
          "Das ist eine reife Leistung für sich!\n")
    WARTEN()
    print(f"So geh also in die Schenke, {protagonist.name}, du hast heute einen Grund zum Feiern!\n")
    WARTEN()
    print("Lass dich nur nicht zu sehr gehen. Du musst heute früh ins Bett, die Ausbildung geht direkt morgen los.\n")
    WARTEN()
    print("Herzlichen Glückwunsch! \n")
    WARTEN()
    print("Ende\n")
    WARTEN()
    return


def kaputtgezaubert():
    print("Die Explosion ist zu stark, und du brichst zusammen.\n")
    WARTEN()
    print("Du bist dir nicht sicher, wie lange du bewusstlos warst, aber als du wieder zu dir kommst, bist du "
          "in einem Bett.\n")
    WARTEN()
    print("Du fühlst dich wie gerädert. Und wenn du die Menge an Verbandszeug und Medizin um dich herum betrachtest, "
          "ist dein Gefühl vermutlich gar nicht so falsch.\n")
    WARTEN()
    print("Du versuchst, dich zu bewegen, aber dein Körper tut derart weh, dass du dir das Stöhnen nicht verkneifen "
          "kannst\n")
    WARTEN()
    print("Schon bald kommt ein Medikus, um nach dir zu schauen. Dann klärt er dich auf, was passiert ist.\n")
    WARTEN()
    print(f"Dein potentieller Meister hat dich verletzt und bewusstlos in seinem {protagonist.wort_fuer_dungeon()} "
          f"vorgefunden.\n")
    WARTEN()
    print("Physisch gesehen hat die Zauberdetonation keinen bleibenden Schaden angerichtet, aber für die nächsten "
          "Wochen solltest du starke Anstrengung vermeiden.\n")
    WARTEN()
    print("Dass sich deine Aufnahmeprüfung damit für jetzt und - zumindest für speziell diesen Meister - für immer "
          "erledigt hat, muss er nicht hinzufügen. Das verstehst du auch selbst.\n")
    WARTEN()
    print("Jetzt kannst du nur noch hoffen, dein Glück nach der Genesung woanders zu probieren.\n")
    WARTEN()
    print("Schlimmstenfalls war's das mit den Abenteuern in einer Zunft. Aber du gibst die Hoffnung noch nicht auf.\n")
    WARTEN()
    print("Und zumindest übernimmt der Meister die Behandlungskosten, wie von der Zunft vorgeschrieben. Lass das "
          "vorerst dein Trost sein.\n")
    WARTEN()
    print("Ende.\n")
    WARTEN()
    return


def besiegt():
    print("Gerade als das Monster zum letzten Schlag ansetzt, wird es von einem Blitz getroffen und flüchtet.\n")
    WARTEN()
    print("Bevor du das Bewusstsein verlierst, sieht du kurz deinen potentiellen Meister, der dir zu Hilfe eilt.\n")
    print("Du bist dir nicht sicher, wie lange du bewusstlos warst, aber als du wieder zu dir kommst, bist du "
          "in einem Bett.\n")
    WARTEN()
    print("Du fühlst dich wie gerädert. Und wenn du die Menge an Verbandszeug und Medizin um dich herum betrachtest, "
          "ist dein Gefühl vermutlich gar nicht so falsch.\n")
    WARTEN()
    print("Du versuchst, dich zu bewegen, aber dein Körper tut derart weh, dass du dir das Stöhnen nicht verkneifen "
          "kannst\n")
    WARTEN()
    print("Schon bald kommt ein Medikus, um nach dir zu schauen. Dann klärt er dich auf, was passiert ist.\n")
    WARTEN()
    print(f"Dein potentieller Meister hat plötzlich eine Gefahr gespürt und eilte in seinem "
          f"{protagonist.wort_fuer_dungeon()}.\n")
    WARTEN()
    print("Ein Kampf gegen Monster gehört bei ihm nämlich nicht zu den Prüfungen für Anwärter.\n")
    WARTEN()
    print(f"Dass sich eins - oder gar mehrere - im {protagonist.wort_fuer_dungeon()} verirren, war nicht vorgesehen.\n")
    WARTEN()
    print("Physisch gesehen hat der Kampf keinen bleibenden Schaden angerichtet, aber für die nächsten "
          "Wochen solltest du starke Anstrengung vermeiden.\n")
    WARTEN()
    print("Dass sich deine Aufnahmeprüfung damit für absehbare Zeit erledigt hat, muss er nicht hinzufügen. "
          "Das verstehst du auch selbst.\n")
    WARTEN()
    print("Vielleicht lässt sich der Meister später zu einer Wiederholung überreden, "
          "sehr wahrscheinlich ist es aber nicht\n")
    WARTEN()
    print("Geplant oder nicht, deine Niederlage dürfte ihn schon ziemlich enttäuscht haben.\n")
    WARTEN()
    print("Jetzt kannst du nur noch hoffen, dein Glück nach der Genesung noch einmal - vermutlich aber woanders - "
          "zu versuchen.\n")
    WARTEN()
    print("Schlimmstenfalls war's das mit den Abenteuern in einer Zunft. Aber du gibst die Hoffnung noch nicht auf.\n")
    WARTEN()
    print("Und zumindest übernimmt der Meister die Behandlungskosten, wie von der Zunft vorgeschrieben. Lass das "
          "vorerst dein Trost sein.\n")
    WARTEN()
    print("Ende.\n")
    WARTEN()
    return
