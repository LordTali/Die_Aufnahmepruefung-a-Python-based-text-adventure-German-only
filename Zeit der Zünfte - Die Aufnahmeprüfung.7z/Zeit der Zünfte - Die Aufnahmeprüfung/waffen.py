import random
from steuerelemente import *
from colorama import Fore


class Waffe:
    def __init__(self, name, typ, gattung, gewicht, reichweite, angriffsbonus, toedlichkeit, schaden,
                 schadensart, besonderheit, belastung, verteidigungsmalus, angriffsmalus):
        self.name = name
        self.typ = typ
        self.gattung = gattung
        self.gewicht = gewicht
        self.gattung = gattung
        self.reichweite = reichweite
        self.angriffsbonus = angriffsbonus
        self.schadensart = schadensart
        self.besonderheit = besonderheit
        self.schaden = schaden
        self.belastung = belastung
        self.verteidigungsmalus = verteidigungsmalus
        self.toedlichkeit = toedlichkeit
        self.angriffsmalus = angriffsmalus

    def wurf_w4(self, wuerfel):
        ergebnis = 0
        for element in range(1, wuerfel+1):
            wurf = random.randint(1, 4)
            print(f"{Fore.WHITE}[Wurf: {wurf}]{Fore.GREEN}\n")
            WARTEN()
            ergebnis += wurf
        return ergebnis

    def wurf_w6(self, wuerfel):
        ergebnis = 0
        for element in range(1, wuerfel+1):
            wurf = random.randint(1, 6)
            print(f"{Fore.WHITE}[Wurf: {wurf}]{Fore.GREEN}\n")
            WARTEN()
            ergebnis += wurf
        return ergebnis

    def wurf_w8(self, wuerfel):
        ergebnis = 0
        for element in range(1, wuerfel+1):
            wurf = random.randint(1, 8)
            print(f"{Fore.WHITE}[Wurf: {wurf}]{Fore.GREEN}\n")
            WARTEN()
            ergebnis += wurf
        return ergebnis

    def wurf_w10(self, wuerfel):
        ergebnis = 0
        for element in range(1, wuerfel+1):
            wurf = random.randint(1, 10)
            print(f"{Fore.WHITE}[Wurf: {wurf}]{Fore.GREEN}\n")
            WARTEN()
            ergebnis += wurf
        return ergebnis

    def wurf_w12(self, wuerfel):
        ergebnis = 0
        for element in range(1, wuerfel+1):
            wurf = random.randint(1, 12)
            print(f"{Fore.WHITE}[Wurf: {wurf}]{Fore.GREEN}\n")
            WARTEN()
            ergebnis += wurf
        return ergebnis

    def wurf_w20(self, wuerfel):
        ergebnis = 0
        for element in range(1, wuerfel+1):
            wurf = random.randint(1, 20)
            print(f"{Fore.WHITE}[Wurf: {wurf}]{Fore.GREEN}\n")
            WARTEN()
            ergebnis += wurf
        return ergebnis


def waffenschaden(anzahl, schadenswuerfel):
    gesamtschaden = 0
    zaehler = 1
    for element in range(anzahl):
        wurf = random.randint(1, schadenswuerfel)
        print(f"{Fore.WHITE}[Wurf {zaehler}: {wurf}]{Fore.GREEN}\n")
        WARTEN()
        zaehler += 1
        gesamtschaden += wurf
    print(f"{Fore.WHITE}[Schaden (Waffe): {gesamtschaden}]{Fore.GREEN}\n")
    WARTEN()
    return gesamtschaden


class Schwerter (Waffe):
    def __init__(self, name, typ, gattung, gewicht, reichweite, angriffsbonus, toedlichkeit, schaden, schadensart,
                 besonderheit, belastung, verteidigungsmalus, angriffsmalus):
        super().__init__(name=name, typ=typ, gattung="Schwerter", gewicht=gewicht, reichweite=reichweite,
                         angriffsbonus=angriffsbonus, toedlichkeit=toedlichkeit, schaden=schaden,
                         schadensart=schadensart, besonderheit=besonderheit, belastung=belastung,
                         verteidigungsmalus=verteidigungsmalus, angriffsmalus=angriffsmalus)


class Aexte (Waffe):
    def __init__(self, name, typ, gattung, gewicht, reichweite, angriffsbonus, toedlichkeit, schaden, schadensart,
                 besonderheit, belastung, verteidigungsmalus, angriffsmalus):
        super().__init__(name=name, typ=typ, gattung="Äxte", gewicht=gewicht, reichweite=reichweite,
                         angriffsbonus=angriffsbonus, toedlichkeit=toedlichkeit, schaden=schaden,
                         schadensart=schadensart, besonderheit="Sperrig", belastung=belastung,
                         verteidigungsmalus=verteidigungsmalus, angriffsmalus=angriffsmalus)


dolch = Waffe("Dolch", "Nahkampf", "leichte und Wurfwaffen", 0.6,
              1, 0, "1W6", random.randint(1, 6), "S",
              "fernkampftauglich", 0, 0, 0)

hasenkette = Waffe("Hasenkette", "Nahkampf", "Leichte und Wurfwaffen", 1,1,
                   1,"1W4+1", random.randint(1,4) + 1, "H",
                   "fernkampftauglich", 0,0,0)


kurzschwert = Schwerter("Kurzschwert", "Nahkampf", "Schwerter", 1, 1, 0,
                        "1W8", random.randint(1, 8), "H/S", "kombinierbar",
                        1, 0, 0)

langschwert = Schwerter("Langschwert", "Nahkampf", "Schwerter", 1, 1, 0,
                        "1W8+2", random.randint(1, 8) + 2, "H", "", 0,
                        0, 1)

sachs = Waffe("Sachs", "Nahkampf", "Leichte und Wurfwaffen", 0.6, 1, 0,
              "1W4+2", random.randint(1, 4) +2, "S", "", 0,
              0, 0)

sichel = Waffe("Sichel", "Nahkampf", "Ungewöhnliche Waffen", 0.5, 1, 0,
               "1W6+1W4", random.randint(1, 6) + random.randint(1, 4), "H",
               "", 0, 0, 2, )

streitaxt = Aexte("Streitaxt", "Nahkampf", "Äxte", 2, 1, 0,
                  "2W8", random.randint(1, 8) + random.randint(1, 8), "H",
                  "", 1, 0, 1)

streithammer = Waffe("Streithammer", "Nahkampf", "Wuchtwaffen", 5, 1, 0,
                     "3W8", random.randint(1, 8) + random.randint(1, 8) +
                     random.randint(1, 8), "W", "", 3, 0,
                     0)

unbewaffnet = Waffe("Unbewaffnet", "Nahkampf", "Leichte und Wurfwaffen", 0, 1,
                    0, "1W6", random.randint(1, 6), "W", "",
                    0, 0, 0)

zauberstab = Waffe("Zauberstab", "Nahkampf", "Ungewöhnliche Waffen", 1, 1,
                   0, "1W6-1", random.randint(1, 6) - 1, "W", "",
                   1, 0, 1)

zweihaendige_axt = Aexte("Zweihändige Axt", "Nahkampf", "Äxte", 3, 1,
                         0, "2W12", random.randint(1, 12) + random.randint(1, 12),
                         "H", "sperrig", 2, 2, 2)
